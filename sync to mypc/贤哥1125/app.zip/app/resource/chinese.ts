<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>CWlan</name>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="80"/>
        <source>remove</source>
        <translation>删除</translation>
    </message>
</context>
<context>
    <name>ColumnarCurve</name>
    <message>
        <source>Predefined curve can not modify!</source>
        <translation type="obsolete">预定义曲线不能修改</translation>
    </message>
    <message>
        <source>Selecting </source>
        <translation type="obsolete">选择</translation>
    </message>
</context>
<context>
    <name>ColumnarCurveUf</name>
    <message>
        <source>Predefined curve can not modify!</source>
        <translation type="obsolete">预定义曲线不能修改</translation>
    </message>
    <message>
        <source>Selecting </source>
        <translation type="obsolete">选择</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Params</source>
        <translation type="obsolete">参数</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="66"/>
        <source>Curent Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="67"/>
        <source>Curent Hco3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="68"/>
        <source>Filter1 all Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="69"/>
        <source>Filter1 used Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="70"/>
        <source>Filter1 remain Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="71"/>
        <source>Filter2 all Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="72"/>
        <source>Filter2 used Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="73"/>
        <source>Filter2 remain Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="395"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="658"/>
        <source>/Config/Engineer_Factoryset/CureMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="442"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="665"/>
        <source>/Config/Engineer_Factoryset/ProfileMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="482"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="756"/>
        <source>/Config/Engineer_Factoryset/fluidMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="508"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="766"/>
        <source>/Config/Engineer_Factoryset/GetBloodMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="518"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="776"/>
        <source>/Config/Engineer_Factoryset/ReturnBloodMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="528"/>
        <source>/Config/Engineer_Factoryset/HeparinMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="568"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="782"/>
        <source>/Config/Engineer_Factoryset/ChemicalDisinfect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="833"/>
        <source>select the update Packag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="389"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="628"/>
        <source>/Config/Engineer_Factoryset/PrimeMode</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="14"/>
        <source>工程模式</source>
        <translation>工程模式</translation>
    </message>
    <message utf8="true">
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="26"/>
        <source>关闭窗口</source>
        <translation>关闭窗口</translation>
    </message>
    <message>
        <source>状态和信息</source>
        <translation type="obsolete">状态和信息</translation>
    </message>
    <message>
        <source>软件版本</source>
        <translation type="obsolete">软件版本</translation>
    </message>
    <message>
        <source>编译时间</source>
        <translation type="obsolete">编译时间</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="110"/>
        <source>Update System Software &amp; Firmware</source>
        <translation>更新系统固件</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="123"/>
        <source>CheckVersion</source>
        <translation>查询软件版本</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="136"/>
        <source>BloodVersion</source>
        <translation>血泵软件版本</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="149"/>
        <source>Blood2Version</source>
        <translation>血泵2软件版本</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="162"/>
        <source>MornitorVersion</source>
        <translation>监控板软件版本</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="175"/>
        <source>HeparinVersion</source>
        <translation>肝素泵软件版本</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="188"/>
        <source>MasterVersion</source>
        <translation>主板软件版本</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="201"/>
        <source>PowerVersion</source>
        <translation>电源板软件版本</translation>
    </message>
    <message>
        <source>参数设置</source>
        <translation type="obsolete">参数设置</translation>
    </message>
    <message>
        <source>曲线设置</source>
        <translation type="obsolete">曲线设置</translation>
    </message>
    <message>
        <source>配方设置</source>
        <translation type="obsolete">配方设置</translation>
    </message>
    <message>
        <source>系统更新</source>
        <translation type="obsolete">系统更新</translation>
    </message>
    <message>
        <source>出厂设置</source>
        <translation type="obsolete">chuchang</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="46"/>
        <source>Status and info</source>
        <translation>状态和信息</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="58"/>
        <source>Versions</source>
        <translation>软件版本</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="71"/>
        <source>Build In</source>
        <translation>编译时间</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="214"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="227"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="240"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="253"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="266"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="279"/>
        <source>null</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="311"/>
        <source>Params set</source>
        <translation>参数设置</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="316"/>
        <source>Curve Set</source>
        <translation>曲线设置</translation>
    </message>
    <message>
        <source>Formulation</source>
        <translation type="obsolete">配方设置</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="321"/>
        <source>Formula</source>
        <translation>配方设置</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="333"/>
        <source>BCond.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="346"/>
        <source>MixCond.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="359"/>
        <source>scal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="404"/>
        <source>Curent      Na:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="417"/>
        <source>Curent HCO3:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="430"/>
        <source>Factory Set</source>
        <translation>出厂设置</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="442"/>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="455"/>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="468"/>
        <source>Volume :</source>
        <translation>音量:</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="520"/>
        <source>Display Auto Off Time</source>
        <translation>显示自动关机时间</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="533"/>
        <source>Display Remaining Time</source>
        <translation>显示剩余时间</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="546"/>
        <source>Display Last Programs</source>
        <translation>显示上一次消毒</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="559"/>
        <source>Display Filter Change</source>
        <translation>显示超净滤器</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="572"/>
        <source>Chemical Disinfect</source>
        <translation>化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="584"/>
        <source>Chymistry Peracetic </source>
        <translation>过氧乙酸</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="600"/>
        <source>Chymistry Citric</source>
        <translation>柠檬酸</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="613"/>
        <source>Chymistry Reserve3</source>
        <translation>次氯酸钠</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="627"/>
        <source>Central Disinfect Mode</source>
        <translation>中央消毒</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="710"/>
        <source>Online</source>
        <translation>在线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="943"/>
        <source>Heparin Select</source>
        <translation>肝素泵启用</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="958"/>
        <source>YES</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="971"/>
        <source>NO</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="985"/>
        <source>Connect P.t</source>
        <translation>引血</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1000"/>
        <source>Online  Getblood</source>
        <translation>在线引血</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1013"/>
        <source>Getblood</source>
        <translation>引血</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1027"/>
        <source>Cure mode</source>
        <translation>治疗模式</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1042"/>
        <source>HD_DDB</source>
        <translation>HD双针</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1055"/>
        <source>HD_SDP</source>
        <translation>HD单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1068"/>
        <source>HD_SSP</source>
        <translation>HD单针单泵</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1081"/>
        <source>HDF_PRE</source>
        <translation>HDF前置换</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1094"/>
        <source>HDF_POST</source>
        <translation>HDF后置换</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1107"/>
        <source>HF_PRE</source>
        <translation>HF前置换</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1120"/>
        <source>HF_POST</source>
        <translation>HF后置换</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1133"/>
        <source>ISO_DDP</source>
        <translation>ISO双针</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1146"/>
        <source>ISO_SDP</source>
        <translation>ISO单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1159"/>
        <source>ISO_SSP</source>
        <translation>ISO单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1172"/>
        <source>PE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1186"/>
        <source>Return blood</source>
        <translation>回血</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1201"/>
        <source>Online Returnblood</source>
        <translation>在线回血</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1214"/>
        <source>Returnblood</source>
        <translation>回血</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1228"/>
        <source>Fluid mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1243"/>
        <source>A_and_B</source>
        <translation>A液+B液</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1256"/>
        <source>A_and_BPower</source>
        <translation>A液+干粉</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1269"/>
        <source>Acetate</source>
        <translation>醋酸盐</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1282"/>
        <source>Center</source>
        <translation>中央供液</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1296"/>
        <source>Restore Param</source>
        <translation>恢复参数文件</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1309"/>
        <source>Profile mode</source>
        <translation>曲线模式</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1324"/>
        <source>Na Profile</source>
        <translation>钠曲线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1337"/>
        <source>UF Profile</source>
        <translation>超滤曲线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1350"/>
        <source>Dia Profile</source>
        <translation>透析液曲线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1363"/>
        <source>Cond Profile</source>
        <translation>电导曲线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1376"/>
        <source>Temp Profile</source>
        <translation>温度曲线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1389"/>
        <source>Hco3 Profile</source>
        <translation>HCO3曲线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1402"/>
        <source>Hep Profile</source>
        <translation>肝素曲线</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1424"/>
        <source>ReadOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1436"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1488"/>
        <source>Address(dec)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1449"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1501"/>
        <source>data(dec)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1463"/>
        <source>Input Address(dec)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1476"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peracetic acid</source>
        <translation type="obsolete">过氧乙酸</translation>
    </message>
    <message>
        <source>Central Disinfect</source>
        <translation type="obsolete">中央消毒</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="639"/>
        <source>Central Hot</source>
        <translation>中央热消毒</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="655"/>
        <source>Central Chemical</source>
        <translation>中央化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="669"/>
        <source>Prime Select</source>
        <translation>预冲</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="684"/>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="697"/>
        <source>Manual</source>
        <translation>手动</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="724"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="737"/>
        <source>Edit Password</source>
        <translation>秘密设置</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="752"/>
        <source>set password</source>
        <translation>修改密码</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="766"/>
        <source>Until Filter</source>
        <translation>超净滤器</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="788"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="867"/>
        <source>All Times</source>
        <translation>总次数</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="811"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="880"/>
        <source>Used Times</source>
        <translation>已用次数</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="824"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="903"/>
        <source>Remain Times</source>
        <translation>剩余次数</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="916"/>
        <source>Filter1</source>
        <translation>滤器1</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="929"/>
        <source>Filter2</source>
        <translation>滤器2</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1412"/>
        <source>EEPROM</source>
        <translation>测试</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../../src/httpserver/httpserver.cpp" line="168"/>
        <source>&lt;!DOCTYPE html&gt;                        &lt;html&gt;                       &lt;head&gt;                       &lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charset=utf-8&quot; /&gt;                      &lt;meta http-equiv=&quot;refresh&quot; content=&quot;10&quot;&gt;                      &lt;title&gt;JH-5058 &lt;/title&gt;                      &lt;/head&gt;                       &lt;body&gt; &lt;table width=&quot;100%&quot; border=&quot;1&quot;&gt;&lt;tr&gt; </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogRunModel</name>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="351"/>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="455"/>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="457"/>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="458"/>
        <source>Formula</source>
        <translation type="unfinished">配方设置</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="425"/>
        <source>Change: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="426"/>
        <source> from </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="428"/>
        <source> to </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>HemoDialysis</source>
        <translation type="obsolete">血透机</translation>
    </message>
</context>
<context>
    <name>NumberInputPanel</name>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <location filename="../../src/virtual_keyboard/number_input_panel.cpp" line="53"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/virtual_keyboard/number_input_panel.cpp" line="263"/>
        <source>max  600</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/virtual_keyboard/number_input_panel.cpp" line="276"/>
        <source>min  300</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PASSWORD</name>
    <message>
        <location filename="../../src/wlan/password.cpp" line="40"/>
        <source>OK</source>
        <translation>完成</translation>
    </message>
    <message>
        <location filename="../../src/wlan/password.cpp" line="41"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/wlan/password.cpp" line="42"/>
        <source>password</source>
        <translation>密码</translation>
    </message>
</context>
<context>
    <name>PatientMessage</name>
    <message>
        <source>Time :</source>
        <translation type="obsolete">时间</translation>
    </message>
    <message>
        <source>Tem :</source>
        <translation type="obsolete">温度</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="405"/>
        <source>Na+ :</source>
        <translation>钠:</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="406"/>
        <source>Hco3 :</source>
        <translation></translation>
    </message>
    <message>
        <source>UltraVol :</source>
        <translation type="obsolete">超滤目标</translation>
    </message>
    <message>
        <source>BPSpeed :</source>
        <translation type="obsolete">血泵流速</translation>
    </message>
    <message>
        <source>man</source>
        <translation type="obsolete">男</translation>
    </message>
    <message>
        <source>nephrology dept</source>
        <translation type="obsolete">肾内科</translation>
    </message>
    <message>
        <source>renal failure</source>
        <translation type="obsolete">肾衰竭</translation>
    </message>
    <message>
        <source>gram</source>
        <translation type="obsolete">参数</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="392"/>
        <source>ID :</source>
        <translation>编号:</translation>
    </message>
    <message>
        <source>Name :</source>
        <translation type="obsolete">姓名</translation>
    </message>
    <message>
        <source>Sex :</source>
        <translation type="obsolete">性别</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="396"/>
        <source>Age :</source>
        <translation>年龄:</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="398"/>
        <source>Depart :</source>
        <translation>科室:</translation>
    </message>
    <message>
        <source>Weight :</source>
        <translation type="obsolete">体重</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="400"/>
        <source>Diagnose :</source>
        <translation>诊断:</translation>
    </message>
    <message>
        <source>Please keep the IC card in the card slot! then click &apos;ReadCard&apos; to read card, click &apos;WriteCard&apos; after set the value.</source>
        <translation type="obsolete">请把卡放在卡槽上！然后点击‘读卡’进行读卡，点击‘写卡’设置参数值；</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="394"/>
        <source>Name &amp; Surname :</source>
        <translation>姓名:</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="395"/>
        <source>Gender :</source>
        <translation>性别:</translation>
    </message>
    <message>
        <source>Dry weight :</source>
        <translation type="obsolete">体重:</translation>
    </message>
    <message>
        <source>Time (h):</source>
        <translation type="obsolete">时间(H):</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="137"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="399"/>
        <source>Dry weight(KG):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="403"/>
        <source>Time(H):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="404"/>
        <source>Temp :</source>
        <translation>温度:</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="407"/>
        <source>UF goal :</source>
        <translation>超滤目标:</translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="408"/>
        <source>Blood Flow :</source>
        <translation>血泵流速:</translation>
    </message>
    <message>
        <source>Please insert IC card into slot before click &apos;read&apos;,then do setting for RF card,and click &apos;write&apos; to save it.</source>
        <translation type="obsolete">请把卡放在卡槽上！然后点击‘读卡’进行读卡，点击‘写卡’设置参数值；</translation>
    </message>
    <message>
        <source>write a card over, please take the IC card!</source>
        <translation type="obsolete">写卡完成，请取下卡！</translation>
    </message>
    <message>
        <source>Write Card</source>
        <translation type="obsolete">写卡</translation>
    </message>
    <message>
        <source>Read Card</source>
        <translation type="obsolete">读卡</translation>
    </message>
    <message>
        <source>BP</source>
        <translation type="obsolete">血压</translation>
    </message>
    <message>
        <source>Pulse</source>
        <translation type="obsolete">脉搏</translation>
    </message>
    <message>
        <source>AP</source>
        <translation type="obsolete">动脉压</translation>
    </message>
    <message>
        <source>VP</source>
        <translation type="obsolete">静脉压</translation>
    </message>
    <message>
        <source>TMP</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
</context>
<context>
    <name>QLabel</name>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="18"/>
        <source>Sum UF</source>
        <translation>总超滤量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="19"/>
        <source>UF mode</source>
        <translation>超滤模式</translation>
    </message>
    <message>
        <source>Cure time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="21"/>
        <source>Selecting</source>
        <translation>已选中时段</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="22"/>
        <source>Predefined curve can not modify!</source>
        <translation>预定义曲线不能修改!</translation>
    </message>
    <message>
        <source>Conductance(Na) Curve</source>
        <translation type="obsolete">总电导度(钠)曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="24"/>
        <source>Sequential UF Curve</source>
        <translation>序贯超滤曲线</translation>
    </message>
    <message>
        <source>The seleceed
period value
[ms/cm]</source>
        <translation type="obsolete">所选时段
数值
[ms/cm]</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="26"/>
        <source>The seleceed
period value
[%]</source>
        <translation>所选时段
数值
[%]</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="27"/>
        <source>Set all
period
value</source>
        <translation>设定全部
时段数值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="28"/>
        <source>Current
curve num</source>
        <translation>当前曲线
序号</translation>
    </message>
    <message>
        <source>Na+ Curve</source>
        <translation type="obsolete">钠离子曲线</translation>
    </message>
    <message>
        <source>UF Curve</source>
        <translation type="obsolete">超滤曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="31"/>
        <source>Browse
curve</source>
        <translation>浏览曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="20"/>
        <location filename="../../src/common/common_tr_string.h" line="32"/>
        <source>Treatment time</source>
        <translation>治疗时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="23"/>
        <source>Conductivity(Na) Curve</source>
        <translation>总电导度(钠)曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="25"/>
        <source>The seleceed
period value
[mmol/L]</source>
        <translation>所选时段
数值[mmol/L]</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="29"/>
        <source>Na+ Profile</source>
        <translation>钠曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="30"/>
        <location filename="../../src/common/common_tr_string.h" line="183"/>
        <source>UF Profile</source>
        <translation>超滤曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="33"/>
        <source>Each period</source>
        <translation>每个时段</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="34"/>
        <source>Not selected</source>
        <translation>无选择时段</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="35"/>
        <source>More than the UF seted value!</source>
        <translation>超出总超滤量的设定值！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="36"/>
        <source>Less than the UF seted value!</source>
        <translation>低于总超滤量的设定值！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="37"/>
        <source>Previous</source>
        <translation>前翻</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="38"/>
        <source>Next</source>
        <translation>后翻</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="39"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="41"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="42"/>
        <source>Return</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="43"/>
        <source>Define</source>
        <translation>预定义</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="44"/>
        <source>Custom</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="45"/>
        <source>This curve data run success!</source>
        <translation>本曲线数据应用成功!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="46"/>
        <source>This curve data save success!</source>
        <translation>本曲线数据保存成功!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="47"/>
        <source>This curve already reset !</source>
        <translation>本曲线已经清除 ！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="48"/>
        <source>An error occurred,save fail!</source>
        <translation>发生错误，保存失败！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="49"/>
        <source>An error occurred,run fail!</source>
        <translation>发生错误，应用失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="50"/>
        <source>An error occurred on PNG file!</source>
        <translation>PNG文件发生错误!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="51"/>
        <source>Prompt</source>
        <translation>提示</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="52"/>
        <source>This curve data save and run!</source>
        <translation>本曲线数据已保存并应用!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="53"/>
        <source>Please select a columnar!</source>
        <translation>请选中一个时段!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="54"/>
        <source>Please select a curve!</source>
        <translation>请选择一个曲线!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="55"/>
        <source>Are you sure to apply?</source>
        <translation>您确定要应用吗？</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="56"/>
        <source>Are you sure to save?</source>
        <translation>您确定要保存吗？</translation>
    </message>
    <message>
        <source>Cure time can not less</source>
        <translation type="obsolete">治疗时间不能少于</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="60"/>
        <source>mintues</source>
        <translation>分钟</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="61"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="62"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="72"/>
        <location filename="../../src/common/common_tr_string.h" line="292"/>
        <source>Please Confirm</source>
        <translation>请确认</translation>
    </message>
    <message>
        <source>If pass selfcheck,the device maybe instable!</source>
        <translation type="obsolete">如果跳过自检，设备可能不稳定!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="78"/>
        <source>Do you want to Stop Cleanning ?</source>
        <translation>您确定停止消毒吗？</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="79"/>
        <source>Do you want to ShotDown ?</source>
        <translation>您是否想关机?</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="80"/>
        <source>Please selct disinfect type!</source>
        <translation>请选择消毒类型!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="81"/>
        <source>NO water!</source>
        <translation>无水</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="84"/>
        <source>Selfcheck timed out failure, please restart!</source>
        <translation>自检超时失败，请重启！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="85"/>
        <source>Selfcheck error, please restart!</source>
        <translation>自检出错失败，请重启！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="86"/>
        <source>The blood Selfcheck fails!</source>
        <translation>血路自检失败！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="87"/>
        <source>The water Selfcheck fails!</source>
        <translation>水路自检失败！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="90"/>
        <source>Can be treated!</source>
        <translation>可以进入治疗！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="91"/>
        <source>Didn&apos;t open the heparin pump, please open!</source>
        <translation>没有打开肝素泵，请打开！</translation>
    </message>
    <message>
        <source>Whether to continue return blood? &apos;Yes&apos;-continue,&apos;No&apos;-end!</source>
        <translation type="obsolete">是否继续回血？是-继续，否-结束！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="40"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="57"/>
        <source>Treatment time can not less</source>
        <translation>治疗时间不能太少</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="58"/>
        <source>This profile is runing!</source>
        <translation>该曲线已经在运行!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="59"/>
        <source>This profile is undefined!</source>
        <translation>该曲线未定义!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="64"/>
        <source>Control</source>
        <translation>控制</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="65"/>
        <source>Voltage</source>
        <translation>电压</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="66"/>
        <source>Set value</source>
        <translation>设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="67"/>
        <source>Foreward</source>
        <translation>正转</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="68"/>
        <source>Rollback</source>
        <translation>反转</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="69"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="73"/>
        <source>Warning:Do not skip self test to do treatment.</source>
        <translation>警告！请不要跳过自检.</translation>
    </message>
    <message>
        <source>Venous air alarm,whether to continue return blood? &apos;Yes&apos;-continue,&apos;No&apos;-end!</source>
        <translation type="obsolete">静脉气泡报警,是否继续回血？是-继续，否-结束！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="94"/>
        <source>Whether to continue drain? &apos;Yes&apos;-continue,&apos;No&apos;-end!</source>
        <translation>是否继续排空？是-继续，否-结束！</translation>
    </message>
    <message>
        <source>Happen alarm,already stop bloodpump,please handle fault alarm as soon!Then manually start blood pump!</source>
        <translation type="obsolete">发生报警，已停止血泵，请尽快处理报警故障！然后手动开启血泵！</translation>
    </message>
    <message>
        <source>Initialize state</source>
        <translation type="obsolete">初始化状态</translation>
    </message>
    <message>
        <source>Prepare state</source>
        <translation type="obsolete">准备状态</translation>
    </message>
    <message>
        <source>Treatment state</source>
        <translation type="obsolete">治疗状态</translation>
    </message>
    <message>
        <source>Finish treatment state</source>
        <translation type="obsolete">结束治疗状态</translation>
    </message>
    <message>
        <source>Cleaning state</source>
        <translation type="obsolete">清洁消毒状态</translation>
    </message>
    <message>
        <source>Debug state</source>
        <translation type="obsolete">调试状态</translation>
    </message>
    <message>
        <source>Drain state</source>
        <translation type="obsolete">排空状态</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="92"/>
        <source>No blood,whether to continue return blood? &apos;Yes&apos;-continue,&apos;No&apos;-end!</source>
        <translation>无血报警，是否继续回血？是-继续，否-结束！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="93"/>
        <source>Whether has ended return blood? &apos;Yes&apos;-start drain,&apos;No&apos;-return!</source>
        <translation>是否已经结束回血？是-开始排空，否-返回</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="96"/>
        <source>Are you sure preflush finish?</source>
        <translation>你确定预冲已完成？</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="97"/>
        <source>Treatment finish,go to blood return!</source>
        <translation>治疗结束，进入回血！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="99"/>
        <source>online prime</source>
        <translation>在线预冲</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="100"/>
        <source>online P.t</source>
        <translation>在线引血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="101"/>
        <source>online RB</source>
        <translation>在线回血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="107"/>
        <source>Initialize</source>
        <translation>初始化</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="108"/>
        <source>Preparation</source>
        <translation>准备</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="109"/>
        <source>Treatment</source>
        <translation>治疗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="110"/>
        <source>Disconnection</source>
        <translation>结束治疗状态</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="111"/>
        <source>Cleaning</source>
        <translation>清洁</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="112"/>
        <source>Debug</source>
        <translation>调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="113"/>
        <source>Drain</source>
        <translation>排水</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="115"/>
        <source>Free state</source>
        <translation>等待状态</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="116"/>
        <source>Self checking</source>
        <translation>自检中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="117"/>
        <source>Self check ok have fluid</source>
        <translation>自检完成,有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="118"/>
        <source>Self check ok no fluid</source>
        <translation>自检完成,无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="119"/>
        <source>Preflush runing have fluid</source>
        <translation>预冲中,有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="120"/>
        <source>Manual preflush have fluid</source>
        <translation>手动预冲有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="121"/>
        <source>Auto preflush have fluid</source>
        <translation>自动预冲有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="122"/>
        <source>Online preflush have fluid</source>
        <translation>在线预冲有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="124"/>
        <source>Preflush runing no fluid</source>
        <translation>预冲中,无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="125"/>
        <source>Manual preflush no fluid</source>
        <translation>手动预冲无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="126"/>
        <source>Auto preflush no fluid</source>
        <translation>自动预冲无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="127"/>
        <source>Online preflush no fluid</source>
        <translation>在线预冲无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="129"/>
        <source>Preflush stop have fluid</source>
        <translation>预冲停止,有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="130"/>
        <source>Preflush stop no fluid</source>
        <translation>预冲停止,无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="131"/>
        <source>Preflush ok have fluid</source>
        <translation>预冲完成,有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="132"/>
        <source>Preflush ok no fluid</source>
        <translation>预冲完成,无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="133"/>
        <source>have blood and fluid can treatment</source>
        <translation>有血有液,可进入治疗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="134"/>
        <source>have blood no fluid can treatment</source>
        <translation>有血无液,可进入治疗</translation>
    </message>
    <message>
        <source>get blood no fluid</source>
        <translation type="obsolete">引血无液</translation>
    </message>
    <message>
        <source>get blood have fluid</source>
        <translation type="obsolete">引血有液</translation>
    </message>
    <message>
        <source>get blood stop no fluid</source>
        <translation type="obsolete">引血停无液</translation>
    </message>
    <message>
        <source>get blood stop have fluid</source>
        <translation type="obsolete">引血停有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="142"/>
        <source>Clean runing</source>
        <translation>清洁消毒中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="143"/>
        <source>Clean stop</source>
        <translation>清洁消毒停止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="144"/>
        <source>Clean finished</source>
        <translation>清洁消毒结束</translation>
    </message>
    <message>
        <source>Bloodreturn runing have blood</source>
        <translation type="obsolete">回血中 有血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="74"/>
        <source>Prompt:Whether access debug module?</source>
        <translation>是否进入调试模式?</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="75"/>
        <source>Super clean filter useable times less 3.</source>
        <translation>超净滤器可用次数小于5次.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="76"/>
        <source>Super clean filter useable times is 0.</source>
        <translation>超净滤器可用次数为0.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="95"/>
        <source>Stop blood pump alarm is processed,please open blood pump!</source>
        <translation>使血泵停止的报警已处理，请打开血泵!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="104"/>
        <source>Heparin is running, please first suspended!</source>
        <translation>肝素泵正运行，请先停止!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="135"/>
        <source>connectP.t no fluid</source>
        <translation>引血无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="136"/>
        <source>Online connectP.t no fluid</source>
        <translation>在线引血无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="137"/>
        <source>connectP.t have fluid</source>
        <translation>引血有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="138"/>
        <source>Online connectP.t have fluid</source>
        <translation>在线引血有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="139"/>
        <source>connectP.t stop no fluid</source>
        <translation>引血停止无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="140"/>
        <source>connectP.t stop have fluid</source>
        <translation>引血停止有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="146"/>
        <source>Bloodreturn have blood</source>
        <translation>回血有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="147"/>
        <source>Online Bloodreturn have blood</source>
        <translation>在线回血有液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="148"/>
        <source>Bloodreturn runing no blood</source>
        <translation>回血中 无血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="149"/>
        <source>Online Bloodreturn no blood</source>
        <translation>在线回血无液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="150"/>
        <source>Bloodreturn stop have blood</source>
        <translation>回血停止 有血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="151"/>
        <source>Bloodreturn stop no blood</source>
        <translation>回血停止 无血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="152"/>
        <source>Drain runing</source>
        <translation>排空中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="153"/>
        <source>Drain stop</source>
        <translation>排空停止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="155"/>
        <source>Water to prepare</source>
        <translation>水路准备</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="156"/>
        <source>Dry barrels preflush</source>
        <translation>干粉桶预冲</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="157"/>
        <source>DM test</source>
        <translation>水路自检</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="158"/>
        <source>DM test ok</source>
        <translation>水路自检OK</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="159"/>
        <source>Provincial fluid</source>
        <translation>省液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="160"/>
        <source>Water suspension</source>
        <translation>水路停止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="161"/>
        <source>Provincial fluid and bypass</source>
        <translation>省液 旁路</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="162"/>
        <source>Stop fluid</source>
        <translation>停液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="163"/>
        <source>Bypass</source>
        <translation>旁路</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="165"/>
        <source>Disinfection preparation</source>
        <translation>清洁准备</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="166"/>
        <source>Disinfection preflush</source>
        <translation>消毒前冲洗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="167"/>
        <source>SUCK flush</source>
        <translation>吸消毒液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="168"/>
        <source>Hold</source>
        <translation>滞留</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="169"/>
        <source>Loop</source>
        <translation>消毒循环</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="170"/>
        <source>After rinse</source>
        <translation>消毒后冲洗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="171"/>
        <source>Cold rinse</source>
        <translation>冷冲洗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="172"/>
        <source>Hot rinse 1</source>
        <translation>热冲洗阶段1</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="173"/>
        <source>Hot rinse 2</source>
        <translation>热冲洗阶段2</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="174"/>
        <source>Hot rinse 3</source>
        <translation>热冲洗阶段3</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="175"/>
        <source>Emptying</source>
        <translation>清洁后排空</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="176"/>
        <source>Pipe rinse</source>
        <translation>冲洗进水管</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="177"/>
        <source>The CCD suck</source>
        <translation>中央化消入液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="178"/>
        <source>The CCD rinse</source>
        <translation>中央化消冲洗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="179"/>
        <source>The CHD</source>
        <translation>中央热消毒</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="181"/>
        <source>NA UF Profile</source>
        <translation>NA+UF曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="182"/>
        <source>NA Profile</source>
        <translation>钠曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="185"/>
        <source>Cool Rinse</source>
        <translation>冷冲洗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="186"/>
        <source>Hot Rinse</source>
        <translation>热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="187"/>
        <source>Chemical Citricacid</source>
        <translation>柠檬酸消毒</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="188"/>
        <source>Chemical Preacetic</source>
        <translation>过氧乙酸消毒</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="189"/>
        <source>Chemical-3</source>
        <translation>化学消毒3</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="190"/>
        <source>Hot Chemical</source>
        <translation>热化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="191"/>
        <source>Hot Clean</source>
        <translation>纯热消毒</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="193"/>
        <source>HD DoubleNeedle</source>
        <translation>HD双针</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="194"/>
        <source>ISO DoubleNeedle</source>
        <translation>ISO双针</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="195"/>
        <source>HDFonline</source>
        <translation>HDF在线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="196"/>
        <source>HFonline</source>
        <translation>HF在线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="197"/>
        <source>PE/PH</source>
        <translation>PE/PH</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="198"/>
        <source>HD SNSP</source>
        <translation>HD单针单泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="199"/>
        <source>HD SNDP</source>
        <translation>HD单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="200"/>
        <source>ISO SNSP</source>
        <translation>ISO单针单泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="201"/>
        <source>ISO SNDP</source>
        <translation>ISO单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="203"/>
        <source>Pre Dilute</source>
        <translation>前稀释</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="204"/>
        <source>Post Dilute</source>
        <translation>后稀释</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="205"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <source>DiaFlow Curve</source>
        <translation type="obsolete">透析液曲线</translation>
    </message>
    <message>
        <source>Heparin Curve</source>
        <translation type="obsolete">肝素曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="207"/>
        <source>DiaFlow Profile</source>
        <translation>透析液曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="208"/>
        <source>Heparin Profile</source>
        <translation>肝素曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="209"/>
        <source>Cond Profile</source>
        <translation>电导曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="210"/>
        <source>Temp Profile</source>
        <translation>温度曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="211"/>
        <source>HCO3 Profile</source>
        <translation>HCO3曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="213"/>
        <source>You can set a maximum of 6 time period curves !</source>
        <translation>最多可以设置6个时间段曲线 !</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="214"/>
        <source>Addition</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="215"/>
        <source>Reset</source>
        <translation>重设</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="216"/>
        <source>Start Time:</source>
        <translation>开始时间:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="217"/>
        <source>End Time:</source>
        <translation>结束时间:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="219"/>
        <source>IC card reading...</source>
        <translation>IC 卡正在读取中...</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="220"/>
        <source>IC card writing...</source>
        <translation>IC 卡正在写入中...</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="221"/>
        <source>male</source>
        <translation>男性</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="222"/>
        <source>female</source>
        <translation>女性</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="223"/>
        <source>renal medicine</source>
        <translation>肾衰竭</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="224"/>
        <source>endocrine</source>
        <translation>内分泌</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="225"/>
        <source>renal failure</source>
        <translation>肾衰竭</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="226"/>
        <source>uremia</source>
        <translation>尿毒症</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="228"/>
        <source>Pulse AVG</source>
        <translation>平均脉搏</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="229"/>
        <source>SYS AVG</source>
        <translation>平均收缩压</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="230"/>
        <source>DIA AVG</source>
        <translation>平均舒张压</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="231"/>
        <source>AP AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="232"/>
        <source>VP AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="233"/>
        <source>TMP AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="235"/>
        <source>SUB Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="236"/>
        <source>Heparin Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="237"/>
        <source>Treatment mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="238"/>
        <source>Profile Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="239"/>
        <source>Write</source>
        <translation type="unfinished">写</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="240"/>
        <source>Read</source>
        <translation type="unfinished">读</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="241"/>
        <source>Choose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="242"/>
        <source>Data Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="244"/>
        <source>Cure Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="245"/>
        <source>Pre Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="246"/>
        <source>Nxt Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="248"/>
        <source>times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="249"/>
        <source>date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="250"/>
        <source>Temp</source>
        <translation type="unfinished">透析液设定温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="251"/>
        <source>Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="252"/>
        <source>UFFlow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="253"/>
        <source>BPFlow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="254"/>
        <source>Pulse</source>
        <translation type="unfinished">脉搏</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="255"/>
        <source>SYS/DIA</source>
        <translation type="unfinished">收缩压/舒张压</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="256"/>
        <source>First Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="257"/>
        <source>Pre Page</source>
        <translation type="unfinished">上一页</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="258"/>
        <source>Nxt Page</source>
        <translation type="unfinished">下一页</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="259"/>
        <source>Last Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="261"/>
        <source>SYS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="262"/>
        <source>DIA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="264"/>
        <source>Max Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="265"/>
        <source>Min Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="266"/>
        <source>Avg Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="268"/>
        <source>Data Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="270"/>
        <source>standby mode 01</source>
        <translation>第一待机模式</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="271"/>
        <source>standby mode 02</source>
        <translation>第二待机模式</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="272"/>
        <source>No standby mode runing</source>
        <translation>无待机模式运行</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="274"/>
        <source>Treatment model has not changed!</source>
        <translation>治疗模式没有改变！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="277"/>
        <source>UF volume can not exceed the remaining!</source>
        <translation>不能超过剩余超滤量！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="278"/>
        <source>UF volume can not less than finish volume!</source>
        <translation>不能少于已完成量!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="279"/>
        <source>The time can not exceed the remaining time!</source>
        <translation>不能超过剩余治疗时间!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="280"/>
        <source>The time can not less than residue time!</source>
        <translation>不能小于已进行时间!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="281"/>
        <source>The parameters afresh,and take effect!</source>
        <translation>参数更新，并生效!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="282"/>
        <source>Whether to start ISO?</source>
        <translation>是否开始ISO？</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="284"/>
        <source>Whether to start this model?</source>
        <translation>是否开始该模式治疗?</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="285"/>
        <source>The subspump goal reach,stop!</source>
        <translation>置换目标达到，已停泵!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="288"/>
        <source>ISO treatment ends, have switch to </source>
        <translation>ISO治疗结束，已切换到</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="289"/>
        <source>Can not switch to PE in treatment runing!</source>
        <translation>治疗中不能切换到PE模式!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="293"/>
        <source>Warning:Do You want reset all Filter data ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="294"/>
        <source> Reset  Filter data  or dry filter </source>
        <translation>重设或者排空超净滤器</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="295"/>
        <source>Change Filter1</source>
        <translation>超净滤器1</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="296"/>
        <source>Change Filter2</source>
        <translation>超净滤器2</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="299"/>
        <source>The status of the mastercontrol is abnormal,please try again!</source>
        <translation>主控板状态异常，请重新进行!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="304"/>
        <source>Upper Arterial pressure alarm</source>
        <translation>动脉压上限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="305"/>
        <source>Upper Arterial pressure alarm !</source>
        <translation>动脉压上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="307"/>
        <source>Upper venous pressure alarm</source>
        <translation>静脉压上限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="308"/>
        <source>Upper venous pressure alarm !</source>
        <translation>静脉压上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="310"/>
        <source>Upper TMP alarm</source>
        <translation>跨膜压上限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="311"/>
        <source>Upper TMP alarm !</source>
        <translation>跨膜压上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="313"/>
        <source>Upper temperature alarm</source>
        <translation>温度上限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="314"/>
        <source>Upper temperature alarm !</source>
        <translation>温度上限报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="316"/>
        <source>Lower Arterial pressure alarm</source>
        <translation>动脉压下限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="317"/>
        <source>Lower Arterial pressure alarm !</source>
        <translation>动脉压下限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="319"/>
        <source>Lower venous pressure alarm</source>
        <translation>静脉压下限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="320"/>
        <source>Lower venous pressure alarm !</source>
        <translation>静脉压下限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="322"/>
        <source>Lower TMP alarm</source>
        <translation>跨膜压下限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="323"/>
        <source>Lower TMP alarm !</source>
        <translation>跨膜压下限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="325"/>
        <source>Lower temperature alarm</source>
        <translation>温度下限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="326"/>
        <source>Lower temperature alarm !</source>
        <translation>温度下限报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="328"/>
        <source>Blood level alarm</source>
        <translation>液位报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="329"/>
        <source>Blood level alarm !</source>
        <translation>液位报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="331"/>
        <source>Arteries Bubble alarm</source>
        <translation>动脉气泡</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="332"/>
        <source>Arteries Bubble alarm !</source>
        <translation>动脉气泡！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="334"/>
        <source>No blood alarm</source>
        <translation>无血报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="335"/>
        <source>No blood alarm !</source>
        <translation>无血报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="337"/>
        <source>Vein Bubble alarm</source>
        <translation>静脉气泡</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="338"/>
        <source>Vein Bubble alarm !</source>
        <translation>静脉气泡！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="340"/>
        <source>No1 blood pump out of control</source>
        <translation>血泵1失控</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="462"/>
        <source>Set up fluid interface</source>
        <translation>接置换液接口</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="463"/>
        <source>Set up corresponding line displacement fluid interface!</source>
        <translation>将相应管路接到置换液接口!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="466"/>
        <source>Remove fluid interface</source>
        <translation>置换液接口管路移除</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="467"/>
        <source>Remove the displacement fluid interface line!</source>
        <translation>将置换液接口管路移除!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="470"/>
        <source>Set up fluid flush interface</source>
        <translation>接置换液冲洗接口</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="471"/>
        <source>Set up corresponding line displacement fluid flush interface!</source>
        <translation>将相应管路接到置换液冲洗接口!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="474"/>
        <source>Remove fluid flush interface</source>
        <translation>置换液冲洗接口移除</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="475"/>
        <source>Remove the replacement wash liquid interface line!</source>
        <translation>将置换液冲洗接口管路移除!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="480"/>
        <source>CLPV error</source>
        <translation>静脉管夹出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="483"/>
        <source>CLPA error</source>
        <translation>动脉管夹出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="486"/>
        <source>ADPV error</source>
        <translation>静脉气泡故障</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="489"/>
        <source>ADPA error</source>
        <translation>动脉气泡故障</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="492"/>
        <source>LDS error</source>
        <translation>液位探测器出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="495"/>
        <source>PA error</source>
        <translation>动脉压探测器出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="498"/>
        <source>PV error</source>
        <translation>静脉压探测器出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="501"/>
        <source>TMP error</source>
        <translation>跨膜压探测器出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="504"/>
        <source>BLM error</source>
        <translation>漏血探测器出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="507"/>
        <source>BOM error</source>
        <translation>血氧模块出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="510"/>
        <source>BPM error</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="513"/>
        <location filename="../../src/common/common_tr_string.h" line="516"/>
        <location filename="../../src/common/common_tr_string.h" line="519"/>
        <source>BLOOD1 error</source>
        <translation>血泵1出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="522"/>
        <location filename="../../src/common/common_tr_string.h" line="525"/>
        <location filename="../../src/common/common_tr_string.h" line="528"/>
        <source>BLOOD2 error</source>
        <translation>血泵2出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="523"/>
        <source>NO2 blood pump is out of control!</source>
        <translation>血泵2失控!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="526"/>
        <source>NO2 blood pump no feedback!</source>
        <translation>血泵2无反馈信号!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="529"/>
        <source>NO2 blood pump selfcheck fail!</source>
        <translation>血泵2自检失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="531"/>
        <source>Heparin error</source>
        <translation>肝素泵出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="536"/>
        <source>N7 error</source>
        <translation>N7出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="539"/>
        <source>N9 error</source>
        <translation>N9出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="542"/>
        <source>N10 error</source>
        <translation>N10出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="545"/>
        <source>N15 error</source>
        <translation>N15出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="548"/>
        <source>N5 error</source>
        <translation>N5出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="559"/>
        <source>some error</source>
        <translation>其他错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="560"/>
        <source>Please check alarm code!</source>
        <translation>请检查报警代码！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="584"/>
        <source>N3 communication failure</source>
        <translation>N3通信失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="587"/>
        <source>N5 communication failure</source>
        <translation>N5通信失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="590"/>
        <source>N9 communication failure</source>
        <translation>N9通信失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="593"/>
        <source>N10 communication failure</source>
        <translation>N10通信失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="596"/>
        <source>N15 communication failure</source>
        <translation>N15通信失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="599"/>
        <source>N7 communication failure</source>
        <translation>N7通信失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="602"/>
        <source>The patient calls</source>
        <translation>病人呼叫</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="603"/>
        <source>Patients with emergency call !</source>
        <translation>病人紧急呼叫!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="605"/>
        <source>water working abnormal</source>
        <translation>水路工作异常</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="606"/>
        <source>Master plate water problem!</source>
        <translation>主控板水路状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="608"/>
        <source>Single time alarm</source>
        <translation>单次定时报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="609"/>
        <source>Single timeout !</source>
        <translation>单次定时时间到</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="611"/>
        <source>Cycle time alarm</source>
        <translation>循环定时报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="612"/>
        <source>Cycle timeout !</source>
        <translation>循环定时时间到</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="615"/>
        <source>Manual preflush state error</source>
        <translation>手动预冲状态出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="616"/>
        <source>Master plate manual preflush state error!</source>
        <translation>主控板手动预冲状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="618"/>
        <source>Auto preflush state error</source>
        <translation>自动预冲状态出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="619"/>
        <source>Master plate auto preflush state error!</source>
        <translation>主控板自动预冲状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="621"/>
        <source>Online preflush state error</source>
        <translation>在线预冲状态错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="622"/>
        <source>Master plate online preflush state error!</source>
        <translation>主控板在线自动预冲状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="624"/>
        <source>Connect P.t state error</source>
        <translation>引血状态出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="625"/>
        <source>Master plate Connect P.t state error!</source>
        <translation>主控板引血状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="627"/>
        <source>Online connect P.t state error</source>
        <translation>在线引血状态错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="628"/>
        <source>Master plate Online connect P.t state error!</source>
        <translation>主控板在线引血状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="630"/>
        <source>Return blood state error</source>
        <translation>回血状态错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="631"/>
        <source>Master plate Return blood state error!</source>
        <translation>主控板回血状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="633"/>
        <source>Online return blood state error</source>
        <translation>在线回血状态错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="634"/>
        <source>Master plate Online return blood state error!</source>
        <translation>主控板在线回血状态出错!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="670"/>
        <source>XML file error</source>
        <translation>XML文件错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="671"/>
        <source>xml file read error,the param is:</source>
        <translation>以下xml文件参数读取错误：</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="692"/>
        <source>Cond Record Data</source>
        <translation>电导记录数据</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="693"/>
        <source>Temp Record Data</source>
        <translation>温度记录数据</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="706"/>
        <source>Save success!</source>
        <translation>保存成功</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="707"/>
        <source>Whether to Restore xml file?</source>
        <translation>是否恢复原XML文件?</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="712"/>
        <source>UF_Goal</source>
        <translation>超滤目标值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="713"/>
        <source>UF_Rate</source>
        <translation>超滤速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="714"/>
        <source>UF_Time</source>
        <translation>超滤时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="715"/>
        <source>Earlier_Time</source>
        <translation>提前结束时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="716"/>
        <source>AutoChange_Limit</source>
        <translation>自动变化限制</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="718"/>
        <source>Dia_Temp</source>
        <translation>透析液温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="719"/>
        <source>Dia_Cond</source>
        <translation>透析液电导</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="720"/>
        <source>Dia_Rate</source>
        <translation>透析液流速</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="721"/>
        <source>Dia_OnlineRate</source>
        <translation>透析液在线流速</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="723"/>
        <source>BP_Width</source>
        <translation>血泵管径</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="724"/>
        <source>BP_RateCheckSelf</source>
        <translation>血泵自检速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="725"/>
        <source>BP_RateThreatMent</source>
        <translation>血泵治疗速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="726"/>
        <source>BP_RateReturnBlood</source>
        <translation>血泵回血速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="727"/>
        <source>BP_RatePreflush</source>
        <translation>血泵预冲速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="728"/>
        <source>BP_RateGetBlood</source>
        <translation>血泵引血速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="730"/>
        <source>First_Volume</source>
        <translation>首剂量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="731"/>
        <source>Heparin_Rate</source>
        <translation>肝素速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="732"/>
        <source>Pre_StopTime</source>
        <translation>预先停止时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="733"/>
        <source>Add_Volume</source>
        <translation>追加量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="735"/>
        <source>SubPump_Flux</source>
        <translation>置换泵流速</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="736"/>
        <source>SubPump_Goal</source>
        <translation>置换泵目标</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="737"/>
        <source>SubPump_RapidRate</source>
        <translation>快速补液速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="739"/>
        <source>Hour</source>
        <translation>小时</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="740"/>
        <source>Min</source>
        <translation>分钟</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="742"/>
        <source>BpRate_First_FiveMin</source>
        <translation>预冲血泵速（前5分钟）</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="743"/>
        <source>BpRate</source>
        <translation>预冲血泵速</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="744"/>
        <source>Dialyser_Rate</source>
        <translation>透析液流量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="745"/>
        <location filename="../../src/common/common_tr_string.h" line="761"/>
        <source>Preflush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="746"/>
        <source>PF_UF_Rate</source>
        <translation>预冲超滤率</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="747"/>
        <source>PF_UF_Volume</source>
        <translation>预冲超滤量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="748"/>
        <source>PF_Volume</source>
        <translation>预冲总量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="749"/>
        <source>BpRate_Conect</source>
        <translation>连接患者时血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="750"/>
        <source>BpRate_phase1</source>
        <translation>第一阶段血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="751"/>
        <source>BpRate_phase2</source>
        <translation>第二阶段血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="752"/>
        <source>BpRate_phase3</source>
        <translation>第三阶段血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="753"/>
        <source>TMPUp_PF</source>
        <translation>跨膜压上限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="755"/>
        <location filename="../../src/common/common_tr_string.h" line="762"/>
        <source>Loop_Time</source>
        <translation>循环时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="758"/>
        <source>TargetTemp</source>
        <translation>目标温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="759"/>
        <source>RealTemp</source>
        <translation>走时温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="763"/>
        <source>Hold_Time</source>
        <translation>滞留时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="764"/>
        <source>BackFlush_Time</source>
        <translation>后冲时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="765"/>
        <source>Flush_Flux</source>
        <translation>冲洗速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="766"/>
        <source>Loop_Flux</source>
        <translation>循环速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="767"/>
        <source>Target_Temp</source>
        <translation>目标温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="768"/>
        <source>Real_Temp</source>
        <translation>走时温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="772"/>
        <source>Blood Pump</source>
        <translation>血泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="773"/>
        <source>Sub Pump</source>
        <translation>置换泵（第二血泵）</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="774"/>
        <source>Function Pump</source>
        <translation>功能泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="775"/>
        <source>Heparin Pump</source>
        <translation>肝素泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="776"/>
        <source>PRESSURE</source>
        <translation>压力</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="777"/>
        <source>Air bubblies</source>
        <translation>气泡</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="778"/>
        <source>Liquid</source>
        <translation>液位</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="779"/>
        <source>BLood monitor</source>
        <translation>漏血检测</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="780"/>
        <source>Choke clip</source>
        <translation>阻流夹</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="781"/>
        <source>Sound light</source>
        <translation>声光</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="784"/>
        <source>Common</source>
        <translation>公共</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="785"/>
        <source>No water time</source>
        <translation>无液时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="786"/>
        <source>Set flow</source>
        <translation>设置流量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="788"/>
        <source>Not revised value</source>
        <translation>未修正值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="789"/>
        <source>Send value</source>
        <translation>发送值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="790"/>
        <source>Show value</source>
        <translation>显示值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="792"/>
        <source>B Temp</source>
        <translation>B液温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="793"/>
        <source>Mix Temp</source>
        <translation>混合温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="794"/>
        <source>Outlet Temp</source>
        <translation>出水口温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="795"/>
        <source>After Temp</source>
        <translation>透后温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="796"/>
        <source>Heater Temp</source>
        <translation>加热腔温度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="797"/>
        <source>B Cond</source>
        <translation>B液电导</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="798"/>
        <source>Mix Cond</source>
        <translation>混合电导</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="799"/>
        <source>Outlet Cond</source>
        <translation>出水口电导</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="800"/>
        <source>After Cond</source>
        <translation>透后电导</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="801"/>
        <source>Disinfect Cond</source>
        <translation>消毒液电导</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="802"/>
        <source>BloodLeak</source>
        <translation>漏血检测</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="803"/>
        <source>UF Pump</source>
        <translation>超滤泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="804"/>
        <source>Dialystate Flow</source>
        <translation>透析液流速</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="805"/>
        <source>Circulate Pump</source>
        <translation>循环泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="806"/>
        <source>Before Pump</source>
        <translation>透前泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="807"/>
        <source>After Pump</source>
        <translation>透后泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="808"/>
        <source>A Pump</source>
        <translation>A液泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="809"/>
        <source>B Pump</source>
        <translation>B液泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="810"/>
        <source>Valve Check</source>
        <translation>阀门检测</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="813"/>
        <source>Set Formula</source>
        <translation>配方设定</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="814"/>
        <source>Front-back Pump</source>
        <translation>透前透后泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="815"/>
        <source>Degassing Pump</source>
        <translation>除气泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="817"/>
        <source>AB Pump</source>
        <translation>AB泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="818"/>
        <source>Temp Adjust</source>
        <translation>温度调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="819"/>
        <source>Cond Adjust</source>
        <translation>电导调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="833"/>
        <source>Control Water Graph</source>
        <translation>可控水路图</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="863"/>
        <source>If there a bloodleak alarm:</source>
        <translation>是否有漏血报警:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="864"/>
        <source>Blood Leak Limit</source>
        <translation>漏血报警限值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="865"/>
        <source>Set BLood Leak Limit</source>
        <translation>设置漏血报警限值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="887"/>
        <location filename="../../src/common/common_tr_string.h" line="899"/>
        <source>Stop discharge test</source>
        <translation>停止放电测试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="893"/>
        <source>Charging</source>
        <translation>充电中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="894"/>
        <source>Charge complete</source>
        <translation>充电完成</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="895"/>
        <source>Pre boot</source>
        <translation>预开机</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="896"/>
        <source>Normal</source>
        <translation>正常</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="897"/>
        <source>Reserve</source>
        <translation>后备</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="898"/>
        <source>Discharge testing</source>
        <translation>放电测试中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="908"/>
        <source>Blocking/Up Sensor:</source>
        <translation>阻塞/上限传感器:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="909"/>
        <source>Down Sensor:</source>
        <translation>下限传感器:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="911"/>
        <source>Length of syringe</source>
        <translation>注射器长度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="912"/>
        <source>Syringe capacity</source>
        <translation>注射器容量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="917"/>
        <source>Click</source>
        <translation>点击</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="918"/>
        <source>Pump</source>
        <translation>泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="919"/>
        <source>Should be set</source>
        <translation>应该设置</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="930"/>
        <source>Speed</source>
        <translation>速度</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="931"/>
        <source>Pipe</source>
        <translation>管径</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="932"/>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="933"/>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="935"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="937"/>
        <source>Cavity Value</source>
        <translation>腔数</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="938"/>
        <source>Cavity Capacity</source>
        <translation>腔量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="940"/>
        <source>Speed Select</source>
        <translation>速度选择</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="941"/>
        <source>Low</source>
        <translation>低</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="942"/>
        <source>Mid</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="943"/>
        <source>High</source>
        <translation>高</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="944"/>
        <source>Other Use</source>
        <translation>其他操作</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="946"/>
        <source>Basic Value</source>
        <translation>理论量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="947"/>
        <source>Real Value</source>
        <translation>实际量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="950"/>
        <source>Send Ok</source>
        <translation>发送完毕</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="952"/>
        <source>Rapid Up</source>
        <translation>快速上推</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="953"/>
        <source>Rapid Down</source>
        <translation>快速下推</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="956"/>
        <source>First Dose</source>
        <translation>首剂量</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="959"/>
        <source>TMP Current Value:</source>
        <translation>跨膜压当前值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="963"/>
        <source>Degassing Value:</source>
        <translation>除气泵值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="974"/>
        <source>Send param finish!</source>
        <translation>参数发送完毕</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="975"/>
        <source>Send param fail !</source>
        <translation>参数发送失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="980"/>
        <source>Test runing</source>
        <translation>测试进行中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="981"/>
        <source>Test stop</source>
        <translation>测试终止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="982"/>
        <source>Test finish</source>
        <translation>测试完成</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="984"/>
        <source>A Pump testing,please stop !</source>
        <translation>A液泵测试中，请先停止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="985"/>
        <source>B Pump testing,please stop !</source>
        <translation>B液泵测试中，请先停止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="987"/>
        <source>Running state of the water</source>
        <translation>水路运行状态</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="988"/>
        <source>The state of Bloodleadcheck</source>
        <translation>漏血检测状态</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="990"/>
        <source>B Temp Feedback</source>
        <translation>B液温度反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="991"/>
        <source>Set B Temp Feedback</source>
        <translation>B液反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="993"/>
        <source>Mix Temp Feedback</source>
        <translation>混合温度反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="994"/>
        <source>Set Mix Temp Feedback</source>
        <translation>混合温度反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="996"/>
        <source>Mix Cond Feedback</source>
        <translation>混合电导反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="997"/>
        <source>Set Mix Cond Feedback</source>
        <translation>混合电导反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1000"/>
        <source>Outlet Temp Feedback</source>
        <translation>出水口温度反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1001"/>
        <source>Set Outlet Temp Feedback</source>
        <translation>出水口温度反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1003"/>
        <source>Outlet Cond Feedback</source>
        <translation>出水口电导反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1004"/>
        <source>Set Outlet Cond Feedback</source>
        <translation>出水口电导反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1006"/>
        <source>After Temp Feedback</source>
        <translation>透后温度反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1007"/>
        <source>Set After Temp Feedback</source>
        <translation>透后温度反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1009"/>
        <source>After Cond Feedback</source>
        <translation>透后电导反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1010"/>
        <source>Set After Cond Feedback</source>
        <translation>透后电导反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1012"/>
        <source>Disinfect Cond Feedback</source>
        <translation>消毒液电导反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1013"/>
        <source>Set Disinfect Cond Feedback</source>
        <translation>消毒液电导反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1015"/>
        <source>Feedback</source>
        <translation>反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1016"/>
        <source>Current feedback</source>
        <translation>当前反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1017"/>
        <source>Feedback alarm threshold</source>
        <translation>反馈报警阀值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1018"/>
        <source>Set alarm threshold</source>
        <translation>报警阀值设置</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1019"/>
        <source>Feedback 100 Cavity</source>
        <translation>反馈100腔体值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1020"/>
        <source>Alarm upper limit</source>
        <translation>报警上限值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1021"/>
        <source>Set  Feedback</source>
        <translation>设置反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1023"/>
        <source>Heater Temp Feedback</source>
        <translation>加热腔温度反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1024"/>
        <source>Set Heater Temp Feedback</source>
        <translation>加热腔温度反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1026"/>
        <source>B Cond Feedback</source>
        <translation>B液电导反馈值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1027"/>
        <source>Set B Cond Feedback</source>
        <translation>B液电导反馈设置值</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1030"/>
        <source>Note: please click to read the parameters before debugging.</source>
        <translation>注意:调试前请先点击读取参数.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1031"/>
        <source>1.Select high speed or low speed, click start test,read the pulse.</source>
        <translation>1.选择高速或者低速，点击开始测试，读取脉冲.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1033"/>
        <source>2.If the theory of pulse and pulse actual gap is too big, then click start since the correction.</source>
        <translation>2.如果理论脉冲和实际脉冲差距过大，则点击开始自校正.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1035"/>
        <source>3.Prepare a measuring cup, make sure good pipe diameter and time,click start.</source>
        <translation>3.准备好量杯，确定好管径和时间，点击开始.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1037"/>
        <source>4.The measuring cup measure when feedback input, and click the correction.</source>
        <translation>4.将量杯的量当反馈量输入，并点击校正.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1042"/>
        <source>1.Observe the heparin pump button status and alarm information is correct.</source>
        <translation>1.观察肝素泵的按键状态和报警信息是否正确.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1044"/>
        <source>2.According to the actual situation, set up syringes length and capacity.</source>
        <translation>2.根据实际情况设置注射器长度和容量.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1046"/>
        <source>3.Prepare a measuring cup, make sure good speed and time, click start, and input the actual measured values, click send.</source>
        <translation>3.准备好量杯，确定好速度和时间，点击启动，输入实际测量值，点击发送进行校正.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1048"/>
        <source>4.Determine the good starting dose, click start, and input the actual measured values, click send.</source>
        <translation>4.确定好首剂量，点击启动，输入实际测量值，点击发送进行校正.</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1052"/>
        <source>1.The pressure value, based on the current equipment real-time pressure, dynamic update the display.</source>
        <translation>1.各压力值，根据当前设备实时压力情况，动态更新显示.</translation>
    </message>
    <message>
        <source>Alarm sound</source>
        <translation type="obsolete">报警音</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="782"/>
        <source>Light</source>
        <translation>灯光</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="783"/>
        <source>Bat and power</source>
        <translation>电池和电源</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="822"/>
        <location filename="../../src/common/common_tr_string.h" line="843"/>
        <source>Blood Debug</source>
        <translation>血路调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="823"/>
        <source>Water Debug</source>
        <translation>水路调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="824"/>
        <source>User Param</source>
        <translation>用户参数</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="825"/>
        <source>Project Param</source>
        <translation>工程参数</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="826"/>
        <source>Setup Param</source>
        <translation>设置参数</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="827"/>
        <source>Drain Option</source>
        <translation>排水操作</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="828"/>
        <source>Ts Debug</source>
        <translation>触摸屏调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="829"/>
        <source>Water Test</source>
        <translation>水路测试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="830"/>
        <source>Use Time</source>
        <translation>使用时间</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="832"/>
        <source>Reset Defaults</source>
        <translation>恢复出厂设置</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="834"/>
        <source>Turn Off</source>
        <translation>关机</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="836"/>
        <source>pre</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="837"/>
        <source>next</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="842"/>
        <source>Read Param</source>
        <translation>读取参数</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="844"/>
        <source>BloodPump Debug</source>
        <translation>血泵调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="845"/>
        <source>SubPump Debug</source>
        <translation>置换泵调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="846"/>
        <source>HeparinPump Debug</source>
        <translation>肝素泵调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="847"/>
        <source>Pressure Debug</source>
        <translation>压力调试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="848"/>
        <source>Check Bubble</source>
        <translation>气泡检测</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="849"/>
        <source>Check Choke Clip</source>
        <translation>检测阻流夹</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="850"/>
        <source>Sound and light detecting</source>
        <translation>声光检测</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="851"/>
        <source>Battery supply</source>
        <translation>电池电源</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="853"/>
        <source>Liquid Status</source>
        <translation>液位状态</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="854"/>
        <source>Liquid Alarm Status:</source>
        <translation>液位报警状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="855"/>
        <source>Liquid Raised Key:</source>
        <translation>液位上调键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="856"/>
        <source>Liquid Reduce Key:</source>
        <translation>液位下调键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="858"/>
        <source>Blood Detection</source>
        <translation>血液检测</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="859"/>
        <source>Artery Status:</source>
        <translation>动脉检测状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="860"/>
        <source>Vein Status:</source>
        <translation>静脉检测状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="861"/>
        <source>Have Blood</source>
        <translation>有血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="862"/>
        <source>No Blood</source>
        <translation>无血</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="867"/>
        <source>Artery Clip Status:</source>
        <translation>动脉阻流夹状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="868"/>
        <source>Vein Clip Status:</source>
        <translation>静脉阻流夹状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="869"/>
        <source>ON/OFF Key:</source>
        <translation>开关按键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="870"/>
        <source>Monitoring sensor value:</source>
        <translation>监测传感器值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="873"/>
        <source>State of sound:</source>
        <translation>声音状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="874"/>
        <source>Volume:</source>
        <translation>音量大小:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="875"/>
        <source>Macron</source>
        <translation>长音</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="876"/>
        <source>Mediant</source>
        <translation>中音</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="877"/>
        <source>Tone pips</source>
        <translation>短音</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="878"/>
        <source>State of alarmlight:</source>
        <translation>报警灯状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="880"/>
        <source>Red</source>
        <translation>红</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="881"/>
        <source>Yellow</source>
        <translation>黄</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="882"/>
        <source>Green</source>
        <translation>绿</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="884"/>
        <source>Battery status:</source>
        <translation>电池状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="885"/>
        <source>Power status:</source>
        <translation>电源状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="886"/>
        <source>Bat discharge test</source>
        <translation>电池放电测试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="888"/>
        <source>The last stop of blood pump:</source>
        <translation>上次停血泵时间:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="889"/>
        <source>The last time of battery discharge:</source>
        <translation>上次电池放电时间:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="890"/>
        <source>Blood pump speed:</source>
        <translation>血泵速度:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="891"/>
        <source>Heparin pump speed:</source>
        <translation>肝素速度:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="901"/>
        <source>Door Status:</source>
        <translation>门盖状态:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="902"/>
        <source>Start Key:</source>
        <translation>启动键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="903"/>
        <source>+Key:</source>
        <translation>+键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="904"/>
        <source>-Key:</source>
        <translation>-键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="905"/>
        <source>Up Key:</source>
        <translation>向上键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="906"/>
        <source>Down Key:</source>
        <translation>向下键:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="907"/>
        <source>Up Alarm:</source>
        <translation>上限报警:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="910"/>
        <source>Down Alarm:</source>
        <translation>下限报警:</translation>
    </message>
    <message>
        <source>Length of syringe:</source>
        <translation type="obsolete">注射器长度:</translation>
    </message>
    <message>
        <source>Syringe capacity:</source>
        <translation type="obsolete">注射器容量:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="913"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="914"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="915"/>
        <source>Press</source>
        <translation>点击</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="916"/>
        <source>Release</source>
        <translation>释放</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="922"/>
        <source>HSpeed</source>
        <translation>高速</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="923"/>
        <source>LSpeed</source>
        <translation>低速</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="924"/>
        <source>Basic Pulse:</source>
        <translation>理论脉冲:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="925"/>
        <source>Real Pulse:</source>
        <translation>实际脉冲:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="926"/>
        <source>Start Test</source>
        <translation>开始测试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="927"/>
        <source>Stop Test</source>
        <translation>停止测试</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="928"/>
        <source>Start Adjust</source>
        <translation>开始自校正</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="929"/>
        <source>Stop Adjust</source>
        <translation>停止校正</translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation type="obsolete">速度:</translation>
    </message>
    <message>
        <source>Pipe:</source>
        <translation type="obsolete">管径:</translation>
    </message>
    <message>
        <source>Time:</source>
        <translation type="obsolete">时间:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="934"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="936"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <source>Basic Value:</source>
        <translation type="obsolete">理论量:</translation>
    </message>
    <message>
        <source>Real Value:</source>
        <translation type="obsolete">实际量:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="948"/>
        <source>Adjust</source>
        <translation>校正</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="949"/>
        <source>Send</source>
        <translation>发送</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="955"/>
        <source>Runing status:</source>
        <translation>运行状态:</translation>
    </message>
    <message>
        <source>First Dose:</source>
        <translation type="obsolete">首剂量:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="957"/>
        <source>AP Current Value:</source>
        <translation>动脉压当前值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="958"/>
        <source>VP Current Value:</source>
        <translation>静脉压当前值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="960"/>
        <source>WP Current Value:</source>
        <translation>水路压当前值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="961"/>
        <source>Degassing Pressure:</source>
        <translation>排气压当前值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="962"/>
        <source>PSN Pressure:</source>
        <translation>PSN压当前值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="964"/>
        <source>If there is a bubble alarm:</source>
        <translation>是否有气泡报警:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="965"/>
        <source>Tiny bubbles accumulation limit:</source>
        <translation>微小气泡累积极限:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="966"/>
        <source>Set accumulation limit:</source>
        <translation>设置累积极限:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="967"/>
        <source>Bubble pulse width alarm threshold:</source>
        <translation>气泡脉宽报警限值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="968"/>
        <source>Set pulse width alarm threshold:</source>
        <translation>设置脉宽报警限值:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="970"/>
        <source>Param reading,please wait!</source>
        <translation>参数正在读取，请稍等!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="971"/>
        <source>Read param fail!</source>
        <translation>参数读取失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="972"/>
        <source>Read param sucess!</source>
        <translation>参数读取成功!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="973"/>
        <source>Has not been read parameters, please click to Read Param!</source>
        <translation>尚未读取参数，请点击读取!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="977"/>
        <source>Pump Runing</source>
        <translation>泵运行中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="978"/>
        <source>Pump Stop</source>
        <translation>泵停止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="979"/>
        <source>Pump Adjust</source>
        <translation>泵校正中</translation>
    </message>
    <message>
        <source>Systolic range alarm</source>
        <translation type="obsolete">收缩压范围报警</translation>
    </message>
    <message>
        <source>Systolic beyond the upper limit or lower limit!</source>
        <translation type="obsolete">收缩压超过上限或下限!</translation>
    </message>
    <message>
        <source>Diastolic range alarm</source>
        <translation type="obsolete">舒张压范围报警</translation>
    </message>
    <message>
        <source>Diastolic beyond the upper limit or lower limit!</source>
        <translation type="obsolete">舒张压超过上限或下限!</translation>
    </message>
    <message>
        <source>Pulse range alarm</source>
        <translation type="obsolete">脉搏范围报警</translation>
    </message>
    <message>
        <source>Pulse beyond the upper limit or lower limit!</source>
        <translation type="obsolete">脉搏超过上限或下限!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="680"/>
        <source>BPM runing...</source>
        <translation>BPM测量中</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="683"/>
        <source>Residue time less than heparinPrestop time,heparin will not run!</source>
        <translation>剩余时间比肝素预停止时间少，肝素将停止!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="684"/>
        <source>Cure time has changed,profile cancel!</source>
        <translation>治疗时间改变，曲线治疗取消!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="685"/>
        <source>Workmode has changed,profile cancel!</source>
        <translation>工作模式改变，曲线治疗取消!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="686"/>
        <source>UF Aimvol has changed,uf profile cancel!</source>
        <translation>超滤目标改变，曲线治疗取消！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="687"/>
        <source>The remaining time too little, uf volume can not reach,uf profile cancel!</source>
        <translation>剩余时间内，超滤目标无法达到，UF曲线治疗取消！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="690"/>
        <source>Cond Record Profile</source>
        <translation>电导记录曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="691"/>
        <source>Temp Record Profile</source>
        <translation>温度记录曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="696"/>
        <source>Has select profile cure,profile num:</source>
        <translation>已选择曲线治疗，曲线号为：</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="697"/>
        <source>Profile cure runing,profile num:</source>
        <translation>曲线治疗运行中，曲线号为:</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="698"/>
        <source>Not select profile cure</source>
        <translation>未选择曲线治疗</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="702"/>
        <source>Na cure predefined modify</source>
        <translation>预定义钠曲线修改</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="703"/>
        <source>UF cure predefined modify</source>
        <translation>预定义UF曲线修改</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="704"/>
        <source>Na precure</source>
        <translation>钠曲线</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="705"/>
        <source>Uf precure</source>
        <translation>UF曲线</translation>
    </message>
    <message>
        <source>Cond record curve</source>
        <translation type="obsolete">电导记录曲线</translation>
    </message>
    <message>
        <source>Temp record curve</source>
        <translation type="obsolete">温度记录曲线</translation>
    </message>
    <message>
        <source>05001:CLPV error</source>
        <translation type="obsolete">05001:静脉管夹出错</translation>
    </message>
    <message>
        <source>05002:CLPA error</source>
        <translation type="obsolete">05002:动脉管夹出错</translation>
    </message>
    <message>
        <source>05003:ADPV error</source>
        <translation type="obsolete">05003:静脉气泡探测器出错</translation>
    </message>
    <message>
        <source>05004:ADPA error</source>
        <translation type="obsolete">05004:动脉气泡探测器出错</translation>
    </message>
    <message>
        <source>05005:LDS error</source>
        <translation type="obsolete">05005:液位探测器出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="496"/>
        <location filename="../../src/common/common_tr_string.h" line="499"/>
        <location filename="../../src/common/common_tr_string.h" line="502"/>
        <source>The zero offset is too large!</source>
        <translation>零点漂移过大!</translation>
    </message>
    <message>
        <source>05009:BLM error</source>
        <translation type="obsolete">5006:漏血探测器出错 {05009:?}</translation>
    </message>
    <message>
        <source>05010:BOM error</source>
        <translation type="obsolete">5007:血氧模块出错 {05010:?}</translation>
    </message>
    <message>
        <source>05011:BPM error</source>
        <translation type="obsolete">5007:血压模块出错 {05011:?}</translation>
    </message>
    <message>
        <source>05006:BLM error</source>
        <translation type="obsolete">05006:漏血探测器出错</translation>
    </message>
    <message>
        <source>05007:BOM error</source>
        <translation type="obsolete">05007:血氧模块出错</translation>
    </message>
    <message>
        <source>05007:BPM error</source>
        <translation type="obsolete">05007:血压模块出错</translation>
    </message>
    <message>
        <source>09032:BLOOD1 error</source>
        <translation type="obsolete">09032:血泵1出错</translation>
    </message>
    <message>
        <source>09064:BLOOD1 error</source>
        <translation type="obsolete">09064:血泵1出错</translation>
    </message>
    <message>
        <source>09128:BLOOD1 error</source>
        <translation type="obsolete">09128:血泵1出错</translation>
    </message>
    <message>
        <source>5001:CLPV error</source>
        <translation type="obsolete">5001:静脉管夹出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="481"/>
        <source>CLPV drive or flow resistance feedback!</source>
        <translation>静脉管夹驱动或反馈有问题！</translation>
    </message>
    <message>
        <source>5002:CLPA error</source>
        <translation type="obsolete">5002:动脉管夹出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="484"/>
        <source>CLPA drive or flow resistance feedback!</source>
        <translation>动脉管夹驱动或反馈有问题！</translation>
    </message>
    <message>
        <source>5003:ADPV error</source>
        <translation type="obsolete">5003:静脉气泡探测器出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="487"/>
        <location filename="../../src/common/common_tr_string.h" line="490"/>
        <location filename="../../src/common/common_tr_string.h" line="493"/>
        <source>Remove the line!</source>
        <translation>移走管路!</translation>
    </message>
    <message>
        <source>5004:ADPA error</source>
        <translation type="obsolete">5004:动脉气泡探测器出错</translation>
    </message>
    <message>
        <source>5005:LDS error</source>
        <translation type="obsolete">5005:液位探测器出错</translation>
    </message>
    <message>
        <source>5006:BLM error</source>
        <translation type="obsolete">5006:漏血探测器出错</translation>
    </message>
    <message>
        <source>5007:BOM error</source>
        <translation type="obsolete">5007:血氧模块出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="508"/>
        <source>No blood oxygen module or communication failures!</source>
        <translation>没有血氧模块或通讯故障!</translation>
    </message>
    <message>
        <source>5007:BPM error</source>
        <translation type="obsolete">5007:血压模块出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="511"/>
        <source>No Blood pressure module or communication failures!</source>
        <translation>没有血压模块或通讯故障!</translation>
    </message>
    <message>
        <source>9032:BLOOD1 error</source>
        <translation type="obsolete">9032:血泵1出错</translation>
    </message>
    <message>
        <source>9064:BLOOD1 error</source>
        <translation type="obsolete">9064:血泵1出错</translation>
    </message>
    <message>
        <source>9128:BLOOD1 error</source>
        <translation type="obsolete">9128:血泵1出错</translation>
    </message>
    <message>
        <source>15153:Heparin error</source>
        <translation type="obsolete">15153:肝素泵出错</translation>
    </message>
    <message>
        <source>03001:N7 error</source>
        <translation type="obsolete">03001:N7出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="537"/>
        <source>N7 selfcheck fail!</source>
        <translation>N7自检失败!</translation>
    </message>
    <message>
        <source>03002:N9 error</source>
        <translation type="obsolete">03002:N9出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="540"/>
        <source>N9 selfcheck fail!</source>
        <translation>N9自检失败!</translation>
    </message>
    <message>
        <source>03003:N10 error</source>
        <translation type="obsolete">03003:N10出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="543"/>
        <source>N10 selfcheck fail!</source>
        <translation>N10自检失败!</translation>
    </message>
    <message>
        <source>03004:N15 error</source>
        <translation type="obsolete">03004:N15出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="546"/>
        <source>N15 selfcheck fail!</source>
        <translation>N15自检失败!</translation>
    </message>
    <message>
        <source>03005:N5 error</source>
        <translation type="obsolete">03005:N5出错</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="549"/>
        <source>N5 selfcheck fail!</source>
        <translation>N5自检失败!</translation>
    </message>
    <message>
        <source>Blood pump out of control</source>
        <translation type="obsolete">血泵失控</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="341"/>
        <source>No1 blood pump out of control !</source>
        <translation>血泵1失控！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="343"/>
        <source>No2 blood pump out of control</source>
        <translation>血泵2失控</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="344"/>
        <source>No2 blood pump out of control !</source>
        <translation>血泵2失控！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="346"/>
        <source>Please close blood pump door</source>
        <translation>血泵1盖门打开</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="347"/>
        <source>Please close blood pump door!</source>
        <translation>请关闭血泵1门盖！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="349"/>
        <source>Please close spare pump door</source>
        <translation>血泵2盖门打开</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="350"/>
        <source>Please close spare pump door!</source>
        <translation>请关闭血泵2门盖！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="352"/>
        <source>Blood Leak</source>
        <translation>漏血报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="353"/>
        <source>Blood Leak !</source>
        <translation>漏血报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="355"/>
        <source>Heparin empty Or  block</source>
        <translation>肝素空液或阻塞</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="356"/>
        <source>Heparin empty Or  block !</source>
        <translation>肝素空液或阻塞！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="358"/>
        <source>Blood pressure monitor alarm</source>
        <translation>血压计报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="359"/>
        <source>Blood pressure monitor alarm !</source>
        <translation>血压计报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="361"/>
        <location filename="../../src/common/common_tr_string.h" line="364"/>
        <source>The pressure before the dialyzer</source>
        <translation>透析器前压力报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="362"/>
        <source>The pressure before the dialyzer upper limit !</source>
        <translation>透析器前压力上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="365"/>
        <source>The pressure before the dialyzer lower limit !</source>
        <translation>透析器前压力下限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="369"/>
        <location filename="../../src/common/common_tr_string.h" line="372"/>
        <source>The water outlet Conductivity</source>
        <translation>出水口电导</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="370"/>
        <source>The water outlet of the upper limit of Conductivity !</source>
        <translation>出水口总电导度上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="373"/>
        <source>The water outlet of the lower limit of the Conductivity !</source>
        <translation>出水口总电导度下限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="375"/>
        <source>Alarming of water outlet total Conductivity</source>
        <translation>出水口总电导度范围报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="376"/>
        <source>Alarming of water outlet total Conductivity !</source>
        <translation>出水口总电导度范围报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="378"/>
        <location filename="../../src/common/common_tr_string.h" line="381"/>
        <source>Alarming of the total Conductivity of mixed</source>
        <translation>混合总电导度报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="379"/>
        <source>The upper limit of the total Conductivity of mixed !</source>
        <translation>混合总电导度上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="382"/>
        <source>The lower limit of the total Conductivity of mixed !</source>
        <translation>混合总电导度下限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="384"/>
        <source>Hybrid total Conductivity alarm</source>
        <translation>混合总电导度报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="385"/>
        <source>Hybrid total Conductivity range alarm !</source>
        <translation>混合总电导度范围报警!</translation>
    </message>
    <message>
        <source>Selfcheck:NO1 choke clamp fault</source>
        <translation type="obsolete">自检:阻流夹1故障</translation>
    </message>
    <message>
        <source>Selfcheck:NO2 choke clamp fault</source>
        <translation type="obsolete">自检:阻流夹2故障</translation>
    </message>
    <message>
        <source>Selfcheck:Venous air failure</source>
        <translation type="obsolete">自检:静脉气泡故障</translation>
    </message>
    <message>
        <source>Selfcheck:Arterial bubble fault</source>
        <translation type="obsolete">自检:动脉气泡故障</translation>
    </message>
    <message>
        <source>Selfcheck:Level fault</source>
        <translation type="obsolete">自检:液位故障</translation>
    </message>
    <message>
        <source>Selfcheck:Blood leak monitor fault</source>
        <translation type="obsolete">自检:漏血监测故障</translation>
    </message>
    <message>
        <source>Selfcheck:Blood oxygen module fault</source>
        <translation type="obsolete">自检:血氧模块故障</translation>
    </message>
    <message>
        <source>Selfcheck:Blood pressure module fault</source>
        <translation type="obsolete">自检:血压模块故障</translation>
    </message>
    <message>
        <source>Selfcheck:NO1 blood pump is out of control</source>
        <translation type="obsolete">自检:血泵1失控</translation>
    </message>
    <message>
        <source>Selfcheck:NO1 blood pump no feedback</source>
        <translation type="obsolete">自检:血泵1无反馈信号</translation>
    </message>
    <message>
        <source>Selfcheck:NO1 blood pump selfcheck fail</source>
        <translation type="obsolete">自检:血泵1自检失败</translation>
    </message>
    <message>
        <source>Selfcheck:Heparin pump selfcheck fail</source>
        <translation type="obsolete">自检:肝素泵故障</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="552"/>
        <source>Selfcheck:Part of the blood selfcheck fail</source>
        <translation>自检:血路自检失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="555"/>
        <source>Selfcheck:Part of the water selfcheck fail</source>
        <translation>自检:水路自检失败</translation>
    </message>
    <message>
        <source>The water outlet conductance</source>
        <translation type="obsolete">出水口总电导度报警</translation>
    </message>
    <message>
        <source>The water outlet of the upper limit of conductance !</source>
        <translation type="obsolete">出水口总电导度上限！</translation>
    </message>
    <message>
        <source>The water outlet of the lower limit of the conductance !</source>
        <translation type="obsolete">出水口总电导度下限！</translation>
    </message>
    <message>
        <source>Alarming of water outlet total conductance</source>
        <translation type="obsolete">出水口总电导度范围报警</translation>
    </message>
    <message>
        <source>Alarming of water outlet total conductance !</source>
        <translation type="obsolete">出水口总电导度范围报警！</translation>
    </message>
    <message>
        <source>Alarming of the total conductance of mixed</source>
        <translation type="obsolete">混合总电导度报警</translation>
    </message>
    <message>
        <source>The upper limit of the total conductance of mixed !</source>
        <translation type="obsolete">混合总电导度上限！</translation>
    </message>
    <message>
        <source>The lower limit of the total conductance of mixed !</source>
        <translation type="obsolete">混合总电导度下限！</translation>
    </message>
    <message>
        <source>Hybrid total conductance alarm</source>
        <translation type="obsolete">混合总电导度上限</translation>
    </message>
    <message>
        <source>Hybrid total conductance range alarm !</source>
        <translation type="obsolete">混合总电导度上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="387"/>
        <source>Dialysis fluid temperature is higher than the limit</source>
        <translation>透析夜温度太高</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="388"/>
        <source>Dialysis fluid temperature is higher than the limit !</source>
        <translation>透析夜温度太高极限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="390"/>
        <source>Dialysis fluid temperature is below the limit</source>
        <translation>透析夜温度太低</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="391"/>
        <source>Dialysis fluid temperature is below the limit !</source>
        <translation>透析夜温度太低 极限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="393"/>
        <source>The upper temperature limit</source>
        <translation>温度上限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="394"/>
        <source>The upper temperature limit !</source>
        <translation>温度上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="396"/>
        <source>The lower limit of temperature</source>
        <translation>温度下限</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="397"/>
        <source>The lower limit of temperature !</source>
        <translation>温度下限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="399"/>
        <source>The range of temperature alarm</source>
        <translation>温度范围报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="400"/>
        <source>The range of temperature alarm !</source>
        <translation>温度范围报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="402"/>
        <source>A liquid conductivity error</source>
        <translation>A液电导率错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="403"/>
        <source>A liquid conductivity error !</source>
        <translation>A液电导率错误！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="405"/>
        <source>B liquid conductivity error</source>
        <translation>B液电导率错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="406"/>
        <source>B liquid conductivity error !</source>
        <translation>B液电导率错误！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="408"/>
        <source>No A dialysate</source>
        <translation>无A液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="409"/>
        <source>No A dialysate !</source>
        <translation>无A液！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="411"/>
        <source>No B dialysate</source>
        <translation>无B液</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="412"/>
        <source>No B dialysate !</source>
        <translation>无B液！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="414"/>
        <source>The alarm of no water</source>
        <translation>无水报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="415"/>
        <source>The alarm of no water !</source>
        <translation>无水报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="417"/>
        <source>Disinfection liquid conductivity toplimit error</source>
        <translation>消毒液电导上限错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="418"/>
        <source>Disinfection liquid conductivity toplimit error !</source>
        <translation>消毒液电导上限错误！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="420"/>
        <source>Disinfection liquid conductivity lower limit error</source>
        <translation>消毒液电导下限错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="421"/>
        <source>Disinfection liquid conductivity lower limit error !</source>
        <translation>消毒液电导下限错误！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="423"/>
        <source>Fluid degassing error</source>
        <translation>补液除气错误</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="424"/>
        <source>Fluid degassing error !</source>
        <translation>补液除气错误！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="426"/>
        <source>Balance cavity film breaking alarm</source>
        <translation>平衡腔破膜报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="427"/>
        <source>Balance cavity film breaking alarm !</source>
        <translation>平衡腔破膜报警！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="431"/>
        <source>Connect tube A to pot A</source>
        <translation>将A液吸管放到A液桶</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="432"/>
        <source>Connect tube A to pot A !</source>
        <translation>将A液吸管放到A液桶！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="434"/>
        <source>Connect tube A to machine</source>
        <translation>将A液吸管插回机器</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="435"/>
        <source>Connect tube A to machine !</source>
        <translation>将A液吸管插回机器！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="437"/>
        <source>Connect tube B to pot B</source>
        <translation>将B液管放到B液桶</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="438"/>
        <source>Connect tube B to pot B !</source>
        <translation>将B液管放到B液桶！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="440"/>
        <source>Connect tube B to machine</source>
        <translation>将B液管插回机器</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="441"/>
        <source>Connect tube B to machine !</source>
        <translation>将B液管插回机器！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="443"/>
        <source>Connect supply tube to dialyzer</source>
        <translation>将供液管接到透析器</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="444"/>
        <source>Connect supply tube to dialyzer !</source>
        <translation>将供液管接到透析器！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="446"/>
        <source>Connect supply tube to machine</source>
        <translation>将供液管接回机器</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="447"/>
        <source>Connect supply tube to machine !</source>
        <translation>将供液管接回机器！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="449"/>
        <source>Connect return tubes of dialyzer to the  port of dialyzer</source>
        <translation>将回液管接到透析器</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="450"/>
        <source>Connect return tubes of dialyzer to the  port of dialyzer !</source>
        <translation>将回液管接到透析器！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="452"/>
        <source>Connect return tubes of dialyzer to the  port of machine</source>
        <translation>将回液管接回机器</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="453"/>
        <source>Connect return tubes of dialyzer to the  port of machine!</source>
        <translation>将回液管接回机器！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="455"/>
        <source>Dry frame open</source>
        <translation>将干粉架打开</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="456"/>
        <source>Dry frame open !</source>
        <translation>将干粉架打开！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="458"/>
        <source>Dry frame close</source>
        <translation>将干粉架关闭</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="459"/>
        <source>Dry frame close !</source>
        <translation>将干粉架关闭！</translation>
    </message>
    <message>
        <source>NO1 choke clamp fault</source>
        <translation type="obsolete">阻流夹1故障</translation>
    </message>
    <message>
        <source>NO1 choke clamp fault!</source>
        <translation type="obsolete">阻流夹1故障!</translation>
    </message>
    <message>
        <source>NO2 choke clamp fault</source>
        <translation type="obsolete">阻流夹2故障</translation>
    </message>
    <message>
        <source>NO2 choke clamp fault!</source>
        <translation type="obsolete">阻流夹2故障!</translation>
    </message>
    <message>
        <source>Venous air failure</source>
        <translation type="obsolete">静脉气泡故障</translation>
    </message>
    <message>
        <source>Venous air failure!</source>
        <translation type="obsolete">静脉气泡故障!</translation>
    </message>
    <message>
        <source>Arterial bubble fault</source>
        <translation type="obsolete">动脉气泡故障</translation>
    </message>
    <message>
        <source>Arterial bubble fault!</source>
        <translation type="obsolete">动脉气泡故障!</translation>
    </message>
    <message>
        <source>Level fault</source>
        <translation type="obsolete">液位故障</translation>
    </message>
    <message>
        <source>Level fault!</source>
        <translation type="obsolete">液位故障!</translation>
    </message>
    <message>
        <source>Blood leak monitor fault</source>
        <translation type="obsolete">漏血监测器故障</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="505"/>
        <source>Blood leak monitor fault!</source>
        <translation>漏血监测器故障!</translation>
    </message>
    <message>
        <source>Blood oxygen module fault</source>
        <translation type="obsolete">血氧模块故障</translation>
    </message>
    <message>
        <source>Blood oxygen module fault!</source>
        <translation type="obsolete">血氧模块故障!</translation>
    </message>
    <message>
        <source>Blood pressure module fault</source>
        <translation type="obsolete">血压模块故障</translation>
    </message>
    <message>
        <source>Blood pressure module fault!</source>
        <translation type="obsolete">血压模块故障!</translation>
    </message>
    <message>
        <source>NO1 blood pump is out of control</source>
        <translation type="obsolete">血泵1失控</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="514"/>
        <source>NO1 blood pump is out of control!</source>
        <translation>血泵1失控!</translation>
    </message>
    <message>
        <source>NO1 blood pump no feedback</source>
        <translation type="obsolete">血泵1无反馈信号</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="517"/>
        <source>NO1 blood pump no feedback!</source>
        <translation>血泵1无反馈信号!</translation>
    </message>
    <message>
        <source>NO1 blood pump selfcheck fail</source>
        <translation type="obsolete">血泵1自检失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="520"/>
        <source>NO1 blood pump selfcheck fail!</source>
        <translation>血泵1自检失败!</translation>
    </message>
    <message>
        <source>Heparin pump selfcheck fail</source>
        <translation type="obsolete">肝素泵自检失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="532"/>
        <source>Heparin pump selfcheck fail!</source>
        <translation>肝素泵自检失败!</translation>
    </message>
    <message>
        <source>Part of the blood selfcheck fail</source>
        <translation type="obsolete">血路自检失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="553"/>
        <source>Part of the blood selfcheck fail!</source>
        <translation>血路自检失败!</translation>
    </message>
    <message>
        <source>Part of the water selfcheck fail</source>
        <translation type="obsolete">水路自检失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="556"/>
        <source>Part of the water selfcheck fail!</source>
        <translation>水路自检失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="564"/>
        <source>prompt</source>
        <translation>提示</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="566"/>
        <source>Blood or water</source>
        <translation>血路或水路</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="568"/>
        <source>Program prompts</source>
        <translation>程序提示</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="570"/>
        <source>The power</source>
        <translation>电源</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="572"/>
        <source>Blood pump</source>
        <translation>血泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="574"/>
        <source>Backup pump</source>
        <translation>备用泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="576"/>
        <source>Heparin pump</source>
        <translation>肝素泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="578"/>
        <source>Self check</source>
        <translation>自检</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="580"/>
        <source>The unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <source>N3 communication failure!</source>
        <translation type="obsolete">N3通信失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="585"/>
        <source>N3 canopen error!</source>
        <translation>N3 canopen通信失败!</translation>
    </message>
    <message>
        <source>N5 communication failure!</source>
        <translation type="obsolete">N5通信失败</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="588"/>
        <source>N5 canopen error!</source>
        <translation>N5 canopen通信失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="591"/>
        <source>N9 canopen error!</source>
        <translation>N9 canopen通信失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="594"/>
        <source>N10 canopen error!</source>
        <translation>N10 canopen通信失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="597"/>
        <source>N15 canopen error!</source>
        <translation>N15 canopen通信失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="600"/>
        <source>N7 canopen error!</source>
        <translation>N7 canopen通信失败!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="637"/>
        <source>Systolic upper limit alarm</source>
        <translation>收缩压上限报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="638"/>
        <source>Systolic beyond the upper limit!</source>
        <translation>收缩压超过设置上限!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="640"/>
        <source>Systolic lower limit alarm</source>
        <translation>收缩压下限报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="641"/>
        <source>Systolic beyond the lower limit!</source>
        <translation>收缩压超过设置下限!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="644"/>
        <source>Diastolic upper limit alarm</source>
        <translation>舒张压上限报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="645"/>
        <source>Diastolic beyond the upper limit!</source>
        <translation>舒张压超过设置上限！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="647"/>
        <source>Diastolic lower limit alarm</source>
        <translation>舒张压下限报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="648"/>
        <source>Diastolic beyond the lower limit!</source>
        <translation>舒张压超过设置下限!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="651"/>
        <source>Pulse upper limit alarm</source>
        <translation>脉搏上限报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="652"/>
        <source>Pulse beyond the upper limit!</source>
        <translation>脉搏超过设置上限!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="654"/>
        <source>Pulse lower limit alarm</source>
        <translation>脉搏下限报警</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="655"/>
        <source>Pulse beyond the lower limit!</source>
        <translation>脉搏超过设置下限!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="658"/>
        <source>Time to stop heparin pump</source>
        <translation>肝素泵停止时间到</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="659"/>
        <source>Has reached the stop time!</source>
        <translation>设置的预停止时间到！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="662"/>
        <source>Please open the heparin pump</source>
        <translation>请打开肝素泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="663"/>
        <source>Didn&apos;t open the heparin pump!</source>
        <translation>肝素泵没有打开!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="666"/>
        <source>Please open the blood pump</source>
        <translation>请打开血泵</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="667"/>
        <source>The alarm already processed,please open the blood pump!</source>
        <translation>影响血泵的报警已处理完，可以打开血泵!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="674"/>
        <source>Electric supply stop</source>
        <translation>市电停止</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="675"/>
        <source>Electric supply stop!</source>
        <translation>市电停止!</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="678"/>
        <source>Please select a row !</source>
        <translation>请选择一行！</translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="679"/>
        <source>Are you sure to delete ?</source>
        <translation>是否确定删除？</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Artery</source>
        <translation type="obsolete">动脉压</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="47"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="85"/>
        <source>A.P.</source>
        <translation>动脉压</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="51"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="86"/>
        <source>V.P.</source>
        <oldsource>Vein</oldsource>
        <translation>静脉压</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="55"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="87"/>
        <source>TMP</source>
        <translation>跨膜压</translation>
    </message>
    <message>
        <source>Across</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="59"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="88"/>
        <source>Cond.</source>
        <oldsource>Conductance</oldsource>
        <translation>电导度</translation>
    </message>
    <message>
        <source>Disinfect</source>
        <translation type="obsolete">超滤目标</translation>
    </message>
    <message>
        <source>Run</source>
        <translation type="obsolete">运行</translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation type="obsolete">关机</translation>
    </message>
    <message>
        <source>Flush</source>
        <translation type="obsolete">冲洗</translation>
    </message>
    <message>
        <source>Rinse</source>
        <translation type="obsolete">冲洗</translation>
    </message>
    <message>
        <source>Chemical Disinfect</source>
        <oldsource>Chemical</oldsource>
        <translation type="obsolete">化学消毒</translation>
    </message>
    <message>
        <source>Hot Chemical Disinfect</source>
        <oldsource>Hot Chemical</oldsource>
        <translation type="obsolete">热化学消毒</translation>
    </message>
    <message>
        <source>Hot Rinse</source>
        <oldsource>Hot Flush</oldsource>
        <translation type="obsolete">热冲洗</translation>
    </message>
    <message>
        <source>Sodiun citrate(60)</source>
        <translation type="obsolete">柠檬酸(60 ℃)</translation>
    </message>
    <message>
        <source>Chloros</source>
        <translation type="obsolete">次氯酸钠</translation>
    </message>
    <message>
        <source>Sodiun citrate(85)</source>
        <translation type="obsolete">柠檬酸(85 ℃)</translation>
    </message>
    <message>
        <source>Citric acid</source>
        <translation type="obsolete">柠檬酸那(60 ℃)</translation>
    </message>
    <message>
        <source>Peracetic acid</source>
        <translation type="obsolete">过氧乙酸</translation>
    </message>
    <message>
        <source>Thermal chemical</source>
        <translation type="obsolete">次氯酸钠</translation>
    </message>
    <message>
        <source>Hot Citric acid</source>
        <translation type="obsolete">柠檬酸那(85 ℃)</translation>
    </message>
    <message>
        <source>Hemo Pump</source>
        <translation type="obsolete">血泵</translation>
    </message>
    <message>
        <source>Hemo Pump Speed:</source>
        <translation type="obsolete">血泵流速:</translation>
    </message>
    <message>
        <source>Hemo Pump Caliber:</source>
        <translation type="obsolete">血泵管径:</translation>
    </message>
    <message>
        <source>Supply Pump Speed:</source>
        <translation type="obsolete">补充泵流速:</translation>
    </message>
    <message>
        <source>Supply Pump Caliber:</source>
        <translation type="obsolete">补充泵管径:</translation>
    </message>
    <message>
        <source>Hemo Total:</source>
        <translation type="obsolete">血流累积量:</translation>
    </message>
    <message>
        <source>Supply Pump Used by Hemo:</source>
        <translation type="obsolete">补充泵做血泵:</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="obsolete">是</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="obsolete">否</translation>
    </message>
    <message>
        <source>Dialysis Liquid Temp</source>
        <translation type="obsolete">透析液温度</translation>
    </message>
    <message>
        <source>Temperature:</source>
        <translation type="obsolete">温度:</translation>
    </message>
    <message>
        <source>Temperature High:</source>
        <translation type="obsolete">温度上限:</translation>
    </message>
    <message>
        <source>Temperature Low:</source>
        <translation type="obsolete">温度下限:</translation>
    </message>
    <message>
        <source>target:</source>
        <translation type="obsolete">目标值</translation>
    </message>
    <message>
        <source>test value:</source>
        <translation type="obsolete">测试值</translation>
    </message>
    <message>
        <source>height:</source>
        <translation type="obsolete">身高</translation>
    </message>
    <message>
        <source>weight:</source>
        <translation type="obsolete">体重</translation>
    </message>
    <message>
        <source>age:</source>
        <translation type="obsolete">年龄</translation>
    </message>
    <message>
        <source>Gender:</source>
        <translation type="obsolete">性别</translation>
    </message>
    <message>
        <source>male</source>
        <translation type="obsolete">男性</translation>
    </message>
    <message>
        <source>female</source>
        <translation type="obsolete">女性</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation type="obsolete">参数设置</translation>
    </message>
    <message>
        <source>sodium concentration:</source>
        <translation type="obsolete">钠浓度</translation>
    </message>
    <message>
        <source>EC:</source>
        <translation type="obsolete">电导度</translation>
    </message>
    <message>
        <source>EC High:</source>
        <translation type="obsolete">电导度上限</translation>
    </message>
    <message>
        <source>EC Low:</source>
        <translation type="obsolete">电导度下限</translation>
    </message>
    <message>
        <source>Arterial Pressure</source>
        <translation type="obsolete">动脉压</translation>
    </message>
    <message>
        <source>Arterial Pressure:</source>
        <translation type="obsolete">动脉压</translation>
    </message>
    <message>
        <source>Arterial Pressure High:</source>
        <translatorcomment>动脉压上眼</translatorcomment>
        <translation type="obsolete">动脉压上限</translation>
    </message>
    <message>
        <source>Arterial Pressure Low:</source>
        <translatorcomment>动脉压下限</translatorcomment>
        <translation type="obsolete">动脉限下限</translation>
    </message>
    <message>
        <source>Heparin</source>
        <translation type="obsolete">肝素</translation>
    </message>
    <message>
        <source>Transmembrane:</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
    <message>
        <source>Transmembrane High:</source>
        <translation type="obsolete">跨膜压上限</translation>
    </message>
    <message>
        <source>Transmembrane Low:</source>
        <translation type="obsolete">跨膜压下限</translation>
    </message>
    <message>
        <source>Above ultrafiltration time:</source>
        <translation type="obsolete">已超滤时间</translation>
    </message>
    <message>
        <source>ultrafiltration target:</source>
        <translation type="obsolete">超滤目标：</translation>
    </message>
    <message>
        <source>ultrafiltration rate:</source>
        <translation type="obsolete">超滤率：</translation>
    </message>
    <message>
        <source>The actual amount of ultrafiltration:</source>
        <translation type="obsolete">实际超滤量：</translation>
    </message>
    <message>
        <source>Venous Pressure</source>
        <translation type="obsolete">静脉压</translation>
    </message>
    <message>
        <source>Venous Pressure:</source>
        <translation type="obsolete">静脉压</translation>
    </message>
    <message>
        <source>Venous Pressure High:</source>
        <translation type="obsolete">静脉压上限</translation>
    </message>
    <message>
        <source>Venous Pressure Low:</source>
        <translation type="obsolete">静脉压下限</translation>
    </message>
    <message>
        <source>UF</source>
        <translation type="obsolete">超虑设置</translation>
    </message>
    <message>
        <source>ISO UF</source>
        <translation type="obsolete">干超</translation>
    </message>
    <message>
        <source>Na Curve:</source>
        <translation type="obsolete">钠曲线</translation>
    </message>
    <message>
        <source>UF Curve:</source>
        <translation type="obsolete">UF曲线</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="583"/>
        <source>Messages</source>
        <translation>信息</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="572"/>
        <source>Alarm</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="557"/>
        <source>Warn</source>
        <translation>报警</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="420"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="286"/>
        <source>WorkModel</source>
        <translation>工作模式</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="410"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="197"/>
        <source>Return to ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="429"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="185"/>
        <source>CureFinish</source>
        <translation>完成治疗</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="447"/>
        <location filename="../../src/scenes/scene_main/widget_measure.cpp" line="260"/>
        <source>Confirm AP</source>
        <translation>确认动脉压</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="455"/>
        <location filename="../../src/scenes/scene_main/widget_measure.cpp" line="634"/>
        <source>Confirm VP</source>
        <translation>确认静脉压</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="463"/>
        <location filename="../../src/scenes/scene_main/widget_measure.cpp" line="861"/>
        <source>Confirm TMP</source>
        <translation>确认跨膜压</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="164"/>
        <source>Please Input Passwd</source>
        <translation>请输入密码</translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="400"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="189"/>
        <source>Cure Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="438"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="193"/>
        <source>CureLeave</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneArterialPressure</name>
    <message>
        <source>Arterial Pressure</source>
        <translation type="obsolete">动脉压</translation>
    </message>
</context>
<context>
    <name>SceneBloodVolume</name>
    <message>
        <source>Weight:</source>
        <translation type="obsolete">体重</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="68"/>
        <source>Dry weight:</source>
        <translation>体重:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="69"/>
        <source>Kg</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="71"/>
        <source>BloodVolume</source>
        <translation>血容</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="73"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
</context>
<context>
    <name>SceneControlWaterGraph</name>
    <message>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="743"/>
        <source>Blood Speed:</source>
        <translation type="unfinished">血流量：</translation>
    </message>
    <message>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="744"/>
        <source>Sub Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="870"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1833"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1837"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1841"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1845"/>
        <source>Contrlwater volt:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneCureLog</name>
    <message>
        <source>Transmembrane</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
</context>
<context>
    <name>SceneDialysateTemp</name>
    <message>
        <source>Dialysis Liquid Temp</source>
        <translation type="obsolete">透析液温度</translation>
    </message>
</context>
<context>
    <name>SceneDisinfect</name>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="69"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="838"/>
        <source>Disinfect</source>
        <translation>消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="117"/>
        <source>              Auto Off : 10min</source>
        <translation>              自动关机: 10分钟</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="862"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="863"/>
        <source>Filter Change</source>
        <translation>更 换</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="230"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="719"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="842"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="250"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="851"/>
        <source>Shut Off</source>
        <oldsource>Shutdown</oldsource>
        <translation>关机</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="538"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1236"/>
        <source>stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="561"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1187"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1366"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1404"/>
        <source>Rinse</source>
        <translation>冲洗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="568"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1192"/>
        <source>Hot Rinse</source>
        <translation>热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="581"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1197"/>
        <source>Chymistry Peracetic</source>
        <translation>过氧乙酸</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="584"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1200"/>
        <source>Chymistry Citric</source>
        <translation>柠檬酸</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="587"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1203"/>
        <source>Chymistry Reserve3</source>
        <translation>次氯酸钠</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="858"/>
        <source>     Filter1           Filter2</source>
        <translation>     滤器1           滤器2</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="859"/>
        <source>All Times :                                            </source>
        <translation>总次数:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="860"/>
        <source>Used Times :                                            </source>
        <translation>已用次数:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="861"/>
        <source>Remain Times :                                            </source>
        <translation>剩余次数:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1371"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1406"/>
        <source>Hot rinse</source>
        <translation>热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1376"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1408"/>
        <source>Chemical</source>
        <translation>化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1381"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1410"/>
        <source>Hot Water</source>
        <translation>热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1386"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1412"/>
        <source>Hot Acid</source>
        <translation type="unfinished">柠檬酸热消毒</translation>
    </message>
    <message>
        <source>     All Times :           days</source>
        <translation type="obsolete">总可用时间:             天</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="874"/>
        <source>Disinfect completed! Machine will shutdown automatically</source>
        <translation>消毒程序正常完成 ! 如果无任何操作 , 本机器将会</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="875"/>
        <source>in          minutes if no operation !</source>
        <translation>在           分钟后自动关机 !</translation>
    </message>
    <message>
        <source>  All Times :           days</source>
        <translation type="obsolete">总可用时间:            天</translation>
    </message>
    <message>
        <source>All Times :           days</source>
        <translation type="obsolete">总可用时间:            天</translation>
    </message>
    <message>
        <source>Used Times :           days</source>
        <translation type="obsolete">    已用时间:             天</translation>
    </message>
    <message>
        <source>Remaining Times :           days</source>
        <translation type="obsolete">              剩余时间:             天</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="854"/>
        <source>     Date            Time          Program Type</source>
        <translation>     日期            时间          消毒类型</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="857"/>
        <source>Remaining Time Until Filter Change</source>
        <translation>           超净滤器剩余时间</translation>
    </message>
    <message>
        <source>All Times : 32 days</source>
        <translation type="obsolete">总可用时间 : 32 天</translation>
    </message>
    <message>
        <source>Used Times : 12 days</source>
        <translation type="obsolete">    已用时间 :  12 天      </translation>
    </message>
    <message>
        <source>Remaining Times : 20 days</source>
        <translation type="obsolete">         剩余时间 : 20 天 </translation>
    </message>
    <message>
        <source>Date        Time        Program Type</source>
        <translation type="obsolete">日期        时间          消毒类型</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="853"/>
        <source>Last Programs</source>
        <translation>最近消毒记录</translation>
    </message>
    <message>
        <source>Peracetic acid</source>
        <translation type="obsolete">过氧乙酸</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="594"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1208"/>
        <source>Chloros</source>
        <translation>次氯酸钠</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="600"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1212"/>
        <source>Sodium citrate</source>
        <translation>柠檬酸</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="606"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1216"/>
        <source>Sodium citrate 85</source>
        <translation>柠檬酸(85 ℃)</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="612"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1220"/>
        <source>hot Disinfect</source>
        <translation>纯热水消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="679"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1272"/>
        <source>         Remaining Time : </source>
        <translation>         剩余时间e :</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="679"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1272"/>
        <source>min</source>
        <translation>分钟</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="847"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
</context>
<context>
    <name>SceneEC</name>
    <message>
        <source>Conductivity</source>
        <translation type="obsolete">电导度</translation>
    </message>
</context>
<context>
    <name>SceneHemoPump</name>
    <message>
        <source>Hemo Pump Status</source>
        <translation type="obsolete">血泵状态</translation>
    </message>
</context>
<context>
    <name>SceneHistory</name>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="230"/>
        <source>Introduce:</source>
        <translation>说明:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="670"/>
        <source>Alarm record</source>
        <translation>报警记录</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="671"/>
        <source>history</source>
        <translation>历史报警</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="672"/>
        <source>delete</source>
        <translation>删除记录</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="673"/>
        <source>first page</source>
        <translation>第一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="674"/>
        <source>up</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="675"/>
        <source>down</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="676"/>
        <source>last page</source>
        <translation>最后一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <source>id</source>
        <translation>序号</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>source</source>
        <translation>报警源</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>priority</source>
        <translation>优先级</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <source>dispose</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>code</source>
        <translation>编码</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="722"/>
        <source>selfcheck</source>
        <translation>自检报警</translation>
    </message>
    <message>
        <source>note</source>
        <translation type="obsolete">注解</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>info</source>
        <translation>信息</translation>
    </message>
    <message>
        <source>result</source>
        <translation type="obsolete">结果</translation>
    </message>
    <message>
        <source>History</source>
        <translation type="obsolete">历史数据</translation>
    </message>
    <message>
        <source>all</source>
        <translation type="obsolete">全部告警</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="726"/>
        <source>current</source>
        <translation>当前告警</translation>
    </message>
</context>
<context>
    <name>SceneKTV</name>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="373"/>
        <source>Pre-dislysis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="374"/>
        <source>Post-dislysis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="375"/>
        <source>Height:</source>
        <translation>身高：</translation>
    </message>
    <message>
        <source>Weight:</source>
        <translation type="obsolete">体重：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="377"/>
        <source>Age:</source>
        <translation>年龄：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="378"/>
        <source>Gender:</source>
        <translation>性别：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="379"/>
        <source>  Calibration should be done when Kt/V tests inaccurately.In calibration,machine should be in prime status.Precondition on successful calibration: Pre-dialysis conductivity and post-dialysis conductivity should be in the range of 13.0-15.0 mS/cm,the error between them should be less than 1.0 mS/cm.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="385"/>
        <source>Male</source>
        <translation>男</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="386"/>
        <source>Female</source>
        <translation>女</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="387"/>
        <source>OK</source>
        <translation type="unfinished">完成</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="388"/>
        <source>Ban</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="390"/>
        <source>Kt/V function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="391"/>
        <source>  Dialysis urea reduction rate just reflects reduction percentage of soluteinstead of actual solute-removing index. &gt;70% indicates dialysis adequacy.Only for reference! Please refer to actual clinical for analysis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="394"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="403"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="434"/>
        <source>First pre-dialysis BUN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="395"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="404"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="419"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="435"/>
        <source>First post-dialysis BUN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="396"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="397"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="407"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="408"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="424"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="425"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="426"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="440"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="441"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="442"/>
        <source>mmol/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="398"/>
        <source>Dialysis urea reduction rate(URR):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="399"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="410"/>
        <source>0 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="400"/>
        <source>  Pool II solute clearance index, a parameter calculated by urea kinetic model, indicates solute removing index in dialysis. SRI&gt;70% indicates dialysis adequacy. Only for reference! Please refer to actual clinical for analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UF Volume:</source>
        <translation type="obsolete">超滤量:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="406"/>
        <source>Pool II solute clearance index(SRI2pool):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="409"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="422"/>
        <source>ml</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="411"/>
        <source>  Normal protein catabolism rate.The protein intakes for dialysis patients should be more than 1.1(g/kg.d),then nPCR will be more than 1.1(g/kg.d) too.When nPCR is less than 0.8(g/kg.d),it means malnutrition and inadequate dialysisrate will be high. Only for reference! Please refer to actual clinical for analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="416"/>
        <source>Urine volume in dialysis interphase:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="417"/>
        <source>Interval time of dialysis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="418"/>
        <source>Urine BUN in dialysis interphase:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="420"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="436"/>
        <source>Second pre-dialysis BUN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="421"/>
        <source>Normal protein catabolism rate(nPCR):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="423"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="443"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="444"/>
        <source>min</source>
        <translation type="unfinished">分钟</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="427"/>
        <source>1000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="428"/>
        <source>g/kg.d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="429"/>
        <source>  Time Average Concentrations of Urea reflects synthesis situation of       dialysis urea remov index and patient&apos;s protein metabolism.TACurea&gt;50(mg/dl)       means reference index for dialysis adequacy.It indicates cardiovascular,      nervous system of alimentary canal and other long-term complications increase.      Only for reference! Please refer to actual clinical for analysis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="447"/>
        <source>  If the result after dialysis is &gt;1.2,it measn dialysis adequacy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="437"/>
        <source>Dialysis time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="376"/>
        <source>Dry weight:</source>
        <translation type="unfinished">体重:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="405"/>
        <source>Acc UF Volume:</source>
        <translation>已超滤量:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="438"/>
        <source>Dialysis interval time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="439"/>
        <source>Time Average Concentrations of Urea(TACurea):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="445"/>
        <source>mg/dl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="446"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneKTV2</name>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="197"/>
        <source>PerInfo</source>
        <translation>病人信息</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="291"/>
        <source>Height:</source>
        <translation>身高</translation>
    </message>
    <message>
        <source>Weight:</source>
        <translation type="obsolete">体重</translation>
    </message>
    <message>
        <source>Dry weight:</source>
        <translation type="obsolete">体重:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="292"/>
        <source>Dry Weight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="293"/>
        <source>Age:</source>
        <translation>年龄:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="294"/>
        <source>Gender:</source>
        <translation>性别:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="296"/>
        <source>Male</source>
        <translation>男</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="297"/>
        <source>Female</source>
        <translation>女</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="298"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="301"/>
        <source>Dialyzer Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="303"/>
        <source>Blood Flow</source>
        <translation>血泵流速</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="306"/>
        <source>Treatment Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="308"/>
        <source>UF Goal</source>
        <translation type="unfinished">超滤目标</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="312"/>
        <source>Kt/V Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="313"/>
        <source>Kt/V Upto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="314"/>
        <source>Kt/V Actual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="317"/>
        <source>P.t Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Treatment time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <source>UF goal</source>
        <translation type="obsolete">超滤目标</translation>
    </message>
    <message>
        <source>Kt/V goal</source>
        <translation type="obsolete">Kt/V目标</translation>
    </message>
    <message>
        <source>Kt/V upto</source>
        <translation type="obsolete">KT/V上升到</translation>
    </message>
    <message>
        <source>Kt/V actual</source>
        <translation type="obsolete">Kt/V当前值</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="299"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Dialyser Model</source>
        <translation type="obsolete">透析器类型</translation>
    </message>
    <message>
        <source>Blood Flow Rate</source>
        <translation type="obsolete">血流速率</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="304"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="311"/>
        <source>[ml/min]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="305"/>
        <source>Patient Information</source>
        <translation>病人信息</translation>
    </message>
    <message>
        <source>Cure Time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="307"/>
        <source>[h:min]</source>
        <translation></translation>
    </message>
    <message>
        <source>UF Target</source>
        <translation type="obsolete">超滤目标</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="309"/>
        <source>[ml]</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="310"/>
        <source>Dialysate Flowrate</source>
        <translation>透析液流速</translation>
    </message>
    <message>
        <source>Kt/V Target</source>
        <translation type="obsolete">Kt/V 目标</translation>
    </message>
    <message>
        <source>Kt/V Up To</source>
        <translation type="obsolete">Kt/V目标值</translation>
    </message>
    <message>
        <source>Kt/V Current</source>
        <translation type="obsolete">Kt/V当前值</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="316"/>
        <source>  If the result after dialysis is &gt;1.2,it measn dialysis adequacy.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneLogEmr</name>
    <message>
        <source>EMR Log</source>
        <translation type="obsolete">病例管理</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_emr.cpp" line="29"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_emr.cpp" line="30"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneLogRun</name>
    <message>
        <source>Run Log</source>
        <translation type="obsolete">运行日志</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="obsolete">确认</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="87"/>
        <source>Next Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="88"/>
        <source>Pre Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>id</source>
        <translation>序号</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>option</source>
        <translation>操作内容</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>workstatus</source>
        <translation>工作状态</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>note</source>
        <translation>注解</translation>
    </message>
</context>
<context>
    <name>SceneLogTreatment</name>
    <message>
        <source>Language</source>
        <translation type="obsolete">语言</translation>
    </message>
    <message>
        <source>Treatment log</source>
        <translation type="obsolete">治疗日志</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="12"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <source>  conductance   </source>
        <translation type="obsolete">电导度</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="10"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="44"/>
        <source>  conductivity   </source>
        <translation>电导度</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="45"/>
        <source>   temperature  </source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="46"/>
        <source>  DialysisFlux </source>
        <translation>透析液流速</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="47"/>
        <source>   UFR         </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="48"/>
        <source>   HeparinFlux  </source>
        <translation>肝素速率</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="49"/>
        <source>ArterialPressure</source>
        <translation>动脉压</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="50"/>
        <source> VenousPressure </source>
        <translation>静脉压</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="51"/>
        <source> Transmembrane  </source>
        <translation>跨膜压</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="52"/>
        <source> blood pressure </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="53"/>
        <source>      ktv       </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="54"/>
        <source>    alerting    </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneLogWarn</name>
    <message>
        <source>Warn Log</source>
        <translation type="obsolete">警告日志</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>id</source>
        <translation>序号</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>source</source>
        <translation>报警源</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>priority</source>
        <translation>优先级</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>title</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>dispose</source>
        <translation>确认</translation>
    </message>
</context>
<context>
    <name>SceneMaintain</name>
    <message>
        <location filename="../../src/maintain/scene_maintain.cpp" line="195"/>
        <source>Project Mode</source>
        <translation>工厂模式</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain.cpp" line="196"/>
        <source>Config Language</source>
        <translation>语言设置</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain.cpp" line="197"/>
        <source>Return</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneMaintainConfigLanguage</name>
    <message>
        <source>save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="19"/>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="39"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="22"/>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="40"/>
        <source>cancel</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneMaintainUpdate</name>
    <message>
        <source>Update System</source>
        <translation type="obsolete">系统升级</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
</context>
<context>
    <name>SceneProjectModeCurve</name>
    <message>
        <source>Confirm</source>
        <translation type="obsolete">确认</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
</context>
<context>
    <name>SceneProjectModeEeprom</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="54"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="95"/>
        <source>Read</source>
        <translation>读</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="57"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="96"/>
        <source>Write</source>
        <translation>写</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="87"/>
        <source>0000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="88"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="89"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="92"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="93"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneProjectModeFormulaSet</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="41"/>
        <source>mmol/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="42"/>
        <source>g/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="462"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="538"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="624"/>
        <source>/Config/Formula/Default%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="472"/>
        <source>One</source>
        <translation>一</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="473"/>
        <source>Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="474"/>
        <source>Three</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="475"/>
        <source>Four</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="228"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="477"/>
        <source>NaAc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="226"/>
        <source>B scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="227"/>
        <source>Water scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="229"/>
        <source>Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="230"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="232"/>
        <source>HCO3</source>
        <translation type="unfinished">碳酸氢根 {3?}</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="234"/>
        <source>Acetate</source>
        <translation type="unfinished">醋酸盐</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="235"/>
        <source>Ca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="237"/>
        <source>Default Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="478"/>
        <source>Na+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="479"/>
        <source>Cl-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="480"/>
        <source>K+</source>
        <translation>钾</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="482"/>
        <source>Mg++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="483"/>
        <source>Acetate+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="484"/>
        <source>Ca++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="485"/>
        <source>B)NaCl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="486"/>
        <source>Default Na+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="238"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="487"/>
        <source>Default HCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="497"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="556"/>
        <source>RadioB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="498"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="557"/>
        <source>RadioWater</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="499"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="558"/>
        <source>NaAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="503"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="560"/>
        <source>CL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="231"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="504"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="561"/>
        <source>K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="233"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="508"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="563"/>
        <source>Mg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="509"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="564"/>
        <source>ACE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="510"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="565"/>
        <source>CA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="236"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="511"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="566"/>
        <source>BNaCl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="506"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="562"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="569"/>
        <source>Stand_HCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="501"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="559"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="570"/>
        <source>Stand_Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="476"/>
        <source>Formula  1 :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="512"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="567"/>
        <source>DNa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="513"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="568"/>
        <source>DHCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="571"/>
        <source>Stand_B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="572"/>
        <source>Stand_Water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="611"/>
        <source>/Config/Formula/Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="615"/>
        <source>use</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneProjectModeParams</name>
    <message>
        <source>Sodium citrate(60 &apos;C)</source>
        <translation type="obsolete">柠檬酸</translation>
    </message>
    <message>
        <source>Peracetic acid</source>
        <translation type="obsolete">过氧乙酸</translation>
    </message>
    <message>
        <source>Chloros</source>
        <translation type="obsolete">次氯酸钠</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="108"/>
        <source>Maintain Params</source>
        <translation>维护参数</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="109"/>
        <source>Params</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="110"/>
        <source>EEprom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="111"/>
        <source>Return</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneProjectModeParamsCommon</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>name</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>default</source>
        <translation>默认值</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>max</source>
        <translation>最大值</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1308"/>
        <source>/Config/Params_UF/UF_Goal</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1425"/>
        <source>/Config/Params_UF/Earlier_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1627"/>
        <source>/Config/Params_Dialyser/onlineRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1888"/>
        <source>/Config/Params_BP/Rate_GetBlood</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2763"/>
        <source>/Config/Params_PreFlush/BpRate_Conect</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2809"/>
        <source>/Config/Params_PreFlush/BpRate_phase1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2855"/>
        <source>/Config/Params_PreFlush/BpRate_phase2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2901"/>
        <source>/Config/Params_PreFlush/BpRate_phase3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2947"/>
        <source>/Config/Params_PreFlush/TMPUp_PF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3000"/>
        <source>/Config/Params_ColdFlush/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3055"/>
        <source>/Config/Params_ColdFlush/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3150"/>
        <source>/Config/Params_HotFlush/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3414"/>
        <source>/Config/Params_Chymistry_Citric/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3453"/>
        <source>/Config/Params_Chymistry_Citric/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3590"/>
        <source>/Config/Params_Chymistry_Citric/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3644"/>
        <source>/Config/Params_Chymistry_Peracetic/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3654"/>
        <source>/Config/Params_Chymistry_Peracetic/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3703"/>
        <source>/Config/Params_Chymistry_Peracetic/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3758"/>
        <source>/Config/Params_Chymistry_Reserve3/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3768"/>
        <source>/Config/Params_Chymistry_Reserve3/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3818"/>
        <source>/Config/Params_Chymistry_Reserve3/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3874"/>
        <source>/Config/Params_Hot_Citric/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3884"/>
        <source>/Config/Params_Hot_Citric/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3934"/>
        <source>/Config/Params_Hot_Citric/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3979"/>
        <source>/Config/Params_Hot/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3989"/>
        <source>/Config/Params_Hot/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4065"/>
        <source>/Config/Params_Center_Chymistry_Input/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4075"/>
        <source>/Config/Params_Center_Chymistry_Input/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4085"/>
        <source>/Config/Params_Center_Chymistry_Input/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4139"/>
        <source>/Config/Params_Center_Chymistry_Flush/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4149"/>
        <source>/Config/Params_Center_Chymistry_Flush/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4159"/>
        <source>/Config/Params_Center_Chymistry_Flush/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4213"/>
        <source>/Config/Params_Center_Hot/Flush_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4223"/>
        <source>/Config/Params_Center_Hot/Loop_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4243"/>
        <source>/Config/Params_Center_Hot/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4297"/>
        <source>/Config/Params_Center_Flush_Entry/Suck_Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4346"/>
        <source>/Config/Auto_scale/AP_ReadySafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4356"/>
        <source>/Config/Auto_scale/AP_ReadySafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4366"/>
        <source>/Config/Auto_scale/AP_RunSafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4376"/>
        <source>/Config/Auto_scale/AP_RunSafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4406"/>
        <source>/Config/Auto_scale/AP_RunAutoScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4416"/>
        <source>/Config/Auto_scale/AP_RunAutoScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4386"/>
        <source>/Config/Auto_scale/AP_StopSafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4396"/>
        <source>/Config/Auto_scale/AP_StopSafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4429"/>
        <source>/Config/Auto_scale/VP_ReadySafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4439"/>
        <source>/Config/Auto_scale/VP_ReadySafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4449"/>
        <source>/Config/Auto_scale/VP_RunSafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4459"/>
        <source>/Config/Auto_scale/VP_RunSafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4489"/>
        <source>/Config/Auto_scale/VP_RunAutoScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4499"/>
        <source>/Config/Auto_scale/VP_RunAutoScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4469"/>
        <source>/Config/Auto_scale/VP_StopSafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4479"/>
        <source>/Config/Auto_scale/VP_StopSafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4513"/>
        <source>/Config/Auto_scale/TMP_ReadySafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4523"/>
        <source>/Config/Auto_scale/TMP_ReadySafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4533"/>
        <source>/Config/Auto_scale/TMP_RunSafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4543"/>
        <source>/Config/Auto_scale/TMP_RunSafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4573"/>
        <source>/Config/Auto_scale/TMP_RunAutoScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4583"/>
        <source>/Config/Auto_scale/TMP_RunAutoScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4553"/>
        <source>/Config/Auto_scale/TMP_StopSafeScaleUp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4563"/>
        <source>/Config/Auto_scale/TMP_StopSafeScaleLow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4595"/>
        <source>/Config/Auto_scale/AP_SPAN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4606"/>
        <source>/Config/Auto_scale/VP_SPAN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4616"/>
        <source>/Config/Auto_scale/TEMP_SPAN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4626"/>
        <source>/Config/Auto_scale/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4636"/>
        <source>/Config/Auto_scale/Alarm_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4311"/>
        <source>/Config/Clean_cond/B_cond</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4321"/>
        <source>/Config/Clean_cond/Mix_cond</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4331"/>
        <source>/Config/Clean_cond/Out_cond</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1338"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1383"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1418"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1457"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1497"/>
        <source>UF</source>
        <translation>超滤</translation>
    </message>
    <message>
        <source>UF_Goal</source>
        <translation type="obsolete">超滤目标值</translation>
    </message>
    <message>
        <source>Earlier_Time</source>
        <translation type="obsolete">提前结束时间</translation>
    </message>
    <message>
        <source>Online Rate</source>
        <translation type="obsolete">在线流速</translation>
    </message>
    <message>
        <source>Rate_GetBlood</source>
        <translation type="obsolete">血泵引血速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4314"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4324"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4334"/>
        <source>Clean_cond</source>
        <translation>冲洗电导</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4314"/>
        <source>B_cond</source>
        <translation>B液电导</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4324"/>
        <source>Mix_cond</source>
        <translation>混合电导</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4334"/>
        <source>Out_cond</source>
        <translation>出水口电导</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4349"/>
        <source>AP_ReadySafeScaleUp</source>
        <translation>动脉压安全卡标上限(准备状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4359"/>
        <source>AP_ReadySafeScaleLow</source>
        <translation>动脉压安全卡标下限(准备状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4369"/>
        <source>AP_RunSafeScaleUp</source>
        <translation>动脉压安全卡标上限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4379"/>
        <source>AP_RunSafeScaleLow</source>
        <translation>动脉压安全卡标下限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4389"/>
        <source>AP_StopSafeScaleUp</source>
        <translation>动脉压安全卡标上限(结束状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4399"/>
        <source>AP_StopSafeScaleLow</source>
        <translation>动脉压安全卡标下限(结束状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4409"/>
        <source>AP_RunAutoScaleUp</source>
        <translation>动脉压自动卡标上限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4419"/>
        <source>AP_RunAutoScaleLow</source>
        <translation>动脉压自动卡标下限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4432"/>
        <source>VP_ReadySafeScaleUp</source>
        <translation>静脉压安全卡标上限(准备状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4442"/>
        <source>VP_ReadySafeScaleLow</source>
        <translation>静脉压安全卡标下限(准备状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4452"/>
        <source>VP_RunSafeScaleUp</source>
        <translation>静脉压安全卡标上限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4462"/>
        <source>VP_RunSafeScaleLow</source>
        <translation>静脉压安全卡标下限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4472"/>
        <source>VP_StopSafeScaleUp</source>
        <translation>静脉压安全卡标上限(结束状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4482"/>
        <source>VP_StopSafeScaleLow</source>
        <translation>静脉压安全卡标下限(结束状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4492"/>
        <source>VP_RunAutoScaleUp</source>
        <translation>静脉压自动卡标上限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4502"/>
        <source>VP_RunAutoScaleLow</source>
        <translation>静脉压自动卡标下限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4516"/>
        <source>TMP_ReadySafeScaleUp</source>
        <translation>跨膜压安全卡标上限(准备状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4526"/>
        <source>TMP_ReadySafeScaleLow</source>
        <translation>跨膜压安全卡标下限(准备状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4536"/>
        <source>TMP_RunSafeScaleUp</source>
        <translation>跨膜压安全卡标上限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4546"/>
        <source>TMP_RunSafeScaleLow</source>
        <translation>跨膜压安全卡标下限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4556"/>
        <source>TMP_StopSafeScaleUp</source>
        <translation>跨膜压安全卡标上限(结束状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4566"/>
        <source>TMP_StopSafeScaleLow</source>
        <translation>跨膜压安全卡标下限(结束状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4576"/>
        <source>TMP_RunAutoScaleUp</source>
        <translation>跨膜压自动卡标上限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4586"/>
        <source>TMP_RunAutoScaleLow</source>
        <translation>跨膜压自动卡标下限(治疗状态)</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>min</source>
        <translation>最小值</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>step</source>
        <translation>步进值</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>unit</source>
        <translation>单位</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4699"/>
        <source>Confirm</source>
        <translation>确认保存</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4700"/>
        <source>Factory Reset</source>
        <translation>出厂设置</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1354"/>
        <source>/Config/Params_UF/UF_Rate</source>
        <translation></translation>
    </message>
    <message>
        <source>UF_Rate</source>
        <translation type="obsolete">超滤速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1345"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1390"/>
        <source>/Config/Params_UF/UF_Time</source>
        <translation></translation>
    </message>
    <message>
        <source>UF_Time</source>
        <translation type="obsolete">超滤时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1510"/>
        <source>/Config/Params_Dialyser/Temp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1542"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1581"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1620"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1659"/>
        <source>Dialyser</source>
        <translation>透析液</translation>
    </message>
    <message>
        <source>Temp</source>
        <translation type="obsolete">透析液设定温度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1549"/>
        <source>/Config/Params_Dialyser/Cond</source>
        <translation></translation>
    </message>
    <message>
        <source>Cond</source>
        <translation type="obsolete">透后液电导</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1588"/>
        <source>/Config/Params_Dialyser/Rate</source>
        <translation></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="obsolete">透析液设定流速</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1671"/>
        <source>/Config/Params_BP/BP_Width</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1702"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1764"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1803"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1842"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1881"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1920"/>
        <source>BP</source>
        <translation>血泵</translation>
    </message>
    <message>
        <source>BP_Width</source>
        <translation type="obsolete">血泵管径</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1732"/>
        <source>/Config/Params_BP/Rate_CheckSelf</source>
        <translation></translation>
    </message>
    <message>
        <source>Rate_CheckSelf</source>
        <translation type="obsolete">自检血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1771"/>
        <source>/Config/Params_BP/Rate_ThreatMent</source>
        <translation></translation>
    </message>
    <message>
        <source>Rate_ThreatMent</source>
        <translation type="obsolete">治疗血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1810"/>
        <source>/Config/Params_BP/Rate_ReturnBlood</source>
        <translation></translation>
    </message>
    <message>
        <source>Rate_ReturnBlood</source>
        <translation type="obsolete">血泵回血速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1849"/>
        <source>/Config/Params_BP/Rate_Preflush</source>
        <translation></translation>
    </message>
    <message>
        <source>Rate_Preflush</source>
        <translation type="obsolete">预冲血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2044"/>
        <source>/Config/Params_Heparin/First_Volume</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2076"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2115"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2154"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2193"/>
        <source>Heparin</source>
        <translation>肝素</translation>
    </message>
    <message>
        <source>First_Volume</source>
        <translation type="obsolete">首剂量</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2083"/>
        <source>/Config/Params_Heparin/Rate</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2122"/>
        <source>/Config/Params_Heparin/Pre_StopTime</source>
        <translation></translation>
    </message>
    <message>
        <source>Pre_StopTime</source>
        <translation type="obsolete">预先停止时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2161"/>
        <source>/Config/Params_Heparin/add_Volume</source>
        <translation></translation>
    </message>
    <message>
        <source>add_Volume</source>
        <translation type="obsolete">肝素追加量</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2229"/>
        <source>/Config/Params_SubP/Flux</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2261"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2300"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2339"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2379"/>
        <source>Sub Pump</source>
        <translation>置换泵（第二血泵）</translation>
    </message>
    <message>
        <source>Flux</source>
        <translation type="obsolete">置换泵流速</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2268"/>
        <source>/Config/Params_SubP/Goal</source>
        <translation></translation>
    </message>
    <message>
        <source>Goal</source>
        <translation type="obsolete">目标值</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2307"/>
        <source>/Config/Params_SubP/Rapid_Rate</source>
        <translation></translation>
    </message>
    <message>
        <source>Rapid_Rate</source>
        <translation type="obsolete">快速补液速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2391"/>
        <source>/Config/Params_TreatTime/Hour</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2423"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2462"/>
        <source>Threat Time</source>
        <translation>治疗时间</translation>
    </message>
    <message>
        <source>Hour</source>
        <translation type="obsolete">小时</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2430"/>
        <source>/Config/Params_TreatTime/min</source>
        <translation></translation>
    </message>
    <message>
        <source>Min</source>
        <translation type="obsolete">分钟</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2515"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2561"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2600"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2639"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2678"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2717"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2756"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2803"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2849"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2895"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2941"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2979"/>
        <source>PreFlush</source>
        <translation>预冲</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2568"/>
        <source>/Config/Params_PreFlush/Dialyser_Rate</source>
        <translation></translation>
    </message>
    <message>
        <source>Dialyser_Rate</source>
        <translation type="obsolete">透析液流量</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2607"/>
        <source>/Config/Params_PreFlush/Time</source>
        <translation></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">预冲时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2646"/>
        <source>/Config/Params_PreFlush/PF_UF_Rate</source>
        <translation></translation>
    </message>
    <message>
        <source>PF_UF_Rate</source>
        <translation type="obsolete">预冲超滤率</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2685"/>
        <source>/Config/Params_PreFlush/PF_UF_Volume</source>
        <translation></translation>
    </message>
    <message>
        <source>PF_UF_Volume</source>
        <translation type="obsolete">预冲超滤量</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2724"/>
        <source>/Config/Params_PreFlush/PF_Volume</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2474"/>
        <source>/Config/Params_PreFlush/BpRate_First_FiveMin</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2521"/>
        <source>/Config/Params_PreFlush/BpRate</source>
        <translation></translation>
    </message>
    <message>
        <source>BpRate_First_FiveMin</source>
        <translation type="obsolete">预冲血泵速（前5分钟）</translation>
    </message>
    <message>
        <source>BpRate</source>
        <translation type="obsolete">预冲血泵速</translation>
    </message>
    <message>
        <source>PF_Volume</source>
        <translation type="obsolete">预冲总量</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3032"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3058"/>
        <source>ColdFlush</source>
        <translation>冷冲洗</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3607"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3720"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3836"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3952"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4028"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4102"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4176"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4260"/>
        <source>PreFlush_Time</source>
        <translation>前冲时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3617"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3731"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3847"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3962"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4048"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4122"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4196"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4280"/>
        <source>Loop_Time</source>
        <translation>循环时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3627"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3741"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3857"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4038"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4112"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4186"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4270"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4629"/>
        <source>Hold_Time</source>
        <translation>滞留时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3637"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3751"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3867"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3972"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4058"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4132"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4206"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4290"/>
        <source>BackFlush_Time</source>
        <translation>后冲时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3127"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3153"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3200"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3239"/>
        <source>HotFlush</source>
        <translation>热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3095"/>
        <source>/Config/Params_HotFlush/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3168"/>
        <source>/Config/Params_HotFlush/TargetTemp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3667"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3781"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3897"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4003"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4236"/>
        <source>TargetTemp</source>
        <translation>目标温度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3207"/>
        <source>/Config/Params_HotFlush/RealTmep</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3677"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3791"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3907"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4013"/>
        <source>RealTmep</source>
        <translation>走时温度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3258"/>
        <source>/Config/Params_Chymistry_Citric/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3290"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3329"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3368"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3407"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3446"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3485"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3524"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3563"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3573"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3583"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3593"/>
        <source>Chymistry_Citric</source>
        <translation>柠檬酸消毒</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3297"/>
        <source>/Config/Params_Chymistry_Citric/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3336"/>
        <source>/Config/Params_Chymistry_Citric/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3375"/>
        <source>/Config/Params_Chymistry_Citric/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3492"/>
        <source>/Config/Params_Chymistry_Citric/TargetTemp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3531"/>
        <source>/Config/Params_Chymistry_Citric/RealTmep</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3570"/>
        <source>/Config/Params_Chymistry_Citric/Conduction_MAX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3573"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3688"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3801"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3917"/>
        <source>Conduction_MAX</source>
        <translation>电导上限</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3580"/>
        <source>/Config/Params_Chymistry_Citric/Conduction_MIN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3583"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3696"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3811"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3927"/>
        <source>Conduction_MIN</source>
        <translation>电导下限</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3604"/>
        <source>/Config/Params_Chymistry_Peracetic/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3607"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3617"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3627"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3637"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3647"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3657"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3667"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3677"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3688"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3696"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3706"/>
        <source>Chymistry_Peracetic</source>
        <translation>过氧乙酸消毒</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3614"/>
        <source>/Config/Params_Chymistry_Peracetic/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3624"/>
        <source>/Config/Params_Chymistry_Peracetic/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3634"/>
        <source>/Config/Params_Chymistry_Peracetic/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3664"/>
        <source>/Config/Params_Chymistry_Peracetic/TargetTemp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3674"/>
        <source>/Config/Params_Chymistry_Peracetic/RealTmep</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3685"/>
        <source>/Config/Params_Chymistry_Peracetic/Conduction_MAX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3693"/>
        <source>/Config/Params_Chymistry_Peracetic/Conduction_MIN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3717"/>
        <source>/Config/Params_Chymistry_Reserve3/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3720"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3731"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3741"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3751"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3761"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3771"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3781"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3791"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3801"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3811"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3821"/>
        <source>Chymistry_Reserve3</source>
        <translation>次氯酸钠消毒</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3728"/>
        <source>/Config/Params_Chymistry_Reserve3/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3738"/>
        <source>/Config/Params_Chymistry_Reserve3/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3748"/>
        <source>/Config/Params_Chymistry_Reserve3/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3778"/>
        <source>/Config/Params_Chymistry_Reserve3/TargetTemp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3788"/>
        <source>/Config/Params_Chymistry_Reserve3/RealTmep</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3798"/>
        <source>/Config/Params_Chymistry_Reserve3/Conduction_MAX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3808"/>
        <source>/Config/Params_Chymistry_Reserve3/Conduction_MIN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3833"/>
        <source>/Config/Params_Hot_Citric/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <source>BpRate_Conect</source>
        <translation type="obsolete">连接患者时血泵速度</translation>
    </message>
    <message>
        <source>BpRate_phase1</source>
        <translation type="obsolete">第一阶段血泵速度</translation>
    </message>
    <message>
        <source>BpRate_phase2</source>
        <translation type="obsolete">第二阶段血泵速度</translation>
    </message>
    <message>
        <source>BpRate_phase3</source>
        <translation type="obsolete">第三阶段血泵速度</translation>
    </message>
    <message>
        <source>TMPUp_PF</source>
        <translation type="obsolete">跨膜压上限</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3058"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3153"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3647"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3761"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3877"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3982"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4068"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4142"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4216"/>
        <source>Flush_Flux</source>
        <translation>冲洗速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3657"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3771"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3887"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3992"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4078"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4152"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4226"/>
        <source>Loop_Flux</source>
        <translation>循环速度</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3593"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3706"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3821"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3937"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4088"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4162"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4246"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4300"/>
        <source>Suck_Flux</source>
        <translation>吸液量</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1464"/>
        <source>/Config/Params_UF/AutoChange_Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2346"/>
        <source>/Config/Params_SubP/AutoChange_Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3836"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3847"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3857"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3867"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3877"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3887"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3897"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3907"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3917"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3927"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3937"/>
        <source>Hot_Citric</source>
        <translation>热柠檬酸消毒</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3844"/>
        <source>/Config/Params_Hot_Citric/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3854"/>
        <source>/Config/Params_Hot_Citric/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3864"/>
        <source>/Config/Params_Hot_Citric/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3894"/>
        <source>/Config/Params_Hot_Citric/TargetTemp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3904"/>
        <source>/Config/Params_Hot_Citric/RealTmep</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3914"/>
        <source>/Config/Params_Hot_Citric/Conduction_MAX</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3924"/>
        <source>/Config/Params_Hot_Citric/Conduction_MIN</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3949"/>
        <source>/Config/Params_Hot/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3952"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3962"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3972"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3982"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3992"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4003"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4013"/>
        <source>Hot</source>
        <translation>热消毒</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3959"/>
        <source>/Config/Params_Hot/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3969"/>
        <source>/Config/Params_Hot/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4000"/>
        <source>/Config/Params_Hot/TargetTemp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4010"/>
        <source>/Config/Params_Hot/RealTmep</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4025"/>
        <source>/Config/Params_Center_Chymistry_Input/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4028"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4038"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4048"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4058"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4078"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4088"/>
        <source>Center_Chymistry_Input</source>
        <translation>中央化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4035"/>
        <source>/Config/Params_Center_Chymistry_Input/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4045"/>
        <source>/Config/Params_Center_Chymistry_Input/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4055"/>
        <source>/Config/Params_Center_Chymistry_Input/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4068"/>
        <source>Center_Chymistry_Inpult</source>
        <translation>中央热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4099"/>
        <source>/Config/Params_Center_Chymistry_Flush/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4102"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4112"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4122"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4132"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4142"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4152"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4162"/>
        <source>Center_Chymistry_Flush</source>
        <translation>中央化学冲洗消毒</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4109"/>
        <source>/Config/Params_Center_Chymistry_Flush/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4119"/>
        <source>/Config/Params_Center_Chymistry_Flush/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4129"/>
        <source>/Config/Params_Center_Chymistry_Flush/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4173"/>
        <source>/Config/Params_Center_Hot/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4176"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4186"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4196"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4206"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4216"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4226"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4236"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4246"/>
        <source>Center_Hot</source>
        <translation>中央热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4183"/>
        <source>/Config/Params_Center_Hot/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4193"/>
        <source>/Config/Params_Center_Hot/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4203"/>
        <source>/Config/Params_Center_Hot/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4233"/>
        <source>/Config/Params_Center_Hot/TargetTemp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4257"/>
        <source>/Config/Params_Center_Flush_Entry/PreFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4260"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4270"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4280"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4290"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4300"/>
        <source>Center_Flush_Entry</source>
        <translation>中央冷冲洗</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4267"/>
        <source>/Config/Params_Center_Flush_Entry/Hold_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4277"/>
        <source>/Config/Params_Center_Flush_Entry/Loop_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4287"/>
        <source>/Config/Params_Center_Flush_Entry/BackFlush_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4349"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4359"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4369"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4379"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4389"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4399"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4409"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4419"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4432"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4442"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4452"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4462"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4472"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4482"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4492"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4502"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4516"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4526"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4536"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4546"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4556"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4566"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4576"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4586"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4598"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4609"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4619"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4629"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4639"/>
        <source>Auto_scale</source>
        <translation>自动卡标</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4598"/>
        <source>AP_SPAN</source>
        <translation>动脉压范围</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4609"/>
        <source>VP_SPAN</source>
        <translation>静脉压范围</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4619"/>
        <source>TEMP_SPAN</source>
        <translation>跨膜压范围</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4639"/>
        <source>Alarm_Time</source>
        <translation>报警时间</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4697"/>
        <source>last</source>
        <translation>上页</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4698"/>
        <source>next</source>
        <translation>下页</translation>
    </message>
    <message>
        <source>save</source>
        <translation type="obsolete">保存</translation>
    </message>
</context>
<context>
    <name>SceneQuery</name>
    <message>
        <source>Transmembrane</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
</context>
<context>
    <name>SceneRecordCurve</name>
    <message>
        <source>Cond curve</source>
        <translation type="obsolete">电导曲线</translation>
    </message>
    <message>
        <source>Temp curve</source>
        <translation type="obsolete">温度曲线</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="180"/>
        <source>Treatment start time:</source>
        <translation>治疗开始时间:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="182"/>
        <source>Treatment end time:</source>
        <translation>治疗结束时间:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="184"/>
        <source>Cond Profile</source>
        <translation>电导曲线</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="185"/>
        <source>Temp Profile</source>
        <translation>温度曲线</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="191"/>
        <source>Cond date</source>
        <translation>电导数据</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="192"/>
        <source>Temp date</source>
        <translation>温度数据</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="193"/>
        <source>Pre Cure</source>
        <translation>前次治疗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="194"/>
        <source>Nxt Cure</source>
        <translation>后次治疗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="195"/>
        <source>Pre Page</source>
        <translation>上一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="196"/>
        <source>Nxt Page</source>
        <translation>下一页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="540"/>
        <source>The current treatment</source>
        <translation>当前治疗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="544"/>
        <source>before</source>
        <translation>前</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="546"/>
        <source>times treatment</source>
        <translation>次治疗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="589"/>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="594"/>
        <source>time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="589"/>
        <source>C701</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="589"/>
        <source>C702</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="589"/>
        <source>C704</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="589"/>
        <source>C709</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="594"/>
        <source>T201</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="594"/>
        <source>T203</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="594"/>
        <source>T204</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="594"/>
        <source>T205</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupAdvertTimer</name>
    <message>
        <source>AbsolutTime</source>
        <translation type="obsolete">绝对时间</translation>
    </message>
    <message>
        <source>RelativeTime</source>
        <translation type="obsolete">相对时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="135"/>
        <source>SingleTime</source>
        <translation>单次时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="136"/>
        <source>CycleTime</source>
        <translation>循环时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="137"/>
        <source>RemainTime</source>
        <translation>剩余时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="139"/>
        <source>Stop/RUN</source>
        <translation>启动/停止</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="140"/>
        <source>One-Time</source>
        <translation>单次</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="141"/>
        <source>Cyc-Time</source>
        <translation>循环</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="143"/>
        <source>Prompt</source>
        <translation>计时器时间到</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="144"/>
        <source>Sound</source>
        <translation>声音</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="145"/>
        <source>Option</source>
        <translation>操作</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="147"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="148"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="150"/>
        <source>00:00:00</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneSetupAutoWakeUp</name>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="320"/>
        <source>Monday</source>
        <translation>星期一</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="321"/>
        <source>Tuesday</source>
        <translation>星期二</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="322"/>
        <source>Wednesday</source>
        <translation>星期三</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="323"/>
        <source>Thursday</source>
        <translation>星期四</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="324"/>
        <source>Friday</source>
        <translation>星期五</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="325"/>
        <source>Saturday</source>
        <translation>星期六</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="326"/>
        <source>Sunday</source>
        <translation>星期天</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="327"/>
        <source>OK</source>
        <translation type="unfinished">完成</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="328"/>
        <source>Enable Auto-wake-up</source>
        <translation>启动自动开机</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="332"/>
        <source>Time Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="333"/>
        <source>Time Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable AutoWakeup</source>
        <translation type="obsolete">启动自动开机</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="329"/>
        <source>Power Time: </source>
        <translation>电源时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="330"/>
        <source>2000.0.0 0:0:0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="331"/>
        <source>Set Wakeup Time</source>
        <translation>自动开机时间</translation>
    </message>
    <message>
        <source>CalibDate</source>
        <translation type="obsolete">日期校准</translation>
    </message>
    <message>
        <source>GetDate</source>
        <translation type="obsolete">读取日期</translation>
    </message>
</context>
<context>
    <name>SceneSetupBPM</name>
    <message>
        <source>Blood-pressure Meter</source>
        <translation type="obsolete">血压计</translation>
    </message>
    <message>
        <source>Heart rate:</source>
        <translation type="obsolete">心率：</translation>
    </message>
    <message>
        <source>DIA/SYS:</source>
        <translation type="obsolete">舒张压/收缩压：</translation>
    </message>
    <message>
        <source>Patient Positions:</source>
        <translation type="obsolete">患者体位：</translation>
    </message>
    <message>
        <source>Pulse:</source>
        <translation type="obsolete">脉搏：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="118"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="504"/>
        <source>Lying</source>
        <translation>躺</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="119"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="505"/>
        <source>Sitting</source>
        <translation>坐</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="120"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="506"/>
        <source>Standing</source>
        <translation>站</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="128"/>
        <source>ADult</source>
        <translation>成人</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="129"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="509"/>
        <source>Child</source>
        <translation>小孩</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>Time</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>Systolic 
 mmHg</source>
        <translation>收缩压
mmHg</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>Diastolic 
 mmHg</source>
        <translation>舒张压
mmHg</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>MAP 
 mmHg</source>
        <translation>平均压
mmHg</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="500"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="516"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="532"/>
        <source>Pulse</source>
        <translation>脉搏</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="378"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="525"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="875"/>
        <source>Auto Measure 
 ON</source>
        <translation>自动测量 开</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="370"/>
        <source>Auto Measure 
 OFF</source>
        <translation>自动测量 关</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="388"/>
        <source>Cancel Measure</source>
        <translation>取消本次测量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="405"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="526"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="561"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="573"/>
        <source>Start Measure</source>
        <translation>开始单次测量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="418"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="442"/>
        <source>Profile</source>
        <translation>曲线</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="502"/>
        <source>SYS/DIA</source>
        <translation>收缩压/舒张压</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="503"/>
        <source>Patient Position</source>
        <translation>测量姿势</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="508"/>
        <source>Adult</source>
        <translation>成人</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="511"/>
        <source>Measure interval</source>
        <translation>自动测量间隔</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="515"/>
        <source>Lower</source>
        <translation>低限</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="513"/>
        <source>Upper</source>
        <translation>高限</translation>
    </message>
    <message>
        <source>Hour:</source>
        <translation type="obsolete">小时：</translation>
    </message>
    <message>
        <source>Curve&amp;Table</source>
        <translation type="obsolete">曲线/表格</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="524"/>
        <source>Close</source>
        <translation>隐藏</translation>
    </message>
    <message>
        <source>Measure</source>
        <translation type="obsolete">手动测量</translation>
    </message>
    <message>
        <source>Curve</source>
        <translation type="obsolete">曲线</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="427"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="527"/>
        <source>Table</source>
        <translation>表格</translation>
    </message>
    <message>
        <source>DIA/SYS</source>
        <translation type="obsolete">舒张压/收缩压</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="507"/>
        <source>Belt</source>
        <translation>袖带类型</translation>
    </message>
    <message>
        <source>Measure interval:</source>
        <translation type="obsolete">间隔测量时间：</translation>
    </message>
    <message>
        <source>Systolic Upper:</source>
        <translation type="obsolete">收缩压上限：</translation>
    </message>
    <message>
        <source>Systolic Lower:</source>
        <translation type="obsolete">收缩压下限：</translation>
    </message>
    <message>
        <source>Diastolic Upper:</source>
        <translation type="obsolete">舒张压上限：</translation>
    </message>
    <message>
        <source>Diastolic Lower:</source>
        <translation type="obsolete">舒张压下限：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="512"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="529"/>
        <source>Systolic</source>
        <translation>收缩压</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="514"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="530"/>
        <source>Diastolic</source>
        <translation>舒张</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="517"/>
        <source>Hour</source>
        <translation>小时</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="518"/>
        <source>Min</source>
        <translation>分钟</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="523"/>
        <source>Curve/Table</source>
        <translation>曲线/表格</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="531"/>
        <source>MAP</source>
        <translation>平均压</translation>
    </message>
    <message>
        <source>Max Heart Rate:</source>
        <translation type="obsolete">最大心率：</translation>
    </message>
    <message>
        <source>Min Heart Rate:</source>
        <translation type="obsolete">最小心率：</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupBicarbonate</name>
    <message>
        <source>Bicarbonate Radical</source>
        <translation type="obsolete">HCO3-</translation>
    </message>
    <message>
        <source>Time:</source>
        <translation type="obsolete">时间</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="obsolete">确认</translation>
    </message>
    <message>
        <source>Bicarbonate:</source>
        <translation type="obsolete">HCO3-浓度：</translation>
    </message>
    <message>
        <source>HCO3-:</source>
        <translation type="obsolete">碳酸氢根:</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupBloodTemp</name>
    <message>
        <source>Blood Temp</source>
        <oldsource>Blood temperature</oldsource>
        <translation type="obsolete">血温</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bloodtemp.cpp" line="41"/>
        <source>Temp :</source>
        <oldsource>Temperature :</oldsource>
        <translation>温度:</translation>
    </message>
</context>
<context>
    <name>SceneSetupCureTime</name>
    <message>
        <source>Treat Time</source>
        <oldsource>Cure Time Setup</oldsource>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <source>Hour:</source>
        <translation type="obsolete">小时：</translation>
    </message>
    <message>
        <source>Minute:</source>
        <translation type="obsolete">分钟:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="248"/>
        <source>Time:</source>
        <translation>时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="435"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="437"/>
        <source>Treatment time:</source>
        <translation>治疗时间:</translation>
    </message>
    <message>
        <source>Treatment time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="438"/>
        <source>Min time</source>
        <translation>最小值</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="439"/>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="441"/>
        <source>/H:m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/hour</source>
        <translation type="obsolete">/小时</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="440"/>
        <source>Max time</source>
        <translation>最大值</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="436"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupCurveNa</name>
    <message>
        <source>Curve Na</source>
        <translation type="obsolete">Na曲线</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <source>Conductance(Na) Curve</source>
        <translation type="obsolete">总电导度(钠)曲线</translation>
    </message>
    <message>
        <source>Set all
period
value</source>
        <translation type="obsolete">设定全部
时段数值</translation>
    </message>
    <message>
        <source>Current
curve num</source>
        <translation type="obsolete">当前曲线
序号</translation>
    </message>
    <message>
        <source>The seleceed
period value
[ms/cm]</source>
        <translation type="obsolete">所选时段
数值
[ms/cm]</translation>
    </message>
    <message>
        <source>Browse
curve</source>
        <translation type="obsolete">浏览曲线</translation>
    </message>
    <message>
        <source>Sum UF</source>
        <translation type="obsolete">总超滤量</translation>
    </message>
    <message>
        <source>Treatment time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <source>Each period</source>
        <translation type="obsolete">每个时段</translation>
    </message>
    <message>
        <source>Not Selected</source>
        <translation type="obsolete">无选择时段</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">前翻</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">后翻</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">应用</translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <source>Define </source>
        <translation type="obsolete">预定义</translation>
    </message>
    <message>
        <source>Custom </source>
        <translation type="obsolete">自定义</translation>
    </message>
    <message>
        <source>Predefined curve can not modify!</source>
        <translation type="obsolete">预定义曲线不能修改!</translation>
    </message>
    <message>
        <source>This curve data run success!</source>
        <translation type="obsolete">本曲线数据应用成功!</translation>
    </message>
    <message>
        <source>An error occurred,run fail!</source>
        <translation type="obsolete">发生错误，应用失败!</translation>
    </message>
    <message>
        <source>Prompt</source>
        <translation type="obsolete">提示</translation>
    </message>
    <message>
        <source>This curve data save and run!</source>
        <translation type="obsolete">本曲线数据已保存并应用!</translation>
    </message>
</context>
<context>
    <name>SceneSetupCurveTest</name>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="12"/>
        <source>线性曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="13"/>
        <source>抛物线曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="14"/>
        <source>三次曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="15"/>
        <source>指数曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="16"/>
        <source>阶梯曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="17"/>
        <source>方波曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="18"/>
        <source>反方波曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="164"/>
        <source>超滤率曲线类型:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="165"/>
        <source>治疗时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="166"/>
        <source>脱水量</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="167"/>
        <source>初始化超滤值</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="168"/>
        <source>超滤最大值</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="169"/>
        <source>超滤最大值时刻</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="177"/>
        <source>修改</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupCurveUF</name>
    <message>
        <source>HD</source>
        <translation type="obsolete">透析</translation>
    </message>
    <message>
        <source>Sequential UF Curve</source>
        <translation type="obsolete">序贯超滤曲线</translation>
    </message>
    <message>
        <source>UF mode</source>
        <translation type="obsolete">超滤模式</translation>
    </message>
    <message>
        <source>Current
curve num</source>
        <translation type="obsolete">当前曲线
序号</translation>
    </message>
    <message>
        <source>The seleceed
period value
[%]</source>
        <translation type="obsolete">所选时段
数值
[%]</translation>
    </message>
    <message>
        <source>Browse
curve</source>
        <translation type="obsolete">浏览曲线</translation>
    </message>
    <message>
        <source>Sum UF</source>
        <translation type="obsolete">总超滤量</translation>
    </message>
    <message>
        <source>Treatment time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <source>Each period</source>
        <translation type="obsolete">每个时段</translation>
    </message>
    <message>
        <source>Not Selected</source>
        <translation type="obsolete">无选择时段</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">上翻</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">下翻</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">应用</translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <source>Define </source>
        <translation type="obsolete">预定义</translation>
    </message>
    <message>
        <source>Custom </source>
        <translation type="obsolete">自定义</translation>
    </message>
    <message>
        <source>Please select a columnar!</source>
        <translation type="obsolete">请选中一个时段!</translation>
    </message>
    <message>
        <source>Predefined curve can not modify!</source>
        <translation type="obsolete">预定义曲线不能修改!</translation>
    </message>
    <message>
        <source>This curve data run success!</source>
        <translation type="obsolete">本曲线数据应用成功!</translation>
    </message>
    <message>
        <source>An error occurred,run fail!</source>
        <translation type="obsolete">发生错误，应用失败!</translation>
    </message>
    <message>
        <source>Prompt</source>
        <translation type="obsolete">提示</translation>
    </message>
    <message>
        <source>This curve data save and run!</source>
        <translation type="obsolete">本曲线数据已保存并应用!</translation>
    </message>
</context>
<context>
    <name>SceneSetupDialysate</name>
    <message>
        <source>Dialysate Setup</source>
        <translation type="obsolete">透析液</translation>
    </message>
    <message>
        <source>Concentration Na+:</source>
        <translation type="obsolete">Na+浓度：</translation>
    </message>
    <message>
        <source>Concentration HCO3-:</source>
        <translation type="obsolete">HCO3-浓度：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="218"/>
        <source>Na+:</source>
        <translation>钠浓度:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="219"/>
        <source>HCO3-:</source>
        <translation>碳酸氢根:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="220"/>
        <source>Dialysate Flow:</source>
        <translation>透析液流速:</translation>
    </message>
    <message>
        <source>Dialysis Fluid:</source>
        <translation type="obsolete">透析液流速：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="222"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="224"/>
        <source>Profile</source>
        <translation>曲线</translation>
    </message>
    <message>
        <source>Dialysate Flux:</source>
        <oldsource>Dialysate Speed:</oldsource>
        <translation type="obsolete">透析液流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="221"/>
        <source>Dialysate Temp:</source>
        <oldsource>Dialysate Temperature:</oldsource>
        <translation>透析液温度:</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="223"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <source>Curve</source>
        <translation type="obsolete">曲线</translation>
    </message>
</context>
<context>
    <name>SceneSetupEC</name>
    <message>
        <source>Conductivity</source>
        <translation type="obsolete">电导度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="19"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="43"/>
        <source>Na+:</source>
        <translation>钠浓度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="26"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="42"/>
        <source>Cond:</source>
        <translation>电导率</translation>
    </message>
    <message>
        <source>Na Concentration:</source>
        <translation type="obsolete">Na+浓度：</translation>
    </message>
    <message>
        <source>Conductivity:</source>
        <translation type="obsolete">电导度：</translation>
    </message>
</context>
<context>
    <name>SceneSetupHemoManometer</name>
    <message>
        <source>Hemomanometer</source>
        <translation type="obsolete">血压计</translation>
    </message>
</context>
<context>
    <name>SceneSetupHemopump</name>
    <message>
        <source>Blood Pump</source>
        <oldsource>Hemo Pump</oldsource>
        <translation type="obsolete">血泵</translation>
    </message>
    <message>
        <source>Hemo Pump Speed:</source>
        <translation type="obsolete">血泵流速:</translation>
    </message>
    <message>
        <source>Hemo Pump Caliber:</source>
        <translation type="obsolete">血泵管径:</translation>
    </message>
    <message>
        <source>Supply Pump Speed:</source>
        <translation type="obsolete">补充泵流速:</translation>
    </message>
    <message>
        <source>Supply Pump Caliber:</source>
        <translation type="obsolete">补充泵管径:</translation>
    </message>
    <message>
        <source>Hemo Total:</source>
        <translation type="obsolete">血流累积量:</translation>
    </message>
    <message>
        <source>Supply Pump Used by Hemo:</source>
        <translation type="obsolete">补充泵做血泵:</translation>
    </message>
    <message>
        <source>Blood Flux:</source>
        <translation type="obsolete">血泵流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="371"/>
        <source>Supply Flux:</source>
        <translation>补充泵流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="372"/>
        <source>Blood Volume:</source>
        <translation>血流累计量:</translation>
    </message>
    <message>
        <source>Supply Pump Used by Blood:</source>
        <translation type="obsolete">补充泵做血泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="374"/>
        <source>yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="375"/>
        <source>no</source>
        <translation>否</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="377"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="230"/>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="378"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="183"/>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="370"/>
        <source>Blood Flow:</source>
        <translation>血泵流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="232"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="373"/>
        <source>Regard spare pump as blood pump:</source>
        <translation>补充泵做血泵:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="376"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
</context>
<context>
    <name>SceneSetupHeparin</name>
    <message>
        <source>Heparin</source>
        <translation type="obsolete">肝素泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="646"/>
        <source>Syringe Type:</source>
        <oldsource>Syringe style:</oldsource>
        <translation>注射器类型:</translation>
    </message>
    <message>
        <source>Shot Total:</source>
        <translation type="obsolete">注射总量：</translation>
    </message>
    <message>
        <source>First Dose:</source>
        <translation type="obsolete">首剂量</translation>
    </message>
    <message>
        <source>Shot Speed:</source>
        <translation type="obsolete">注射速率：</translation>
    </message>
    <message>
        <source>Pre-Stop time:</source>
        <translation type="obsolete">预先停止时间</translation>
    </message>
    <message>
        <source>Shot Signal:</source>
        <translation type="obsolete">单次注射量：</translation>
    </message>
    <message>
        <source>Injected Vol.:</source>
        <translation type="obsolete">注射器容量</translation>
    </message>
    <message>
        <source>Inject Flux:</source>
        <translation type="obsolete">推注速度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="255"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="651"/>
        <source>BOLUS:</source>
        <translation>肝素追加量:</translation>
    </message>
    <message>
        <source>Injected Vol:</source>
        <translation type="obsolete">肝素累计量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="652"/>
        <source>Heparin Enable</source>
        <translation>使用肝素泵</translation>
    </message>
    <message>
        <source>yes</source>
        <translation type="obsolete">是</translation>
    </message>
    <message>
        <source>no</source>
        <translation type="obsolete">否</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="654"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="376"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="655"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="197"/>
        <source>/Config/Engineer_Factoryset/HeparinMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="229"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="648"/>
        <source>Initial Dose:</source>
        <translation>首剂量:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="235"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="649"/>
        <source>Dose rate:</source>
        <translation>注射速率:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="241"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="650"/>
        <source>Stop time:</source>
        <translation>预先停止时间:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="368"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="647"/>
        <source>Acc heparin:</source>
        <translation>肝素已注量：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="653"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Heparin additional quantity:</source>
        <translation type="obsolete">追加量：</translation>
    </message>
    <message>
        <source>Heparin time:</source>
        <translation type="obsolete">使用时间：</translation>
    </message>
</context>
<context>
    <name>SceneSetupIsoUF</name>
    <message>
        <source>ISO UF Setup</source>
        <translation type="obsolete">单超</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="373"/>
        <source>ISO UF Time:</source>
        <translation>单超时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="89"/>
        <source>ISO UF Hour:</source>
        <translation>单超时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="94"/>
        <source>ISO UF Min:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="99"/>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="375"/>
        <source>ISO UF Goal:</source>
        <oldsource>ISO UF Total:</oldsource>
        <translation>单超总量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="376"/>
        <source>ISO UF Volume:</source>
        <translation>已单超量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="377"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="378"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupLang</name>
    <message>
        <source>Language</source>
        <translation type="obsolete">语言</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_lang.cpp" line="219"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_lang.cpp" line="220"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <source>chinese</source>
        <translation type="obsolete">中文</translation>
    </message>
    <message>
        <source>english</source>
        <translation type="obsolete">英文</translation>
    </message>
</context>
<context>
    <name>SceneSetupNaUF</name>
    <message>
        <source>Na+.UF</source>
        <oldsource>Na.UF</oldsource>
        <translation type="obsolete">Na+,超滤曲线</translation>
    </message>
    <message>
        <source>Prompt</source>
        <translation type="obsolete">计时器时间到</translation>
    </message>
    <message>
        <source>This curve data run success!</source>
        <translation type="obsolete">本曲线数据应用成功!</translation>
    </message>
    <message>
        <source>Na+ Profile:</source>
        <oldsource>Na+ Curve:</oldsource>
        <translation type="obsolete">钠曲线</translation>
    </message>
    <message>
        <source>UF Profile:</source>
        <oldsource>UF Curve:</oldsource>
        <translation type="obsolete">超滤曲线</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">应用</translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_nauf.cpp" line="427"/>
        <source>Na+ Profile</source>
        <translation type="unfinished">钠曲线</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_nauf.cpp" line="428"/>
        <source>UF Profile</source>
        <translation type="unfinished">超滤曲线</translation>
    </message>
</context>
<context>
    <name>SceneSetupNetwork</name>
    <message>
        <source>Network</source>
        <translation type="obsolete">网络</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="269"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="271"/>
        <source>Set</source>
        <translation>参数设置</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="273"/>
        <source>Ip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="274"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="282"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="286"/>
        <source>192</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="275"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="283"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="287"/>
        <source>168</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="276"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="284"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="289"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="277"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="278"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="279"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="280"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="285"/>
        <source>255</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="281"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="288"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="92"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="93"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="94"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="95"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="290"/>
        <source>Mask:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="87"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="88"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="89"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="90"/>
        <source>IP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="97"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="98"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="99"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="100"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="291"/>
        <source>Gateway:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="102"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="103"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="104"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="105"/>
        <source>Dns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="268"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="272"/>
        <source>Parameter of Network:</source>
        <translation>网络参数:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="292"/>
        <source>DNS:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="295"/>
        <source>Init wlan</source>
        <translation>初始化无线网络</translation>
    </message>
</context>
<context>
    <name>SceneSetupOximeter</name>
    <message>
        <source>Oximeter</source>
        <translation type="obsolete">血氧</translation>
    </message>
    <message>
        <source>Oximeter :</source>
        <translation type="obsolete">血氧:</translation>
    </message>
</context>
<context>
    <name>SceneSetupPreflush</name>
    <message>
        <source>Preflush Blood Pump Speed</source>
        <translation type="obsolete">预冲血泵流速</translation>
    </message>
    <message>
        <source>Dialysate Flow</source>
        <translation type="obsolete">透析液流速</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="358"/>
        <source>Preflush Time</source>
        <translation>预冲时间</translation>
    </message>
    <message>
        <source>Preflush Uf Rate</source>
        <translation type="obsolete">预冲超滤速度</translation>
    </message>
    <message>
        <source>Preflush Uf Volume</source>
        <translation type="obsolete">预冲超滤量</translation>
    </message>
    <message>
        <source>Return Blood Volume</source>
        <translation type="obsolete">引血量</translation>
    </message>
    <message>
        <source>Conect Blood Pump Speed</source>
        <translation type="obsolete">连接患者的血液流速</translation>
    </message>
    <message>
        <source>TMP Up</source>
        <translation type="obsolete">跨膜压上限</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="364"/>
        <source>Preflush Volume</source>
        <translation>预冲量</translation>
    </message>
    <message>
        <source>Already Preflush Volume</source>
        <translation type="obsolete">已预冲量</translation>
    </message>
    <message>
        <source>Auto Preflush</source>
        <translation type="obsolete">自动预冲</translation>
    </message>
    <message>
        <source>Manual Operation</source>
        <translation type="obsolete">手动操作</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Online Preflush</source>
        <translation type="obsolete">在线预冲</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="352"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="354"/>
        <source>Blood Pump Flow</source>
        <translation>血泵流速</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="356"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="360"/>
        <source>Uf Rate</source>
        <translation>超滤率</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="362"/>
        <source>Uf Volume</source>
        <translation>预冲超滤量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="366"/>
        <source>Acc Preflush Volume</source>
        <translation>累计预冲量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="369"/>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="371"/>
        <source>Manual</source>
        <translation>手动</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="372"/>
        <source>Online</source>
        <translation>在线</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="373"/>
        <source>Enable online lead-in</source>
        <translation>开启在线引血</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="374"/>
        <source>Disable online lead-in</source>
        <translation>关闭在线引血</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="375"/>
        <source>Enable online return</source>
        <translation>开启在线回血</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="376"/>
        <source>Disable online return</source>
        <translation>关闭在线回血</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="378"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="380"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="635"/>
        <source>Preflush BP Speed:</source>
        <translation>手动预冲血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="641"/>
        <source>Preflush Blood Pump Speed:</source>
        <translation>自动预冲血泵速度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="647"/>
        <source>Dialysate Flow:</source>
        <translation>手动预冲超滤率</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="659"/>
        <source>Preflush Uf Rate:</source>
        <translation>预冲超滤率</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="665"/>
        <source>Preflush Uf Volume:</source>
        <translation>预冲超滤量</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="671"/>
        <source>Return Blood Volume:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupPressure</name>
    <message>
        <source>Pressure Setup</source>
        <translation type="obsolete">压力</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="obsolete">自动</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="obsolete">手动</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Confirm</source>
        <translation type="obsolete">确认</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <source>A.P. :</source>
        <translation type="obsolete">动脉压</translation>
    </message>
    <message>
        <source>A.P. Upper:</source>
        <translation type="obsolete">动脉压上限</translation>
    </message>
    <message>
        <source>A.P. Lower:</source>
        <translation type="obsolete">动脉压下限</translation>
    </message>
    <message>
        <source>V.P. :</source>
        <translation type="obsolete">静脉压</translation>
    </message>
    <message>
        <source>V.P. Upper:</source>
        <translation type="obsolete">静脉压上限</translation>
    </message>
    <message>
        <source>V.P. Lower:</source>
        <translation type="obsolete">静脉压下限</translation>
    </message>
    <message>
        <source>TMP :</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
    <message>
        <source>TMP Upper:</source>
        <translation type="obsolete">跨膜压上限</translation>
    </message>
    <message>
        <source>TMP Lower:</source>
        <translation type="obsolete">跨膜压下限</translation>
    </message>
    <message>
        <source>Arterial Pressure:</source>
        <translation type="obsolete">动脉压:</translation>
    </message>
    <message>
        <source>Arterial Pressure High:</source>
        <translation type="obsolete">动脉压上限:</translation>
    </message>
    <message>
        <source>Arterial Pressure Low:</source>
        <translation type="obsolete">动脉限下限:</translation>
    </message>
    <message>
        <source>Venous Pressure:</source>
        <translation type="obsolete">静脉压:</translation>
    </message>
    <message>
        <source>Venous Pressure High:</source>
        <translation type="obsolete">静脉压上限:</translation>
    </message>
    <message>
        <source>Venous Pressure Low:</source>
        <translation type="obsolete">静脉压下限:</translation>
    </message>
    <message>
        <source>Transmembrane:</source>
        <translation type="obsolete">跨膜压:</translation>
    </message>
    <message>
        <source>Transmembrane High:</source>
        <translation type="obsolete">跨膜压上限:</translation>
    </message>
    <message>
        <source>Transmembrane Low:</source>
        <translation type="obsolete">跨膜压下限:</translation>
    </message>
    <message>
        <source>A.P Alarm width:</source>
        <translation type="obsolete">动脉压报警宽度:</translation>
    </message>
    <message>
        <source>V.P Alarm width:</source>
        <translation type="obsolete">静脉压报警宽度:</translation>
    </message>
    <message>
        <source>TMP Alarm width:</source>
        <translation type="obsolete">跨膜压报警宽度:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="406"/>
        <source>A.P Alarm Range:</source>
        <translation>动脉压报警宽度:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="407"/>
        <source>V.P Alarm Range:</source>
        <translation>静脉压报警宽度:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="408"/>
        <source>TMP Alarm Range:</source>
        <translation>跨膜压报警宽度:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="409"/>
        <source>Max TMP:</source>
        <translation>最大跨膜压:</translation>
    </message>
</context>
<context>
    <name>SceneSetupProfile</name>
    <message>
        <source>Profile</source>
        <translation type="obsolete">序贯：</translation>
    </message>
</context>
<context>
    <name>SceneSetupSequential</name>
    <message>
        <source>Sequential</source>
        <oldsource>Sequential Dialysis</oldsource>
        <translation type="obsolete">序贯透析</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">返回</translation>
    </message>
    <message>
        <source>Prompt</source>
        <translation type="obsolete">计时器时间到</translation>
    </message>
    <message>
        <source>This curve data run success!</source>
        <translation type="obsolete">本曲线数据应用成功!</translation>
    </message>
    <message>
        <source>UF Profile:</source>
        <translation type="obsolete">超滤曲线</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">应用</translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="obsolete">返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupSpO2</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_oximeter.cpp" line="153"/>
        <source>SpO2 :</source>
        <translation>血氧浓度:</translation>
    </message>
</context>
<context>
    <name>SceneSetupSubspump</name>
    <message>
        <source>Substitution Pump</source>
        <oldsource>Substitution Fluid Pump</oldsource>
        <translation type="obsolete">置换液泵</translation>
    </message>
    <message>
        <source>Substitution Fluid Speed:</source>
        <translation type="obsolete">置换液流速：</translation>
    </message>
    <message>
        <source>Substitution Fluid Total:</source>
        <translation type="obsolete">置换液总量：</translation>
    </message>
    <message>
        <source>Substitution Fluid Already:</source>
        <translation type="obsolete">已置换液量：</translation>
    </message>
    <message>
        <source>Fluid additional Already:</source>
        <translation type="obsolete">已补液量：</translation>
    </message>
    <message>
        <source>Fluid additional:</source>
        <translation type="obsolete">快速补液：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="57"/>
        <source>80</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="58"/>
        <source>160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="59"/>
        <source>240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="60"/>
        <source>320</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="61"/>
        <source>400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="62"/>
        <source>480</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="63"/>
        <source>560</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="186"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="383"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="201"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="227"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="392"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="215"/>
        <source>Dilute Type:</source>
        <translation>稀释类型:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="216"/>
        <source>UF/BP:</source>
        <translation>超滤/血液流速比:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="217"/>
        <source>Blood Flow:</source>
        <translation>血泵流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="218"/>
        <source>Dialysate Flow:</source>
        <translation>透析液流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="220"/>
        <source>Sub. Flux:</source>
        <translation>置换泵流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="221"/>
        <source>Sub. Goal:</source>
        <translation>置换目标量:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="222"/>
        <source>Sub. Vol:</source>
        <translation>已置换量:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="223"/>
        <source>Rapid Infusion Vol:</source>
        <translation>已补液量:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="224"/>
        <source>Rapid Infusion Rate:</source>
        <translation>单次在线补液量:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="225"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="264"/>
        <source>Pre Dilute</source>
        <translation>前稀释</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="268"/>
        <source>Post Dilute</source>
        <translation>后稀释</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="452"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="459"/>
        <source>SUB speed:</source>
        <translation>置换液流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="453"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="465"/>
        <source>SUB total:</source>
        <translation>置换目标:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="471"/>
        <source>SUB Add:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="226"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <source>Fluid additional Already</source>
        <translation type="obsolete">已补液量：</translation>
    </message>
</context>
<context>
    <name>SceneSetupSysinfo</name>
    <message>
        <source>System info</source>
        <translation type="obsolete">系统信息</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="89"/>
        <source>Soft Version:</source>
        <translation>软件版本</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="90"/>
        <source>Manufacture date:</source>
        <translation>生产日期:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="91"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Produce Time:</source>
        <translation type="obsolete">生产日期</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="92"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupSystemTime</name>
    <message>
        <source>Systom Time</source>
        <translation type="obsolete">系统时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="92"/>
        <source>Date:</source>
        <translation>日期</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="93"/>
        <source>Time:</source>
        <translation>时间</translation>
    </message>
    <message>
        <source>Zone:</source>
        <translation type="obsolete">时区</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="40"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="95"/>
        <source>China</source>
        <translation>中国</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="41"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="96"/>
        <source>Japan</source>
        <translation>日本</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="42"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="97"/>
        <source>India</source>
        <translation>印度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="43"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="98"/>
        <source>Indonesia</source>
        <translation>印尼</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="44"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="99"/>
        <source>Malaysia</source>
        <translation>马来西亚</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="45"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="100"/>
        <source>Vietnam</source>
        <translation>越南</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="94"/>
        <source>Time Zone:</source>
        <translation>时区:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="101"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="102"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupUf</name>
    <message>
        <source>UF</source>
        <translation type="obsolete">超滤</translation>
    </message>
    <message>
        <source>ultrafiltration target:</source>
        <translation type="obsolete">超滤目标：</translation>
    </message>
    <message>
        <source>ultrafiltration rate:</source>
        <translation type="obsolete">超滤率：</translation>
    </message>
    <message>
        <source>The actual amount of ultrafiltration:</source>
        <translation type="obsolete">实际超滤量：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="222"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="229"/>
        <source>UF Goal:</source>
        <translation>超滤目标</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="223"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="235"/>
        <source>UF rate:</source>
        <translation>超滤速度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="392"/>
        <source>Treatment UF Goal:</source>
        <translation>治疗超滤目标:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="393"/>
        <source>Treatment UF Rate:</source>
        <translation>治疗超滤速度:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="394"/>
        <source>Now Rate:</source>
        <translation>当前流速:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="400"/>
        <source>Cure UF Goal:</source>
        <translation>治疗超滤目标:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="401"/>
        <source>Cure UF rate:</source>
        <translation>治疗超滤率:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="402"/>
        <source>Now rate:</source>
        <translation>当前超滤率:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="395"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="403"/>
        <source>Acc UF Volume:</source>
        <translation>已超滤量:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="396"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="404"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="398"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="406"/>
        <source>Profile</source>
        <translation>曲线</translation>
    </message>
    <message>
        <source>UF Volume:</source>
        <translation type="obsolete">超滤量</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="397"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="405"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <source>Curve</source>
        <translation type="obsolete">曲线</translation>
    </message>
    <message>
        <source>UF Time:</source>
        <oldsource>UF time:</oldsource>
        <translation type="obsolete">超滤时间：</translation>
    </message>
    <message>
        <source>Blood Speed:</source>
        <translation type="obsolete">血流量：</translation>
    </message>
</context>
<context>
    <name>SceneSetupUnit</name>
    <message>
        <source>Unit</source>
        <translation type="obsolete">单位</translation>
    </message>
    <message>
        <source>Unit Conversion</source>
        <translation type="obsolete">单位切换</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="45"/>
        <source>Length:</source>
        <translation>长度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="46"/>
        <source>Pressure:</source>
        <translation>压力</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="47"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="48"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>SceneSetupWorkmode</name>
    <message>
        <source>     Please confirm !</source>
        <translation type="obsolete">请确认！</translation>
    </message>
    <message>
        <source>Would you like to change workmodel ?</source>
        <translation type="obsolete">改变治疗模式吗？</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="938"/>
        <source>HD</source>
        <translation>透析</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="939"/>
        <source>Single Needle</source>
        <translation>单针单泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="940"/>
        <source>SNDP</source>
        <translation>单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="941"/>
        <source>Double Needle</source>
        <translation>双针</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="943"/>
        <source>HDF (Online)</source>
        <translation>在线血液透析滤过</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="944"/>
        <source>HF (Online)</source>
        <translation>在线血液滤过</translation>
    </message>
    <message>
        <source>Pre-dilute</source>
        <translation type="obsolete">前稀释</translation>
    </message>
    <message>
        <source>Post-dilute</source>
        <translation type="obsolete">后稀释</translation>
    </message>
    <message>
        <source>HFPre-dilute</source>
        <translation type="obsolete">前稀释</translation>
    </message>
    <message>
        <source>HFPost-dilute</source>
        <translation type="obsolete">前稀释</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="949"/>
        <source>ISO UF</source>
        <oldsource>Iosuf</oldsource>
        <translation>单超</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="950"/>
        <source>PE/HP</source>
        <translation>血浆置换/血液灌流</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="951"/>
        <source>A + B</source>
        <translation>A液+B液</translation>
    </message>
    <message>
        <source>A + B(Dry)</source>
        <translation type="obsolete">A液+B干粉</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="954"/>
        <source>Central fluid supply</source>
        <translation>中央供液</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="955"/>
        <source>Work Mode</source>
        <translation>工作模式</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="956"/>
        <source>Treatmemt Mode:</source>
        <translation>治疗模式：</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="957"/>
        <source>Supply Fluid Mode:</source>
        <translation>供液模式：</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Pre-dilution</source>
        <translation type="obsolete">前稀释</translation>
    </message>
    <message>
        <source>Post-dilution</source>
        <translation type="obsolete">后稀释</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="945"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="947"/>
        <source>Predilution</source>
        <translation>前稀释</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="946"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="948"/>
        <source>Postdilution</source>
        <translation>后稀释</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="952"/>
        <source>A + B(Dry Powder)</source>
        <translation>A+B（干粉）</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="958"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="959"/>
        <source>Cancel</source>
        <translation>返回</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="960"/>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="961"/>
        <source>NaAc:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="962"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="986"/>
        <source>g/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="964"/>
        <source>Na:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="965"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="968"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="971"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="974"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="977"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="980"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="983"/>
        <source>mmol/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="967"/>
        <source>Cl:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="970"/>
        <source>K:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="973"/>
        <source>HCO3:</source>
        <translation>HCO3:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="976"/>
        <source>Mg:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="979"/>
        <source>Acetate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="982"/>
        <source>Ca:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="985"/>
        <source>B)NaCl:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HDF(online)</source>
        <translation type="obsolete">透析滤过</translation>
    </message>
    <message>
        <source>Dilute Front</source>
        <translation type="obsolete">前稀释</translation>
    </message>
    <message>
        <source>Dilute Behind</source>
        <translation type="obsolete">后稀释</translation>
    </message>
    <message>
        <source>A fluid + B fluid</source>
        <translation type="obsolete">A液+B液</translation>
    </message>
    <message>
        <source>A fluid + B powdery</source>
        <translation type="obsolete">A液+B粉</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="953"/>
        <source>Acetate</source>
        <translation>醋酸盐</translation>
    </message>
    <message>
        <source>Centre Inflow</source>
        <translation type="obsolete">中央供液</translation>
    </message>
    <message>
        <source>Needle Single</source>
        <translation type="obsolete">单针</translation>
    </message>
    <message>
        <source>Needle Double</source>
        <translation type="obsolete">双针</translation>
    </message>
    <message>
        <source>Work Mode.</source>
        <translation type="obsolete">工作模式</translation>
    </message>
    <message>
        <source>Cure Mode:</source>
        <translation type="obsolete">治疗模式：</translation>
    </message>
    <message>
        <source>Feed Mode:</source>
        <translation type="obsolete">供液模式：</translation>
    </message>
    <message>
        <source>Other:</source>
        <translation type="obsolete">其它：</translation>
    </message>
</context>
<context>
    <name>SceneSetupXmlconfig</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="57"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="58"/>
        <source>Config files (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="70"/>
        <source>update ok!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="79"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="91"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="79"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="91"/>
        <source>Config Files (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="109"/>
        <source>save fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="123"/>
        <source>save ok!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="129"/>
        <source>Load File :</source>
        <translation>加载文件:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="130"/>
        <source>Save File:</source>
        <translation>保存文件:</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="131"/>
        <source>Load</source>
        <translation>加载</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="132"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="133"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="134"/>
        <source>Cancel</source>
        <translation type="unfinished">返回</translation>
    </message>
</context>
<context>
    <name>SceneSummary</name>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="341"/>
        <source>Summary Info</source>
        <translation>信息简要</translation>
    </message>
    <message>
        <source>Time Left :</source>
        <translation type="obsolete">剩余时间：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="347"/>
        <source>UF Rate :</source>
        <translation>超滤率：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="348"/>
        <source>UF Goal :</source>
        <translation>预置量：</translation>
    </message>
    <message>
        <source>UF Volume :</source>
        <translation type="obsolete">当前超滤量：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="344"/>
        <source>Curve Type :</source>
        <translation>治疗类型：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="345"/>
        <source>Dilution Type :</source>
        <translation>稀释类型：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="346"/>
        <source>Remaining Time :</source>
        <translation>剩余时间：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="349"/>
        <source>Acc UF Volume :</source>
        <translation>已超滤量:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="350"/>
        <source>A.P. :</source>
        <translation>动脉压：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="351"/>
        <source>V.P. :</source>
        <translation>静脉压：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="352"/>
        <source>TMP :</source>
        <translation>跨膜压：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="357"/>
        <source>BP Flow :</source>
        <translation>血泵流速：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="358"/>
        <source>Sub. Goal :</source>
        <translation>置换目标：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="359"/>
        <source>Sub. Vol :</source>
        <translation>已置换量：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="360"/>
        <source>Dialysate Flow :</source>
        <translation>透析液流速:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="362"/>
        <source>Cond Profile:</source>
        <translation>钠电导曲线</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="363"/>
        <source>UF Profile:</source>
        <translation>超滤曲线</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="478"/>
        <source>Pre Dilute</source>
        <translation>前稀释</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="482"/>
        <source>Post Dilute</source>
        <translation>后稀释</translation>
    </message>
    <message>
        <source>Dialysis Fluid Flow :</source>
        <translation type="obsolete">透析液流速：</translation>
    </message>
    <message>
        <source>Cond Curve:</source>
        <translation type="obsolete">电导图表：</translation>
    </message>
    <message>
        <source>UF Curve:</source>
        <translation type="obsolete">超滤图表：</translation>
    </message>
    <message>
        <source>Na+ :</source>
        <translation type="obsolete">钠：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="353"/>
        <source>Cond. :</source>
        <translation>电导率：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="354"/>
        <source>Temp :</source>
        <translation>透析温度：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="355"/>
        <source>Heparin Flux:</source>
        <translation>肝素速率：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="356"/>
        <source>Heparin Vol :</source>
        <translation>肝素已注量：</translation>
    </message>
    <message>
        <source>BP Speed :</source>
        <translation type="obsolete">血泵流速：</translation>
    </message>
    <message>
        <source>Dialysis Flux :</source>
        <translation type="obsolete">透析液流速：</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="361"/>
        <source>Blood Temp :</source>
        <oldsource>Blood TEMP :</oldsource>
        <translation>血温：</translation>
    </message>
</context>
<context>
    <name>SceneTransmembrane</name>
    <message>
        <source>Transmembrane</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
</context>
<context>
    <name>SceneUfTarget</name>
    <message>
        <source>UF</source>
        <translation type="obsolete">超滤</translation>
    </message>
</context>
<context>
    <name>SceneVenousPressure</name>
    <message>
        <source>Venous Pressure</source>
        <translation type="obsolete">静脉压</translation>
    </message>
</context>
<context>
    <name>SceneWarn</name>
    <message>
        <source>Warn</source>
        <translation type="obsolete">报警</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">保存</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">时间</translation>
    </message>
</context>
<context>
    <name>Scene_Drain_Option</name>
    <message>
        <location filename="../../src/debug_mode/scene_drain_option/scene_drain_option.cpp" line="19"/>
        <source>Drain option</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Project_Param</name>
    <message>
        <location filename="../../src/debug_mode/scene_project_param/scene_project_param.cpp" line="18"/>
        <source>Project param</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Setup_Param</name>
    <message>
        <location filename="../../src/debug_mode/scene_setup_param/scene_setup_param.cpp" line="19"/>
        <source>Setup parm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Ts_Debug</name>
    <message>
        <location filename="../../src/debug_mode/scene_ts_debug/scene_ts_debug.cpp" line="19"/>
        <source>TS debug</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Use_Time</name>
    <message>
        <location filename="../../src/debug_mode/scene_use_time/scene_use_time.cpp" line="19"/>
        <source>Use time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_User_Param</name>
    <message>
        <location filename="../../src/debug_mode/scene_user_param/scene_user_param.cpp" line="19"/>
        <source>User param</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Water_Test</name>
    <message>
        <location filename="../../src/debug_mode/scene_water_test/scene_water_test.cpp" line="19"/>
        <source>Water test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenSnaper</name>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="110"/>
        <source>save image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="111"/>
        <source>Image(*.jpg *.png *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="122"/>
        <source>quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="127"/>
        <source>save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="178"/>
        <source>/hjx.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="180"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="182"/>
        <source>%1 Files (*.%2);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserDataRequest</name>
    <message>
        <location filename="../../src/wlan/userdatarequest.cpp" line="86"/>
        <source>Authentication credentials required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/userdatarequest.cpp" line="89"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/userdatarequest.cpp" line="91"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WIDGET_TEMPERATURE</name>
    <message>
        <source>T</source>
        <translation type="obsolete">温度</translation>
    </message>
</context>
<context>
    <name>WidgetAimConfig</name>
    <message>
        <source>Hemo Pump</source>
        <translation type="obsolete">血泵</translation>
    </message>
    <message>
        <source>Dialysis Liquid Temp</source>
        <oldsource>Dialysis Liquid</oldsource>
        <translation type="obsolete">透析液温度</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="389"/>
        <source>UF Goal</source>
        <oldsource>UF Target</oldsource>
        <translation type="unfinished">超滤目标</translation>
    </message>
    <message>
        <source>Ultrafiltration Target</source>
        <translation type="obsolete">超滤目标</translation>
    </message>
    <message>
        <source>Subs Pump</source>
        <translation type="obsolete">置换泵</translation>
    </message>
    <message>
        <source>Dialysis Aim</source>
        <translation type="obsolete">超滤目标</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="225"/>
        <source>ISO Goal</source>
        <translation>ISO目标</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="387"/>
        <source>Blood Pump</source>
        <translation>血泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="388"/>
        <source>Temperature</source>
        <translation>透析温度</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="392"/>
        <source>ISO time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temp. of Dialysate</source>
        <translation type="obsolete">透析液温度</translation>
    </message>
    <message>
        <source>ISO Remaining time:</source>
        <translation type="obsolete">单超剩余时间:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="240"/>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="390"/>
        <source>Sub. Pump</source>
        <translation>置换泵</translation>
    </message>
</context>
<context>
    <name>WidgetCheckItem</name>
    <message>
        <source>Item name</source>
        <translation type="obsolete">自检项目</translation>
    </message>
</context>
<context>
    <name>WidgetCheckSelf</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_check_self.cpp" line="93"/>
        <source>Self-testing</source>
        <translation>正在自检</translation>
    </message>
</context>
<context>
    <name>WidgetCrossExtern</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="95"/>
        <source>Work mode</source>
        <translation>工作模式</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="96"/>
        <source>Parameters</source>
        <translation>治疗参数</translation>
    </message>
    <message>
        <source>Cure infor</source>
        <translation type="obsolete">治疗参数</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="97"/>
        <source>Advanced</source>
        <translation>高级设置</translation>
    </message>
    <message>
        <source>Dialysis liquid</source>
        <translation type="obsolete">透析液</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="98"/>
        <source>Other</source>
        <translation>其它</translation>
    </message>
</context>
<context>
    <name>WidgetDisinfectRadioButton</name>
    <message>
        <source>Hot flush</source>
        <translation type="obsolete">热冲</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="124"/>
        <source>Rinse Selected</source>
        <translation>选择了冲洗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="129"/>
        <source>Hot Rinse Selected</source>
        <translation>选择了热冲洗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="135"/>
        <source>Chymistry Peracetic Selecte</source>
        <translation>选择了过氧乙酸消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="139"/>
        <source>Chymistry Citric Selecte</source>
        <translation>选择了柠檬酸消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="143"/>
        <source>Chymistry Reserve3 Selecte</source>
        <translation>选择了次氯酸钠消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="147"/>
        <source>Chymistry Disinfect Error!</source>
        <translation>无选择!</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="152"/>
        <source>Hot Disinfect Selected</source>
        <translation>选择了热消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="156"/>
        <source>Hot CitricAcid Selected</source>
        <translation>选择了柠檬酸热消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="162"/>
        <source>Central Hot Selected</source>
        <translation>选择了中央热消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="166"/>
        <source>Central Chemical Selected</source>
        <translation>选择了中央化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="170"/>
        <source>Central Disinfect Error!</source>
        <translation>中央消毒选择错误</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="178"/>
        <source>No Work Model Selected</source>
        <translation>没有选择消毒模式</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="180"/>
        <source>Rinse</source>
        <translation>冲洗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="183"/>
        <source>Chemical Disinfect</source>
        <translation>化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="185"/>
        <source>Hot Disinfect</source>
        <translation>热消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="187"/>
        <source>Central Disinfect Mode</source>
        <translation>中央消毒</translation>
    </message>
    <message>
        <source>Central Disinfect</source>
        <translation type="obsolete">中央消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="188"/>
        <source>Hot Acid</source>
        <translation>柠檬酸热消毒</translation>
    </message>
    <message>
        <source>Hot Chemical Disinfect</source>
        <translation type="obsolete">热化学消毒</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="181"/>
        <source>Hot Rinse</source>
        <translation>热冲洗</translation>
    </message>
    <message>
        <source>Sodium citrate(60 &apos;C)</source>
        <oldsource>Sodiun citrate(60)</oldsource>
        <translation type="obsolete">柠檬酸（60度）</translation>
    </message>
    <message>
        <source>Peracetic acid</source>
        <translation type="obsolete">过氧乙酸</translation>
    </message>
    <message>
        <source>Chloros</source>
        <translation type="obsolete">次氯酸钠</translation>
    </message>
    <message>
        <source>Sodium citrate</source>
        <translation type="obsolete">柠檬酸</translation>
    </message>
    <message>
        <source>Sodium citrate(85 &apos;C)</source>
        <oldsource>Sodiun citrate(85)</oldsource>
        <translation type="obsolete">柠檬酸（85度）</translation>
    </message>
</context>
<context>
    <name>WidgetIms</name>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="11"/>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="151"/>
        <source>IMS</source>
        <translation>信息管理</translation>
    </message>
    <message>
        <source>Log Treat</source>
        <translation type="obsolete">治疗日志</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="153"/>
        <source>Log Warn</source>
        <translation>报警日志</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="154"/>
        <source>Log Run</source>
        <translation>运行日志</translation>
    </message>
    <message>
        <source>Log EMR</source>
        <translation type="obsolete">病历库</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="156"/>
        <source>Record Profile</source>
        <translation>记录曲线</translation>
    </message>
    <message>
        <source>Record Curve</source>
        <translation type="obsolete">记录曲线</translation>
    </message>
    <message>
        <source>Treat Log</source>
        <oldsource>Treatment Log</oldsource>
        <translation type="obsolete">治疗日志</translation>
    </message>
    <message>
        <source>Warn Log</source>
        <translation type="obsolete">警告日志</translation>
    </message>
    <message>
        <source>Run Log</source>
        <translation type="obsolete">运行日志</translation>
    </message>
    <message>
        <source>EMR Log</source>
        <translation type="obsolete">病例管理</translation>
    </message>
</context>
<context>
    <name>WidgetMaintain</name>
    <message>
        <source>Maintain</source>
        <translation type="obsolete">维护</translation>
    </message>
    <message>
        <source>Update System</source>
        <translation type="obsolete">系统升级</translation>
    </message>
</context>
<context>
    <name>WidgetNotice</name>
    <message>
        <source>Double needle Dry purify Cure</source>
        <translation type="obsolete">双针干超治疗</translation>
    </message>
    <message>
        <source>Double needle ISO UF treatment</source>
        <translation type="obsolete">双针干超治疗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="86"/>
        <source>Ready St</source>
        <translation>准备状态</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="89"/>
        <source>Treatment</source>
        <translation>治疗状态</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="92"/>
        <source>Disconnection</source>
        <translation>结束治疗状态</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="95"/>
        <source>Cleaning</source>
        <translation>清洁</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="98"/>
        <source>Debug</source>
        <translation>调试状态</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="101"/>
        <source>Drain</source>
        <translation>机器排水</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="105"/>
        <source>Water Stop</source>
        <translation>水路停止</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="156"/>
        <source>Ready</source>
        <translation>准备</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="159"/>
        <source>BM_test</source>
        <translation>正在自检</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="162"/>
        <source>BM test OK</source>
        <translation>自检完成</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="165"/>
        <source>Prime</source>
        <translation>预冲</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="168"/>
        <source>Dialyze ready</source>
        <translation>透析准备完成</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="171"/>
        <source>HD DoubleNeedle</source>
        <translation>HD双针</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="174"/>
        <source>ISO DoubleNeedle</source>
        <translation>ISO双针</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="177"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="646"/>
        <source>HDFonline</source>
        <translation>HDF在线</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="180"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="649"/>
        <source>HFonline</source>
        <translation>HF在线</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="183"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="186"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="652"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="655"/>
        <source>PE/PH</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="189"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="658"/>
        <source>HD SNSP</source>
        <translation>HD单针单泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="192"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="661"/>
        <source>HD SNDP</source>
        <translation>HD单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="195"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="664"/>
        <source>ISO SNSP</source>
        <translation>ISO单针单泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="198"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="667"/>
        <source>ISO SNDP</source>
        <translation>ISO单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="234"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="255"/>
        <source>ready</source>
        <translation>准备</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="258"/>
        <source>run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="637"/>
        <source>Self testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="640"/>
        <source>HD</source>
        <translation type="unfinished">透析</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="643"/>
        <source>ISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="673"/>
        <source>Priming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="677"/>
        <source>   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="687"/>
        <source>Stop</source>
        <translation type="unfinished">停止</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="693"/>
        <source>  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>stop</source>
        <translation type="obsolete">停止</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="690"/>
        <source>Bypass</source>
        <translation type="unfinished">旁路</translation>
    </message>
    <message>
        <source>run with save water</source>
        <translation type="obsolete">省液运行</translation>
    </message>
    <message>
        <source>Auto Prime</source>
        <translation type="obsolete">自动预冲</translation>
    </message>
</context>
<context>
    <name>WidgetSetup</name>
    <message>
        <source>Work mode</source>
        <translation type="obsolete">工作模式</translation>
    </message>
    <message>
        <source>Cure infor</source>
        <translation type="obsolete">治疗信息</translation>
    </message>
    <message>
        <source>Dialysis liquid</source>
        <translation type="obsolete">透析液</translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="obsolete">其它</translation>
    </message>
    <message>
        <source>Show.</source>
        <translation type="obsolete">显示</translation>
    </message>
    <message>
        <source>Heparin</source>
        <translation type="obsolete">肝素</translation>
    </message>
    <message>
        <source>Bolld Pressure</source>
        <translation type="obsolete">血压</translation>
    </message>
    <message>
        <source>Dialysate</source>
        <translation type="obsolete">透析液</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation type="obsolete">超虑</translation>
    </message>
    <message>
        <source>Hemo Pump</source>
        <translation type="obsolete">血泵</translation>
    </message>
    <message>
        <source>Cure Time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <source>Arterial Pressure</source>
        <translation type="obsolete">动脉压</translation>
    </message>
    <message>
        <source>Venous Pressure</source>
        <translation type="obsolete">静脉压</translation>
    </message>
    <message>
        <source>Transmem brane</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
    <message>
        <source>Dialysate Temp</source>
        <translation type="obsolete">透析液温度</translation>
    </message>
    <message>
        <source>Dialysate EC</source>
        <translation type="obsolete">透析液电导</translation>
    </message>
    <message>
        <source>Dialystate Speed</source>
        <translation type="obsolete">透析液流速</translation>
    </message>
    <message>
        <source>Bicarbonate</source>
        <translation type="obsolete">曲线(HCO3)</translation>
    </message>
    <message>
        <source>Na.</source>
        <translation type="obsolete">曲线
(Na,超虑曲线)</translation>
    </message>
</context>
<context>
    <name>WidgetSetupAdvanced</name>
    <message>
        <source>Show.</source>
        <translation type="obsolete">显示</translation>
    </message>
    <message>
        <source>Bicarbonate</source>
        <translation type="obsolete">HCO3-曲线</translation>
    </message>
    <message>
        <source>NaUF</source>
        <translation type="obsolete">Na+,超滤曲线</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="455"/>
        <source>Sequential</source>
        <oldsource>Sequential Dialysis</oldsource>
        <translation>序贯透析</translation>
    </message>
    <message>
        <source>Profile</source>
        <translation type="obsolete">曲线</translation>
    </message>
    <message>
        <source>Setup Bicarbonate</source>
        <translation type="obsolete">碳酸氢根</translation>
    </message>
    <message>
        <source>Setup NaUF</source>
        <translation type="obsolete">钠曲线</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="339"/>
        <source>Setup NaProfile</source>
        <translation>钠曲线</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="342"/>
        <source>Setup Sequential</source>
        <translation>序贯透析</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="345"/>
        <source>Setup Cond</source>
        <translation>电导度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="348"/>
        <source>Setup XmlConfig</source>
        <translation>配置文件</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="454"/>
        <source>Na Profile</source>
        <translation>钠曲线</translation>
    </message>
    <message>
        <source>XMLConfig</source>
        <translation type="obsolete">配置文件</translation>
    </message>
    <message>
        <source>Setup Unit</source>
        <translation type="obsolete">单位</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="354"/>
        <source>Setup Preflush</source>
        <translation>预冲</translation>
    </message>
    <message>
        <source>Setup autoWakeUp</source>
        <translation type="obsolete">自动开机</translation>
    </message>
    <message>
        <source>HCO3-</source>
        <translation type="obsolete">碳酸氢根</translation>
    </message>
    <message>
        <source>Cond</source>
        <oldsource>Conduction</oldsource>
        <translation type="obsolete">电导度</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="452"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Xml Config</source>
        <translation type="obsolete">配置文件</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="458"/>
        <source>Preflush</source>
        <translation>预冲</translation>
    </message>
    <message>
        <source>Timer</source>
        <translation type="obsolete">定时器</translation>
    </message>
    <message>
        <source>AutoWakeUp</source>
        <translation type="obsolete">自动开机</translation>
    </message>
    <message>
        <source>Setup Timer</source>
        <translation type="obsolete">定时器</translation>
    </message>
    <message>
        <source>Hemomanometer</source>
        <translation type="obsolete">血压计</translation>
    </message>
    <message>
        <source>Heart Pressure</source>
        <translation type="obsolete">血压心力</translation>
    </message>
    <message>
        <source>Oximeter</source>
        <translation type="obsolete">血氧</translation>
    </message>
    <message>
        <source>Blood Temp</source>
        <translation type="obsolete">血温</translation>
    </message>
    <message>
        <source>Unit</source>
        <translation type="obsolete">单位</translation>
    </message>
    <message>
        <source>Advanced Setup</source>
        <translation type="obsolete">高级设置</translation>
    </message>
    <message>
        <source>Na.</source>
        <translation type="obsolete">曲线
(Na,超滤曲线)</translation>
    </message>
</context>
<context>
    <name>WidgetSetupCure</name>
    <message>
        <source>Show.</source>
        <translation type="obsolete">显示</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="136"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="137"/>
        <source>Treat Time</source>
        <oldsource>Cure Time</oldsource>
        <translation>治疗时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="138"/>
        <source>UF</source>
        <translation>超滤</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="139"/>
        <source>Blood Pump</source>
        <oldsource>Hemo Pump</oldsource>
        <translation>血泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="140"/>
        <source>Heparin</source>
        <translation>肝素</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="141"/>
        <source>Pressure</source>
        <oldsource>Bolld Pressure</oldsource>
        <translation>压力</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="142"/>
        <source>Dialysate</source>
        <translation>透析液</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="143"/>
        <source>Substitution</source>
        <translation>置换泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="144"/>
        <source>ISO UF</source>
        <translation>单超</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="237"/>
        <source>Setup Treatment time</source>
        <translation>治疗时间</translation>
    </message>
    <message>
        <source>Setup Cure Time</source>
        <translation type="obsolete">治疗时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="240"/>
        <source>Setup UF</source>
        <translation>超滤</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="243"/>
        <source>Setup Bloodpump</source>
        <translation>血泵</translation>
    </message>
    <message>
        <source>Setup Hemopump</source>
        <translation type="obsolete">肝素泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="246"/>
        <source>Setup Dialysate</source>
        <translation>透析夜</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="249"/>
        <source>Setup Subspump</source>
        <translation>辅助泵</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="252"/>
        <source>Setup ISO UF</source>
        <translation>单超</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="255"/>
        <source>Setup Heparin</source>
        <translation>肝素</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="258"/>
        <source>Setup Pressure</source>
        <translation>压力</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation type="obsolete">参数设置</translation>
    </message>
    <message>
        <source>Bicarbonate</source>
        <translation type="obsolete">曲线(HCO3)</translation>
    </message>
    <message>
        <source>Na.</source>
        <translation type="obsolete">曲线
(Na,超虑曲线)</translation>
    </message>
</context>
<context>
    <name>WidgetSetupExt</name>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="242"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="243"/>
        <source>BPM</source>
        <translation>血压计</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="244"/>
        <source>SpO2</source>
        <translation>血氧浓度</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="245"/>
        <source>BTM</source>
        <translation>血温</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="248"/>
        <source>Kt/V2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="249"/>
        <source>BVM</source>
        <translation>血容</translation>
    </message>
    <message>
        <source>Oximeter</source>
        <translation type="obsolete">血氧</translation>
    </message>
    <message>
        <source>Blood Temp</source>
        <translation type="obsolete">血温</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="246"/>
        <source>Timer</source>
        <translation>定时器</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="247"/>
        <source>Kt/V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BloodVolume</source>
        <translation type="obsolete">血容</translation>
    </message>
</context>
<context>
    <name>WidgetSetupOther</name>
    <message>
        <source>Show.</source>
        <translation type="obsolete">显示</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="obsolete">时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="276"/>
        <source>Other</source>
        <translation>其它设置</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="277"/>
        <source>System Time</source>
        <translation>系统时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="278"/>
        <source>Network</source>
        <translation>网络</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="279"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="280"/>
        <source>System Info</source>
        <translation>系统信息</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="251"/>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="281"/>
        <source>Maintain</source>
        <translation>维护</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="243"/>
        <source>Setup System Time</source>
        <translation>系统时间</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="245"/>
        <source>Setup Network</source>
        <translation>网络</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="247"/>
        <source>Setup Lang</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="249"/>
        <source>Setup System Info</source>
        <translation>系统信息</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="253"/>
        <source>Status Graph</source>
        <translation>维护</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="255"/>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="283"/>
        <source>patientMessage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RFCard</source>
        <translation type="obsolete">病人IC卡</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="257"/>
        <source>Setup Unit</source>
        <translation>单位</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="259"/>
        <source>Setup Auto-wake-up</source>
        <translation>自动开机</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="286"/>
        <source>Auto-wake-up</source>
        <translation>自动开机</translation>
    </message>
    <message>
        <source>Setup autoWakeUp</source>
        <translation type="obsolete">自动开机</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="261"/>
        <source>Setup Password</source>
        <translation>密码设置</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="284"/>
        <source>Engineer</source>
        <translation>工程</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="285"/>
        <source>Unit</source>
        <translation>单位</translation>
    </message>
    <message>
        <source>AutoWakeUp</source>
        <translation type="obsolete">自动开机</translation>
    </message>
    <message>
        <source>System Maintain</source>
        <translation type="obsolete">系统维护</translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="282"/>
        <source>Status Map</source>
        <translation>状态图</translation>
    </message>
    <message>
        <source>RFID</source>
        <translation type="obsolete">病人IC卡</translation>
    </message>
    <message>
        <source>EngineeringMode</source>
        <translation type="obsolete">工程模式</translation>
    </message>
</context>
<context>
    <name>WidgetSwitch</name>
    <message>
        <source>PreShoot</source>
        <translation type="obsolete">预冲</translation>
    </message>
    <message>
        <source>Cure</source>
        <translation type="obsolete">治疗</translation>
    </message>
    <message>
        <source>Dialysis Pump</source>
        <translation type="obsolete">超滤泵</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="obsolete">是</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">否</translation>
    </message>
    <message>
        <source>Dry Dialyzer</source>
        <translation type="obsolete">排空</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="305"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="878"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1070"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1952"/>
        <source>Auto Prime</source>
        <translation>自动预冲</translation>
    </message>
    <message>
        <source>Prime</source>
        <translation type="obsolete">预冲</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="307"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="880"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1077"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1954"/>
        <source>Manual Prime</source>
        <translation>手动预冲</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="325"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1170"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1975"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="3626"/>
        <source>Treatment</source>
        <translation>治疗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="310"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="892"/>
        <source>UF Pump</source>
        <translation>超滤泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="338"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="891"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1050"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1097"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1208"/>
        <source>Connect P.t</source>
        <translation>引血</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="512"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="2002"/>
        <source>Ready</source>
        <translation>准备</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="513"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="2003"/>
        <source>Drain</source>
        <translation>排水</translation>
    </message>
    <message>
        <source>Get Blood</source>
        <translation type="obsolete">引血</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="893"/>
        <source>Heparin Pump</source>
        <translation>肝素泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="894"/>
        <source>Bypass</source>
        <translation>旁路</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="217"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1105"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1983"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="2001"/>
        <source>Return Blood</source>
        <translation>回血</translation>
    </message>
    <message>
        <source>Side Road</source>
        <translation type="obsolete">旁路</translation>
    </message>
</context>
<context>
    <name>WidgetTempo</name>
    <message>
        <source>flushing</source>
        <translation type="obsolete">冲洗</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation type="obsolete">已完成</translation>
    </message>
    <message>
        <source>please wait...</source>
        <translation type="obsolete">请等待...</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_tempo.cpp" line="125"/>
        <source>Please wait till 100%.</source>
        <translation>请等待...</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_tempo.cpp" line="134"/>
        <source>Rinse</source>
        <translation>冲洗</translation>
    </message>
</context>
<context>
    <name>WidgetTime</name>
    <message>
        <source>Time Left</source>
        <oldsource>Remain Time</oldsource>
        <translation type="obsolete">剩余时间</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_time.cpp" line="180"/>
        <source>Remaining time</source>
        <translation>剩余时间</translation>
    </message>
</context>
<context>
    <name>WindowBoot</name>
    <message>
        <source>Enter checking Page......</source>
        <translation type="obsolete">进入自检页面......</translation>
    </message>
    <message>
        <source>Pass</source>
        <translation type="obsolete">跳过</translation>
    </message>
    <message>
        <location filename="../../src/windows/window_boot.cpp" line="320"/>
        <source>Enter Self-test menu...</source>
        <translation>进入自检...</translation>
    </message>
    <message>
        <location filename="../../src/windows/window_boot.cpp" line="321"/>
        <source>Skip</source>
        <translation>跳过</translation>
    </message>
    <message>
        <location filename="../../src/windows/window_boot.cpp" line="322"/>
        <source>Debug mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WindowCheckSelf</name>
    <message>
        <source>Check self</source>
        <translation type="obsolete">自检</translation>
    </message>
    <message>
        <source>Hemopump Check</source>
        <translation type="obsolete">血泵检测</translation>
    </message>
    <message>
        <source>Supply Pump Check</source>
        <translation type="obsolete">补充液泵检测</translation>
    </message>
    <message>
        <source>Heparin Pump Check</source>
        <translation type="obsolete">肝素泵检测</translation>
    </message>
    <message>
        <source>Venous Pre Check</source>
        <translation type="obsolete">静脉压检测</translation>
    </message>
    <message>
        <source>Artery Pre Check</source>
        <translation type="obsolete">动脉压检测</translation>
    </message>
    <message>
        <source>Transmembrane Pre Check</source>
        <translation type="obsolete">跨膜压检测</translation>
    </message>
    <message>
        <source>Liquid Level Check</source>
        <translation type="obsolete">液位检测</translation>
    </message>
    <message>
        <source>Bubbles Check</source>
        <translation type="obsolete">气泡检测</translation>
    </message>
    <message>
        <source>Water Tmp Check</source>
        <translation type="obsolete">水路温度检测</translation>
    </message>
    <message>
        <source>Water Conductivity Check</source>
        <translation type="obsolete">水路电导检测</translation>
    </message>
    <message>
        <source>Self-test</source>
        <translation type="obsolete">自检</translation>
    </message>
    <message>
        <source>Blood Pump</source>
        <translation type="obsolete">血泵</translation>
    </message>
    <message>
        <source>Spare Pump</source>
        <translation type="obsolete">补充液泵</translation>
    </message>
    <message>
        <source>Heparin Pump</source>
        <translation type="obsolete">肝素泵</translation>
    </message>
    <message>
        <source>V.P.</source>
        <translation type="obsolete">静脉压</translation>
    </message>
    <message>
        <source>A.P.</source>
        <translation type="obsolete">动脉压</translation>
    </message>
    <message>
        <source>TMP</source>
        <translation type="obsolete">跨膜压</translation>
    </message>
    <message>
        <source>Liquid Level</source>
        <translation type="obsolete">液位</translation>
    </message>
    <message>
        <source>Air Bubbls</source>
        <translation type="obsolete">气泡</translation>
    </message>
    <message>
        <source>Temp. of water</source>
        <translation type="obsolete">水温</translation>
    </message>
    <message>
        <source>Cond. of water</source>
        <translation type="obsolete">电导</translation>
    </message>
</context>
<context>
    <name>WindowMain</name>
    <message>
        <source>HemoDialysis</source>
        <translation type="obsolete">血透机</translation>
    </message>
</context>
<context>
    <name>WindowStatusMap</name>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="57"/>
        <source>Graph</source>
        <translation>水路图</translation>
    </message>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="58"/>
        <source>Table</source>
        <translation>表格</translation>
    </message>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="59"/>
        <source>User</source>
        <translation>用户</translation>
    </message>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="60"/>
        <source>Return</source>
        <translation>返回</translation>
    </message>
</context>
<context>
    <name>Window_ChangeFilter</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1325"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1326"/>
        <source>Reset Filter</source>
        <translation>重设</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1328"/>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1354"/>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1376"/>
        <source>Dry Filter</source>
        <translation>排空滤器</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1330"/>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1371"/>
        <source>Stop Dry</source>
        <translation>停止排空</translation>
    </message>
</context>
<context>
    <name>Window_Confirm</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="626"/>
        <source>Press&apos;Yes&apos; to auto scale AP!</source>
        <translation>点击&apos;是&apos;,AP自动卡标!</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="633"/>
        <source>Press&apos;Yes&apos; to auto scale VP!</source>
        <translation>点击&apos;是&apos;,VP自动卡标!</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="640"/>
        <source>Press&apos;Yes&apos; to auto scale TMP!</source>
        <translation>点击&apos;是&apos;,TMP自动卡标!</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="650"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="651"/>
        <source>Confirm</source>
        <translation>确认</translation>
    </message>
</context>
<context>
    <name>Window_Message</name>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="297"/>
        <source>Must confirm</source>
        <translation>必须确认</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="326"/>
        <source>Operation guide:</source>
        <translation>操作方法:</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="478"/>
        <source>close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="479"/>
        <source>last</source>
        <translation>上页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="480"/>
        <source>next</source>
        <translation>下页</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="481"/>
        <source>confirm</source>
        <translation>确认</translation>
    </message>
</context>
<context>
    <name>Window_Note</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="158"/>
        <source>Do you want to start the &quot;</source>
        <translation>您是否想开始</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="161"/>
        <source>HD SNSP</source>
        <translation type="unfinished">HD单针单泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="164"/>
        <source>HD double</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="167"/>
        <source>HD SNDP</source>
        <translation type="unfinished">HD单针双泵</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="171"/>
        <source>HDF pre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="174"/>
        <source>HDF post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="178"/>
        <source>HF pre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="181"/>
        <source>HF post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="185"/>
        <source>ISOUF SNSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="188"/>
        <source>ISOUF DNSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="227"/>
        <source>Cure Finished ? Press&apos;No&apos; to continut ,Press&apos;Yes&apos; to return blood .</source>
        <translation>是否治疗结束？是-进入回血，否-继续治疗</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="191"/>
        <source>ISOUF SNDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="195"/>
        <source>PE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="198"/>
        <source>HD</source>
        <translation type="unfinished">透析</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="201"/>
        <source>&quot; Cure Mode?</source>
        <translation>治疗模式？</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="208"/>
        <source>Return to ready status,keep or reset parameters? Yes-keep,No-reset</source>
        <translation>返回准备状态，保留或重设参数？是-保留,否-重设</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="215"/>
        <source>Do you want to change the work mode ?</source>
        <translation>您是否想改变治疗模式？</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="221"/>
        <source>Do you want to leave cure ?</source>
        <translation>您是否想结束治疗？</translation>
    </message>
    <message>
        <source>Cure Finished ! Press&apos;Yes&apos; to continut ,Press&apos;No&apos; to return blood .</source>
        <translation type="obsolete">治疗结束!继续治疗请按&quot;是&quot;,进入回血请按&quot;否&quot;。</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="236"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="237"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="238"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="239"/>
        <source>Confirm</source>
        <translation>请确认</translation>
    </message>
</context>
<context>
    <name>Window_Passwd</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="794"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="795"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="796"/>
        <source>Please Input Password:</source>
        <translation>请输入密码</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="846"/>
        <source>Password Error !</source>
        <translation>密码错误</translation>
    </message>
</context>
<context>
    <name>Window_YES</name>
    <message>
        <source>Yes</source>
        <translation type="obsolete">是</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="497"/>
        <source>Confirmation</source>
        <translation>确认</translation>
    </message>
</context>
<context>
    <name>Window_YESNO</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="372"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="373"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
</context>
<context>
    <name>wlan</name>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="76"/>
        <source>wlan</source>
        <translation>无线网络</translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="77"/>
        <source>Connect</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="78"/>
        <source>Disconnect</source>
        <translation>断开</translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="79"/>
        <source>Scan</source>
        <translation>扫描</translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="82"/>
        <source>flags</source>
        <translation>标志</translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="83"/>
        <source>signal</source>
        <translation>信号</translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="84"/>
        <source>frequency</source>
        <translation>频率</translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="85"/>
        <source>BSSID</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="86"/>
        <source>SSID</source>
        <translation></translation>
    </message>
</context>
</TS>
