<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en">
<context>
    <name>CWlan</name>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="80"/>
        <source>remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message utf8="true">
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="14"/>
        <source>工程模式</source>
        <translation>Engineer Modle</translation>
    </message>
    <message utf8="true">
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="26"/>
        <source>关闭窗口</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>状态和信息</source>
        <translation type="obsolete">Status and info</translation>
    </message>
    <message>
        <source>软件版本</source>
        <translation type="obsolete">Versions</translation>
    </message>
    <message>
        <source>编译时间</source>
        <translation type="obsolete">Build in</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="110"/>
        <source>Update System Software &amp; Firmware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="123"/>
        <source>CheckVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="136"/>
        <source>BloodVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="149"/>
        <source>Blood2Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="162"/>
        <source>MornitorVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="175"/>
        <source>HeparinVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="188"/>
        <source>MasterVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="201"/>
        <source>PowerVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>参数设置</source>
        <translation type="obsolete">Params set</translation>
    </message>
    <message>
        <source>曲线设置</source>
        <translation type="obsolete">Curve Set</translation>
    </message>
    <message>
        <source>配方设置</source>
        <translation type="obsolete">Formulation</translation>
    </message>
    <message>
        <source>系统更新</source>
        <translation type="obsolete">System Update</translation>
    </message>
    <message>
        <source>出厂设置</source>
        <translation type="obsolete">Factory Set</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="46"/>
        <source>Status and info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="58"/>
        <source>Versions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="71"/>
        <source>Build In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="214"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="227"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="240"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="253"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="266"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="279"/>
        <source>null</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="311"/>
        <source>Params set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="316"/>
        <source>Curve Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="321"/>
        <source>Formula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="333"/>
        <source>BCond.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="346"/>
        <source>MixCond.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="359"/>
        <source>scal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="404"/>
        <source>Curent      Na:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="417"/>
        <source>Curent HCO3:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="430"/>
        <source>Factory Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="442"/>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="455"/>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="468"/>
        <source>Volume :</source>
        <translation>Volume:</translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="520"/>
        <source>Display Auto Off Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="533"/>
        <source>Display Remaining Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="546"/>
        <source>Display Last Programs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="559"/>
        <source>Display Filter Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="572"/>
        <source>Chemical Disinfect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="584"/>
        <source>Chymistry Peracetic </source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="600"/>
        <source>Chymistry Citric</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="613"/>
        <source>Chymistry Reserve3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="627"/>
        <source>Central Disinfect Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="639"/>
        <source>Central Hot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="655"/>
        <source>Central Chemical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="669"/>
        <source>Prime Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="684"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="697"/>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="710"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="724"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="737"/>
        <source>Edit Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="752"/>
        <source>set password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="766"/>
        <source>Until Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="788"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="867"/>
        <source>All Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="811"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="880"/>
        <source>Used Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="824"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="903"/>
        <source>Remain Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="916"/>
        <source>Filter1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="929"/>
        <source>Filter2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="943"/>
        <source>Heparin Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="958"/>
        <source>YES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="971"/>
        <source>NO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="985"/>
        <source>Connect P.t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1000"/>
        <source>Online  Getblood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1013"/>
        <source>Getblood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1027"/>
        <source>Cure mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1042"/>
        <source>HD_DDB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1055"/>
        <source>HD_SDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1068"/>
        <source>HD_SSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1081"/>
        <source>HDF_PRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1094"/>
        <source>HDF_POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1107"/>
        <source>HF_PRE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1120"/>
        <source>HF_POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1133"/>
        <source>ISO_DDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1146"/>
        <source>ISO_SDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1159"/>
        <source>ISO_SSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1172"/>
        <source>PE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1186"/>
        <source>Return blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1201"/>
        <source>Online Returnblood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1214"/>
        <source>Returnblood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1228"/>
        <source>Fluid mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1243"/>
        <source>A_and_B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1256"/>
        <source>A_and_BPower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1269"/>
        <source>Acetate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1282"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1296"/>
        <source>Restore Param</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1309"/>
        <source>Profile mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1324"/>
        <source>Na Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1337"/>
        <source>UF Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1350"/>
        <source>Dia Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1363"/>
        <source>Cond Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1376"/>
        <source>Temp Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1389"/>
        <source>Hco3 Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1402"/>
        <source>Hep Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1412"/>
        <source>EEPROM</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1424"/>
        <source>ReadOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1436"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1488"/>
        <source>Address(dec)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1449"/>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1501"/>
        <source>data(dec)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1463"/>
        <source>Input Address(dec)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.ui" line="1476"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="66"/>
        <source>Curent Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="67"/>
        <source>Curent Hco3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="68"/>
        <source>Filter1 all Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="69"/>
        <source>Filter1 used Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="70"/>
        <source>Filter1 remain Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="71"/>
        <source>Filter2 all Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="72"/>
        <source>Filter2 used Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="73"/>
        <source>Filter2 remain Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="395"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="658"/>
        <source>/Config/Engineer_Factoryset/CureMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="442"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="665"/>
        <source>/Config/Engineer_Factoryset/ProfileMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="482"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="756"/>
        <source>/Config/Engineer_Factoryset/fluidMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="508"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="766"/>
        <source>/Config/Engineer_Factoryset/GetBloodMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="518"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="776"/>
        <source>/Config/Engineer_Factoryset/ReturnBloodMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="528"/>
        <source>/Config/Engineer_Factoryset/HeparinMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="568"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="782"/>
        <source>/Config/Engineer_Factoryset/ChemicalDisinfect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="833"/>
        <source>select the update Packag</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="389"/>
        <location filename="../../src/engineering_mode/engineering_mode.cpp" line="628"/>
        <source>/Config/Engineer_Factoryset/PrimeMode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../../src/httpserver/httpserver.cpp" line="168"/>
        <source>&lt;!DOCTYPE html&gt;                        &lt;html&gt;                       &lt;head&gt;                       &lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charset=utf-8&quot; /&gt;                      &lt;meta http-equiv=&quot;refresh&quot; content=&quot;10&quot;&gt;                      &lt;title&gt;JH-5058 &lt;/title&gt;                      &lt;/head&gt;                       &lt;body&gt; &lt;table width=&quot;100%&quot; border=&quot;1&quot;&gt;&lt;tr&gt; </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogRunModel</name>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="351"/>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="455"/>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="457"/>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="458"/>
        <source>Formula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="425"/>
        <source>Change: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="426"/>
        <source> from </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="428"/>
        <source> to </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NumberInputPanel</name>
    <message>
        <location filename="../../src/virtual_keyboard/number_input_panel.cpp" line="53"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/virtual_keyboard/number_input_panel.cpp" line="263"/>
        <source>max  600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/virtual_keyboard/number_input_panel.cpp" line="276"/>
        <source>min  300</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PASSWORD</name>
    <message>
        <location filename="../../src/wlan/password.cpp" line="40"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/password.cpp" line="41"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/password.cpp" line="42"/>
        <source>password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PatientMessage</name>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="744"/>
        <source>Na+ :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="745"/>
        <source>Hco3 :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="729"/>
        <source>ID :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="735"/>
        <location filename="../../src/RFCard/RFCard.cpp" line="877"/>
        <source>Age :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="737"/>
        <location filename="../../src/RFCard/RFCard.cpp" line="879"/>
        <source>Depart :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="738"/>
        <location filename="../../src/RFCard/RFCard.cpp" line="880"/>
        <source>Dry weight(KG):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="739"/>
        <location filename="../../src/RFCard/RFCard.cpp" line="881"/>
        <source>Diagnose :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="742"/>
        <source>Time(H):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="733"/>
        <location filename="../../src/RFCard/RFCard.cpp" line="875"/>
        <source>Name &amp; Surname :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="840"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="734"/>
        <location filename="../../src/RFCard/RFCard.cpp" line="876"/>
        <source>Gender :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="743"/>
        <source>Temp :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="746"/>
        <source>UF goal :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RFCard/RFCard.cpp" line="747"/>
        <source>Blood Flow :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QLabel</name>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="18"/>
        <source>Sum UF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="19"/>
        <source>UF mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="21"/>
        <source>Selecting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="22"/>
        <source>Predefined curve can not modify!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="24"/>
        <source>Sequential UF Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="26"/>
        <source>The seleceed
period value
[%]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="27"/>
        <source>Set all
period
value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="28"/>
        <source>Current
curve num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="31"/>
        <source>Browse
curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="20"/>
        <location filename="../../src/common/common_tr_string.h" line="32"/>
        <source>Treatment time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="23"/>
        <source>Conductivity(Na) Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="33"/>
        <source>Each period</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="34"/>
        <source>Not selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="35"/>
        <source>More than the UF seted value!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="36"/>
        <source>Less than the UF seted value!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="37"/>
        <source>Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="38"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="39"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="41"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="42"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="43"/>
        <source>Define</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="44"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="45"/>
        <source>This curve data run success!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="47"/>
        <source>This curve data save success!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="49"/>
        <source>An error occurred,save fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="50"/>
        <source>An error occurred,run fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="51"/>
        <source>An error occurred on PNG file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="52"/>
        <source>Prompt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="53"/>
        <source>This curve data save and run!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="54"/>
        <source>Please select a columnar!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="55"/>
        <source>Please select a curve!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="56"/>
        <source>Are you sure to apply?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="58"/>
        <source>Are you sure to save?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="62"/>
        <source>mintues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="63"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="64"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="74"/>
        <location filename="../../src/common/common_tr_string.h" line="326"/>
        <source>Please Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="40"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="25"/>
        <source>The seleceed
period value
[mmol/L]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="29"/>
        <source>Na+ Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="30"/>
        <location filename="../../src/common/common_tr_string.h" line="185"/>
        <source>UF Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="48"/>
        <source>This curve already reset !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="59"/>
        <source>Treatment time can not less</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="60"/>
        <source>This profile is runing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="61"/>
        <source>This profile is undefined!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="66"/>
        <source>Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="67"/>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="68"/>
        <source>Set value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="69"/>
        <source>Foreward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="70"/>
        <source>Rollback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="71"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="75"/>
        <source>Warning:Do not skip self test to do treatment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="76"/>
        <source>Prompt:Whether access debug module?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="77"/>
        <source>Super clean filter useable times less 3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="78"/>
        <source>Super clean filter useable times is 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="80"/>
        <source>Do you want to Stop Cleanning ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="81"/>
        <source>Do you want to ShotDown ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="82"/>
        <source>Please selct disinfect type!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="83"/>
        <source>NO water!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="86"/>
        <source>Selfcheck timed out failure, please restart!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="87"/>
        <source>Selfcheck error, please restart!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="88"/>
        <source>The blood Selfcheck fails!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="89"/>
        <source>The water Selfcheck fails!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="92"/>
        <source>Can be treated!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="93"/>
        <source>Didn&apos;t open the heparin pump, please open!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="95"/>
        <source>Whether has ended return blood? &apos;Yes&apos;-start drain,&apos;No&apos;-return!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="96"/>
        <source>Whether to continue drain? &apos;Yes&apos;-continue,&apos;No&apos;-end!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="98"/>
        <source>Are you sure preflush finish?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="99"/>
        <source>Treatment finish,go to blood return!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="101"/>
        <source>online prime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="102"/>
        <source>online P.t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="103"/>
        <source>online RB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="106"/>
        <source>Heparin is running, please first suspended!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="109"/>
        <source>Initialize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="110"/>
        <source>Preparation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="111"/>
        <source>Treatment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="112"/>
        <source>Disconnection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="113"/>
        <source>Cleaning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="114"/>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="115"/>
        <source>Drain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="117"/>
        <source>Free state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="118"/>
        <source>Self checking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="119"/>
        <source>Self check ok have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="120"/>
        <source>Self check ok no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="121"/>
        <source>Preflush runing have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="122"/>
        <source>Manual preflush have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="123"/>
        <source>Auto preflush have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="124"/>
        <source>Online preflush have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="126"/>
        <source>Preflush runing no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="127"/>
        <source>Manual preflush no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="128"/>
        <source>Auto preflush no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="129"/>
        <source>Online preflush no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="131"/>
        <source>Preflush stop have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="132"/>
        <source>Preflush stop no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="133"/>
        <source>Preflush ok have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="134"/>
        <source>Preflush ok no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="135"/>
        <source>have blood and fluid can treatment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="136"/>
        <source>have blood no fluid can treatment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="144"/>
        <source>Clean runing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="145"/>
        <source>Clean stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="146"/>
        <source>Clean finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="150"/>
        <source>Bloodreturn runing no blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="151"/>
        <source>Online Bloodreturn no blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="152"/>
        <source>Bloodreturn stop have blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="153"/>
        <source>Bloodreturn stop no blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="154"/>
        <source>Drain runing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="155"/>
        <source>Drain stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="157"/>
        <source>Water to prepare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="158"/>
        <source>Dry barrels preflush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="159"/>
        <source>DM test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="160"/>
        <source>DM test ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="161"/>
        <source>Provincial fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="162"/>
        <source>Water suspension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="163"/>
        <source>Provincial fluid and bypass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="164"/>
        <source>Stop fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="165"/>
        <source>Bypass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="167"/>
        <source>Disinfection preparation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="168"/>
        <source>Disinfection preflush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="169"/>
        <source>SUCK flush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="170"/>
        <source>Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="171"/>
        <source>Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="172"/>
        <source>After rinse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="173"/>
        <source>Cold rinse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="174"/>
        <source>Hot rinse 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="175"/>
        <source>Hot rinse 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="176"/>
        <source>Hot rinse 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="177"/>
        <source>Emptying</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="178"/>
        <source>Pipe rinse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="179"/>
        <source>The CCD suck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="180"/>
        <source>The CCD rinse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="181"/>
        <source>The CHD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="183"/>
        <source>NA UF Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="184"/>
        <source>NA Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="187"/>
        <source>Cool Rinse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="188"/>
        <source>Hot Rinse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="189"/>
        <source>Chemical Citricacid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="190"/>
        <source>Chemical Preacetic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="191"/>
        <source>Chemical-3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="192"/>
        <source>Hot Chemical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="193"/>
        <source>Hot Clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="195"/>
        <source>HD DoubleNeedle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="196"/>
        <source>ISO DoubleNeedle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="197"/>
        <source>HDFonline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="198"/>
        <source>HFonline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="199"/>
        <source>PE/PH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="200"/>
        <source>HD SNSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="201"/>
        <source>HD SNDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="202"/>
        <source>ISO SNSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="203"/>
        <source>ISO SNDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="205"/>
        <source>Pre Dilute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="206"/>
        <source>Post Dilute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="207"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="215"/>
        <source>You can set a maximum of 6 time period curves !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="216"/>
        <source>Addition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="217"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="218"/>
        <source>Start Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="219"/>
        <source>End Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="221"/>
        <source>IC card reading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="222"/>
        <source>IC card writing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="223"/>
        <source>male</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="224"/>
        <source>female</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="225"/>
        <source>renal medicine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="226"/>
        <source>endocrine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="227"/>
        <source>renal failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="228"/>
        <source>uremia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="230"/>
        <source>Pulse AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="231"/>
        <source>SYS AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="232"/>
        <source>DIA AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="233"/>
        <source>AP AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="234"/>
        <source>VP AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="235"/>
        <source>TMP AVG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="237"/>
        <source>AP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="238"/>
        <source>VP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="239"/>
        <source>TMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="248"/>
        <source>SUB Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="249"/>
        <source>Heparin Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="251"/>
        <source>Treatment mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="252"/>
        <source>Profile Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="253"/>
        <source>Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="254"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="255"/>
        <source>Choose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="256"/>
        <source>Data Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="258"/>
        <source>patientMessage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="261"/>
        <source>Cure Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="262"/>
        <source>Pre Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="263"/>
        <source>Nxt Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="271"/>
        <source>Press profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="272"/>
        <source>Press data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="274"/>
        <source>BloodPress profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="275"/>
        <source>BloodPress data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="280"/>
        <source>This id number for currently treatment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="282"/>
        <source>times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="283"/>
        <source>date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="243"/>
        <location filename="../../src/common/common_tr_string.h" line="284"/>
        <source>Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="46"/>
        <source>This profile already cancel!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="57"/>
        <source>Are you sure to cancel?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="242"/>
        <source>Time(H)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="244"/>
        <source>Na+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="245"/>
        <source>HCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="246"/>
        <source>UF goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="247"/>
        <source>Blood Flow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="250"/>
        <source>Heparin rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="260"/>
        <source>Cure Times select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="266"/>
        <source>Cond Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="269"/>
        <source>Temp Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="277"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="278"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="285"/>
        <source>Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="286"/>
        <source>UFFlow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="287"/>
        <source>BPFlow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="288"/>
        <source>Pulse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="289"/>
        <source>SYS/DIA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="290"/>
        <source>First Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="291"/>
        <source>Pre Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="292"/>
        <source>Nxt Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="293"/>
        <source>Last Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="295"/>
        <source>SYS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="296"/>
        <source>DIA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="298"/>
        <source>Max Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="299"/>
        <source>Min Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="300"/>
        <source>Avg Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="302"/>
        <source>Data Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="304"/>
        <source>standby mode 01</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="305"/>
        <source>standby mode 02</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="306"/>
        <source>No standby mode runing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="308"/>
        <source>Treatment model has not changed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="311"/>
        <source>UF volume can not exceed the remaining!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="312"/>
        <source>UF volume can not less than finish volume!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="313"/>
        <source>The time can not exceed the remaining time!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="314"/>
        <source>The time can not less than residue time!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="315"/>
        <source>The parameters afresh,and take effect!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="316"/>
        <source>Whether to start ISO?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="318"/>
        <source>Whether to start this model?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="319"/>
        <source>The subspump goal reach,stop!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="322"/>
        <source>ISO treatment ends, have switch to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="323"/>
        <source>Can not switch to PE in treatment runing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="327"/>
        <source>Warning:Do You want reset all Filter data ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="328"/>
        <source> Reset  Filter data  or dry filter </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="329"/>
        <source>Change Filter1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="330"/>
        <source>Change Filter2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="333"/>
        <source>The status of the mastercontrol is abnormal,please try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="338"/>
        <source>Upper Arterial pressure alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="339"/>
        <source>Upper Arterial pressure alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="341"/>
        <source>Upper venous pressure alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="342"/>
        <source>Upper venous pressure alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="344"/>
        <source>Upper TMP alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="345"/>
        <source>Upper TMP alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="347"/>
        <source>Upper temperature alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="348"/>
        <source>Upper temperature alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="350"/>
        <source>Lower Arterial pressure alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="351"/>
        <source>Lower Arterial pressure alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="353"/>
        <source>Lower venous pressure alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="354"/>
        <source>Lower venous pressure alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="356"/>
        <source>Lower TMP alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="357"/>
        <source>Lower TMP alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="359"/>
        <source>Lower temperature alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="360"/>
        <source>Lower temperature alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="362"/>
        <source>Blood level alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="363"/>
        <source>Blood level alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="365"/>
        <source>Arteries Bubble alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="366"/>
        <source>Arteries Bubble alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="368"/>
        <source>No blood alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="369"/>
        <source>No blood alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="371"/>
        <source>Vein Bubble alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="372"/>
        <source>Vein Bubble alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="375"/>
        <source>No1 blood pump out of control !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="377"/>
        <source>No2 blood pump out of control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="378"/>
        <source>No2 blood pump out of control !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="380"/>
        <source>Please close blood pump door</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="381"/>
        <source>Please close blood pump door!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="383"/>
        <source>Please close spare pump door</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="384"/>
        <source>Please close spare pump door!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="386"/>
        <source>Blood Leak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="387"/>
        <source>Blood Leak !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="389"/>
        <source>Heparin empty Or  block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="390"/>
        <source>Heparin empty Or  block !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="392"/>
        <source>Blood pressure monitor alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="393"/>
        <source>Blood pressure monitor alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="395"/>
        <location filename="../../src/common/common_tr_string.h" line="398"/>
        <source>The pressure before the dialyzer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="396"/>
        <source>The pressure before the dialyzer upper limit !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="399"/>
        <source>The pressure before the dialyzer lower limit !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="403"/>
        <location filename="../../src/common/common_tr_string.h" line="406"/>
        <source>The water outlet Conductivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="404"/>
        <source>The water outlet of the upper limit of Conductivity !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="407"/>
        <source>The water outlet of the lower limit of the Conductivity !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="409"/>
        <source>Alarming of water outlet total Conductivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="410"/>
        <source>Alarming of water outlet total Conductivity !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="412"/>
        <location filename="../../src/common/common_tr_string.h" line="415"/>
        <source>Alarming of the total Conductivity of mixed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="413"/>
        <source>The upper limit of the total Conductivity of mixed !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="416"/>
        <source>The lower limit of the total Conductivity of mixed !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="418"/>
        <source>Hybrid total Conductivity alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="419"/>
        <source>Hybrid total Conductivity range alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="421"/>
        <source>Dialysis fluid temperature is higher than the limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="422"/>
        <source>Dialysis fluid temperature is higher than the limit !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="424"/>
        <source>Dialysis fluid temperature is below the limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="425"/>
        <source>Dialysis fluid temperature is below the limit !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="427"/>
        <source>The upper temperature limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="428"/>
        <source>The upper temperature limit !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="430"/>
        <source>The lower limit of temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="431"/>
        <source>The lower limit of temperature !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="433"/>
        <source>The range of temperature alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="434"/>
        <source>The range of temperature alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="436"/>
        <source>A liquid conductivity error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="437"/>
        <source>A liquid conductivity error !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="439"/>
        <source>B liquid conductivity error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="440"/>
        <source>B liquid conductivity error !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="442"/>
        <source>No A dialysate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="443"/>
        <source>No A dialysate !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="445"/>
        <source>No B dialysate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="446"/>
        <source>No B dialysate !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="448"/>
        <source>The alarm of no water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="449"/>
        <source>The alarm of no water !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="451"/>
        <source>Disinfection liquid conductivity toplimit error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="452"/>
        <source>Disinfection liquid conductivity toplimit error !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="454"/>
        <source>Disinfection liquid conductivity lower limit error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="455"/>
        <source>Disinfection liquid conductivity lower limit error !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="457"/>
        <source>Fluid degassing error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="458"/>
        <source>Fluid degassing error !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="460"/>
        <source>Balance cavity film breaking alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="461"/>
        <source>Balance cavity film breaking alarm !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="465"/>
        <source>Connect tube A to pot A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="466"/>
        <source>Connect tube A to pot A !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="468"/>
        <source>Connect tube A to machine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="469"/>
        <source>Connect tube A to machine !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="471"/>
        <source>Connect tube B to pot B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="472"/>
        <source>Connect tube B to pot B !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="474"/>
        <source>Connect tube B to machine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="475"/>
        <source>Connect tube B to machine !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="477"/>
        <source>Connect supply tube to dialyzer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="478"/>
        <source>Connect supply tube to dialyzer !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="480"/>
        <source>Connect supply tube to machine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="481"/>
        <source>Connect supply tube to machine !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="483"/>
        <source>Connect return tubes of dialyzer to the  port of dialyzer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="484"/>
        <source>Connect return tubes of dialyzer to the  port of dialyzer !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="486"/>
        <source>Connect return tubes of dialyzer to the  port of machine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="487"/>
        <source>Connect return tubes of dialyzer to the  port of machine!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="489"/>
        <source>Dry frame open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="490"/>
        <source>Dry frame open !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="492"/>
        <source>Dry frame close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="493"/>
        <source>Dry frame close !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="496"/>
        <source>Set up fluid interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="497"/>
        <source>Set up corresponding line displacement fluid interface!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="500"/>
        <source>Remove fluid interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="501"/>
        <source>Remove the displacement fluid interface line!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="504"/>
        <source>Set up fluid flush interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="505"/>
        <source>Set up corresponding line displacement fluid flush interface!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="508"/>
        <source>Remove fluid flush interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="509"/>
        <source>Remove the replacement wash liquid interface line!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="514"/>
        <source>CLPV error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="530"/>
        <location filename="../../src/common/common_tr_string.h" line="533"/>
        <location filename="../../src/common/common_tr_string.h" line="536"/>
        <source>The zero offset is too large!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="593"/>
        <source>some error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="594"/>
        <source>Please check alarm code!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="618"/>
        <source>N3 communication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="621"/>
        <source>N5 communication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="624"/>
        <source>N9 communication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="627"/>
        <source>N10 communication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="630"/>
        <source>N15 communication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="633"/>
        <source>N7 communication failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="636"/>
        <source>The patient calls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="637"/>
        <source>Patients with emergency call !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="639"/>
        <source>water working abnormal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="640"/>
        <source>Master plate water problem!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="642"/>
        <source>Single time alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="643"/>
        <source>Single timeout !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="645"/>
        <source>Cycle time alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="646"/>
        <source>Cycle timeout !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="649"/>
        <source>Manual preflush state error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="650"/>
        <source>Master plate manual preflush state error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="652"/>
        <source>Auto preflush state error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="653"/>
        <source>Master plate auto preflush state error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="655"/>
        <source>Online preflush state error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="656"/>
        <source>Master plate online preflush state error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="658"/>
        <source>Connect P.t state error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="659"/>
        <source>Master plate Connect P.t state error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="661"/>
        <source>Online connect P.t state error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="662"/>
        <source>Master plate Online connect P.t state error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="664"/>
        <source>Return blood state error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="665"/>
        <source>Master plate Return blood state error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="667"/>
        <source>Online return blood state error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="668"/>
        <source>Master plate Online return blood state error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="704"/>
        <source>XML file error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="705"/>
        <source>xml file read error,the param is:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="714"/>
        <source>BPM runing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="717"/>
        <source>Residue time less than heparinPrestop time,heparin will not run!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="718"/>
        <source>Cure time has changed,profile cancel!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="719"/>
        <source>Workmode has changed,profile cancel!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="720"/>
        <source>UF Aimvol has changed,uf profile cancel!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="721"/>
        <source>The remaining time too little, uf volume can not reach,uf profile cancel!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="724"/>
        <source>Cond Record Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="725"/>
        <source>Temp Record Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="726"/>
        <source>Cond Record Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="727"/>
        <source>Temp Record Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="730"/>
        <source>Has select profile cure,profile num:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="731"/>
        <source>Profile cure runing,profile num:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="732"/>
        <source>Not select profile cure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="736"/>
        <source>Na cure predefined modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="737"/>
        <source>UF cure predefined modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="738"/>
        <source>Na precure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="739"/>
        <source>Uf precure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="740"/>
        <source>Save success!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="741"/>
        <source>Whether to Restore xml file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="747"/>
        <source>UF_Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="748"/>
        <source>UF_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="749"/>
        <source>Earlier_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="750"/>
        <source>AutoChange_Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="752"/>
        <source>Dia_Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="753"/>
        <source>Dia_Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="754"/>
        <source>Dia_Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="755"/>
        <source>Dia_OnlineRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="757"/>
        <source>BP_Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="758"/>
        <source>BP_RateCheckSelf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="759"/>
        <source>BP_RateThreatMent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="760"/>
        <source>BP_RateReturnBlood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="761"/>
        <source>BP_RatePreflush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="762"/>
        <source>BP_RateGetBlood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="764"/>
        <source>First_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="766"/>
        <source>Pre_StopTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="767"/>
        <source>Add_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="769"/>
        <source>SubPump_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="770"/>
        <source>SubPump_Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="771"/>
        <source>SubPump_RapidRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="773"/>
        <source>Hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="774"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="776"/>
        <source>BpRate_First_FiveMin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="777"/>
        <source>BpRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="778"/>
        <source>Dialyser_Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="779"/>
        <location filename="../../src/common/common_tr_string.h" line="795"/>
        <source>Preflush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="780"/>
        <source>PF_UF_Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="781"/>
        <source>PF_UF_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="782"/>
        <source>PF_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="783"/>
        <source>BpRate_Conect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="784"/>
        <source>BpRate_phase1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="785"/>
        <source>BpRate_phase2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="786"/>
        <source>BpRate_phase3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="787"/>
        <source>TMPUp_PF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="789"/>
        <location filename="../../src/common/common_tr_string.h" line="796"/>
        <source>Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="792"/>
        <source>TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="793"/>
        <source>RealTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="797"/>
        <source>Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="798"/>
        <source>BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="799"/>
        <source>Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="800"/>
        <source>Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="801"/>
        <source>Target_Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="802"/>
        <source>Real_Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="806"/>
        <source>Blood Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="807"/>
        <source>Sub Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="808"/>
        <source>Function Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="809"/>
        <source>Heparin Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="810"/>
        <source>PRESSURE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="811"/>
        <source>Air bubblies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="812"/>
        <source>Liquid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="813"/>
        <source>BLood monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="814"/>
        <source>Choke clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="815"/>
        <source>Sound light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="818"/>
        <source>Common</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="819"/>
        <source>No water time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="820"/>
        <source>Set flow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="822"/>
        <source>Not revised value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="823"/>
        <source>Send value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="824"/>
        <source>Show value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="826"/>
        <source>B Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="827"/>
        <source>Mix Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="828"/>
        <source>Outlet Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="829"/>
        <source>After Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="830"/>
        <source>Heater Temp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="831"/>
        <source>B Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="832"/>
        <source>Mix Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="833"/>
        <source>Outlet Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="834"/>
        <source>After Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="835"/>
        <source>Disinfect Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="836"/>
        <source>BloodLeak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="837"/>
        <source>UF Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="838"/>
        <source>Dialystate Flow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="839"/>
        <source>Circulate Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="840"/>
        <source>Before Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="841"/>
        <source>After Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="842"/>
        <source>A Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="843"/>
        <source>B Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="844"/>
        <source>Valve Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="847"/>
        <source>Set Formula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="848"/>
        <source>Front-back Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="849"/>
        <source>Degassing Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="851"/>
        <source>AB Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="852"/>
        <source>Temp Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="853"/>
        <source>Cond Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="867"/>
        <source>Control Water Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="897"/>
        <source>If there a bloodleak alarm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="898"/>
        <source>Blood Leak Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="899"/>
        <source>Set BLood Leak Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="921"/>
        <location filename="../../src/common/common_tr_string.h" line="933"/>
        <source>Stop discharge test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="927"/>
        <source>Charging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="928"/>
        <source>Charge complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="929"/>
        <source>Pre boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="930"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="931"/>
        <source>Reserve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="932"/>
        <source>Discharge testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="942"/>
        <source>Blocking/Up Sensor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="943"/>
        <source>Down Sensor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="945"/>
        <source>Length of syringe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="946"/>
        <source>Syringe capacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="951"/>
        <source>Click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="952"/>
        <source>Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="953"/>
        <source>Should be set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="964"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="965"/>
        <source>Pipe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="966"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="967"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="969"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="971"/>
        <source>Cavity Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="972"/>
        <source>Cavity Capacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="974"/>
        <source>Speed Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="975"/>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="976"/>
        <source>Mid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="977"/>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="978"/>
        <source>Other Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="980"/>
        <source>Basic Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="981"/>
        <source>Real Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="984"/>
        <source>Send Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="986"/>
        <source>Rapid Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="987"/>
        <source>Rapid Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="990"/>
        <source>First Dose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="993"/>
        <source>TMP Current Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="997"/>
        <source>Degassing Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1008"/>
        <source>Send param finish!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1009"/>
        <source>Send param fail !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1010"/>
        <source>The write id number cannot be less than 10 !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1011"/>
        <source>Id number cannot select be less than 10 !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1012"/>
        <source>Please write patient information first !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1015"/>
        <source>Read information sucess!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1016"/>
        <source>Write information sucess!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1017"/>
        <source>Not this patient idnum! </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1022"/>
        <source>Test runing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1023"/>
        <source>Test stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1024"/>
        <source>Test finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1026"/>
        <source>A Pump testing,please stop !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1027"/>
        <source>B Pump testing,please stop !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1029"/>
        <source>Running state of the water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1030"/>
        <source>The state of Bloodleadcheck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1032"/>
        <source>B Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1033"/>
        <source>Set B Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1035"/>
        <source>Mix Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1036"/>
        <source>Set Mix Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1038"/>
        <source>Mix Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1039"/>
        <source>Set Mix Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1042"/>
        <source>Outlet Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1043"/>
        <source>Set Outlet Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1045"/>
        <source>Outlet Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1046"/>
        <source>Set Outlet Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1048"/>
        <source>After Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1049"/>
        <source>Set After Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1051"/>
        <source>After Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1052"/>
        <source>Set After Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1054"/>
        <source>Disinfect Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1055"/>
        <source>Set Disinfect Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1057"/>
        <source>Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1058"/>
        <source>Current feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1059"/>
        <source>Feedback alarm threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1060"/>
        <source>Set alarm threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1061"/>
        <source>Feedback 100 Cavity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1062"/>
        <source>Alarm upper limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1063"/>
        <source>Set  Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1065"/>
        <source>Heater Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1066"/>
        <source>Set Heater Temp Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1068"/>
        <source>B Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1069"/>
        <source>Set B Cond Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1072"/>
        <source>Note: please click to read the parameters before debugging.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1073"/>
        <source>1.Select high speed or low speed, click start test,read the pulse.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1075"/>
        <source>2.If the theory of pulse and pulse actual gap is too big, then click start since the correction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1077"/>
        <source>3.Prepare a measuring cup, make sure good pipe diameter and time,click start.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1079"/>
        <source>4.The measuring cup measure when feedback input, and click the correction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1084"/>
        <source>1.Observe the heparin pump button status and alarm information is correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1086"/>
        <source>2.According to the actual situation, set up syringes length and capacity.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1088"/>
        <source>3.Prepare a measuring cup, make sure good speed and time, click start, and input the actual measured values, click send.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1090"/>
        <source>4.Determine the good starting dose, click start, and input the actual measured values, click send.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1094"/>
        <source>1.The pressure value, based on the current equipment real-time pressure, dynamic update the display.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="816"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="209"/>
        <source>DiaFlow Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="210"/>
        <source>Heparin Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="211"/>
        <location filename="../../src/common/common_tr_string.h" line="265"/>
        <source>Cond Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="212"/>
        <location filename="../../src/common/common_tr_string.h" line="268"/>
        <source>Temp Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="213"/>
        <source>HCO3 Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="817"/>
        <source>Bat and power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="856"/>
        <location filename="../../src/common/common_tr_string.h" line="877"/>
        <source>Blood Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="857"/>
        <source>Water Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="858"/>
        <source>User Param</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="859"/>
        <source>Project Param</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="860"/>
        <source>Setup Param</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="861"/>
        <source>Drain Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="862"/>
        <source>Ts Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="863"/>
        <source>Water Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="864"/>
        <source>Use Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="866"/>
        <source>Reset Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="868"/>
        <source>Turn Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="870"/>
        <source>pre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="871"/>
        <source>next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="876"/>
        <source>Read Param</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="878"/>
        <source>BloodPump Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="879"/>
        <source>SubPump Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="880"/>
        <source>HeparinPump Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="881"/>
        <source>Pressure Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="882"/>
        <source>Check Bubble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="883"/>
        <source>Check Choke Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="884"/>
        <source>Sound and light detecting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="885"/>
        <source>Battery supply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="887"/>
        <source>Liquid Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="888"/>
        <source>Liquid Alarm Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="889"/>
        <source>Liquid Raised Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="890"/>
        <source>Liquid Reduce Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="892"/>
        <source>Blood Detection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="893"/>
        <source>Artery Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="894"/>
        <source>Vein Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="895"/>
        <source>Have Blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="896"/>
        <source>No Blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="901"/>
        <source>Artery Clip Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="902"/>
        <source>Vein Clip Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="903"/>
        <source>ON/OFF Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="904"/>
        <source>Monitoring sensor value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="907"/>
        <source>State of sound:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="908"/>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="909"/>
        <source>Macron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="910"/>
        <source>Mediant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="911"/>
        <source>Tone pips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="912"/>
        <source>State of alarmlight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="914"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="915"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="916"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="918"/>
        <source>Battery status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="919"/>
        <source>Power status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="920"/>
        <source>Bat discharge test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="922"/>
        <source>The last stop of blood pump:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="923"/>
        <source>The last time of battery discharge:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="924"/>
        <source>Blood pump speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="925"/>
        <source>Heparin pump speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="935"/>
        <source>Door Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="936"/>
        <source>Start Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="937"/>
        <source>+Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="938"/>
        <source>-Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="939"/>
        <source>Up Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="940"/>
        <source>Down Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="941"/>
        <source>Up Alarm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="944"/>
        <source>Down Alarm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="947"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="948"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="949"/>
        <source>Press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="950"/>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="956"/>
        <source>HSpeed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="957"/>
        <source>LSpeed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="958"/>
        <source>Basic Pulse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="959"/>
        <source>Real Pulse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="960"/>
        <source>Start Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="961"/>
        <source>Stop Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="962"/>
        <source>Start Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="963"/>
        <source>Stop Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="968"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="970"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="982"/>
        <source>Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="983"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="989"/>
        <source>Runing status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="991"/>
        <source>AP Current Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="992"/>
        <source>VP Current Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="994"/>
        <source>WP Current Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="995"/>
        <source>Degassing Pressure:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="996"/>
        <source>PSN Pressure:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="998"/>
        <source>If there is a bubble alarm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="999"/>
        <source>Tiny bubbles accumulation limit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1000"/>
        <source>Set accumulation limit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1001"/>
        <source>Bubble pulse width alarm threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1002"/>
        <source>Set pulse width alarm threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1004"/>
        <source>Param reading,please wait!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1005"/>
        <source>Read param fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1006"/>
        <source>Read param sucess!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1007"/>
        <source>Has not been read parameters, please click to Read Param!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1019"/>
        <source>Pump Runing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1020"/>
        <source>Pump Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="1021"/>
        <source>Pump Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="515"/>
        <source>CLPV drive or flow resistance feedback!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="517"/>
        <source>CLPA error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="518"/>
        <source>CLPA drive or flow resistance feedback!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="520"/>
        <source>ADPV error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="521"/>
        <location filename="../../src/common/common_tr_string.h" line="524"/>
        <location filename="../../src/common/common_tr_string.h" line="527"/>
        <source>Remove the line!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="523"/>
        <source>ADPA error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="526"/>
        <source>LDS error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="529"/>
        <source>PA error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="532"/>
        <source>PV error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="535"/>
        <source>TMP error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="538"/>
        <source>BLM error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="541"/>
        <source>BOM error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="542"/>
        <source>No blood oxygen module or communication failures!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="544"/>
        <source>BPM error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="545"/>
        <source>No Blood pressure module or communication failures!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="547"/>
        <location filename="../../src/common/common_tr_string.h" line="550"/>
        <location filename="../../src/common/common_tr_string.h" line="553"/>
        <source>BLOOD1 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="556"/>
        <location filename="../../src/common/common_tr_string.h" line="559"/>
        <location filename="../../src/common/common_tr_string.h" line="562"/>
        <source>BLOOD2 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="557"/>
        <source>NO2 blood pump is out of control!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="560"/>
        <source>NO2 blood pump no feedback!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="563"/>
        <source>NO2 blood pump selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="565"/>
        <source>Heparin error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="570"/>
        <source>N7 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="573"/>
        <source>N9 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="576"/>
        <source>N10 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="579"/>
        <source>N15 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="582"/>
        <source>N5 error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="586"/>
        <source>Selfcheck:Part of the blood selfcheck fail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="589"/>
        <source>Selfcheck:Part of the water selfcheck fail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="374"/>
        <source>No1 blood pump out of control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="94"/>
        <source>No blood,whether to continue return blood? &apos;Yes&apos;-continue,&apos;No&apos;-end!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="97"/>
        <source>Stop blood pump alarm is processed,please open blood pump!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="137"/>
        <source>connectP.t no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="138"/>
        <source>Online connectP.t no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="139"/>
        <source>connectP.t have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="140"/>
        <source>Online connectP.t have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="141"/>
        <source>connectP.t stop no fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="142"/>
        <source>connectP.t stop have fluid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="148"/>
        <source>Bloodreturn have blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="149"/>
        <source>Online Bloodreturn have blood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="539"/>
        <source>Blood leak monitor fault!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="548"/>
        <source>NO1 blood pump is out of control!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="551"/>
        <source>NO1 blood pump no feedback!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="554"/>
        <source>NO1 blood pump selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="566"/>
        <source>Heparin pump selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="571"/>
        <source>N7 selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="574"/>
        <source>N9 selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="577"/>
        <source>N10 selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="580"/>
        <source>N15 selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="583"/>
        <source>N5 selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="587"/>
        <source>Part of the blood selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="590"/>
        <source>Part of the water selfcheck fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="598"/>
        <source>prompt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="600"/>
        <source>Blood or water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="602"/>
        <source>Program prompts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="604"/>
        <source>The power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="606"/>
        <source>Blood pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="608"/>
        <source>Backup pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="610"/>
        <source>Heparin pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="612"/>
        <source>Self check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="614"/>
        <source>The unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="619"/>
        <source>N3 canopen error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="622"/>
        <source>N5 canopen error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="625"/>
        <source>N9 canopen error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="628"/>
        <source>N10 canopen error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="631"/>
        <source>N15 canopen error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="634"/>
        <source>N7 canopen error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="671"/>
        <source>Systolic upper limit alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="672"/>
        <source>Systolic beyond the upper limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="674"/>
        <source>Systolic lower limit alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="675"/>
        <source>Systolic beyond the lower limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="678"/>
        <source>Diastolic upper limit alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="679"/>
        <source>Diastolic beyond the upper limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="681"/>
        <source>Diastolic lower limit alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="682"/>
        <source>Diastolic beyond the lower limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="685"/>
        <source>Pulse upper limit alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="686"/>
        <source>Pulse beyond the upper limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="688"/>
        <source>Pulse lower limit alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="689"/>
        <source>Pulse beyond the lower limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="692"/>
        <source>Time to stop heparin pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="693"/>
        <source>Has reached the stop time!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="696"/>
        <source>Please open the heparin pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="697"/>
        <source>Didn&apos;t open the heparin pump!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="700"/>
        <source>Please open the blood pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="701"/>
        <source>The alarm already processed,please open the blood pump!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="708"/>
        <source>Electric supply stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="709"/>
        <source>Electric supply stop!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="712"/>
        <source>Please select a row !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/common_tr_string.h" line="713"/>
        <source>Are you sure to delete ?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="47"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="85"/>
        <source>A.P.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="51"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="86"/>
        <source>V.P.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="55"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="87"/>
        <source>TMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="59"/>
        <location filename="../../src/scenes/scene_main/scene_main.cpp" line="88"/>
        <source>Cond.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="583"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="572"/>
        <source>Alarm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="557"/>
        <source>Warn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="420"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="286"/>
        <source>WorkModel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="410"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="198"/>
        <source>Return to ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="429"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="186"/>
        <source>CureFinish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="447"/>
        <location filename="../../src/scenes/scene_main/widget_measure.cpp" line="260"/>
        <source>Confirm AP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="455"/>
        <location filename="../../src/scenes/scene_main/widget_measure.cpp" line="634"/>
        <source>Confirm VP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="463"/>
        <location filename="../../src/scenes/scene_main/widget_measure.cpp" line="861"/>
        <source>Confirm TMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="165"/>
        <source>Please Input Passwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="400"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="190"/>
        <source>Cure Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/data_manage/data_set.cpp" line="438"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="194"/>
        <source>CureLeave</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneBloodVolume</name>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="68"/>
        <source>Dry weight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="69"/>
        <source>Kg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="71"/>
        <source>BloodVolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_bloodvolume.cpp" line="73"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneControlWaterGraph</name>
    <message>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="743"/>
        <source>Blood Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="744"/>
        <source>Sub Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="870"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1833"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1837"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1841"/>
        <location filename="../../src/debug_mode/scene_controlwater_graph/scene_controlwater_graph.cpp" line="1845"/>
        <source>Contrlwater volt:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneDisinfect</name>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="69"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="838"/>
        <source>Disinfect</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="117"/>
        <source>              Auto Off : 10min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="862"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="863"/>
        <source>Filter Change</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="230"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="719"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="842"/>
        <source>Run</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="250"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="851"/>
        <source>Shut Off</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="538"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1236"/>
        <source>stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="561"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1187"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1366"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1404"/>
        <source>Rinse</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="568"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1192"/>
        <source>Hot Rinse</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="581"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1197"/>
        <source>Chymistry Peracetic</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="584"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1200"/>
        <source>Chymistry Citric</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="587"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1203"/>
        <source>Chymistry Reserve3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="594"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1208"/>
        <source>Chloros</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="600"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1212"/>
        <source>Sodium citrate</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="606"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1216"/>
        <source>Sodium citrate 85</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="612"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1220"/>
        <source>hot Disinfect</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="679"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1272"/>
        <source>         Remaining Time : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="679"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1272"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="858"/>
        <source>     Filter1           Filter2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="859"/>
        <source>All Times :                                            </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="860"/>
        <source>Used Times :                                            </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="861"/>
        <source>Remain Times :                                            </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1371"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1406"/>
        <source>Hot rinse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1376"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1408"/>
        <source>Chemical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1381"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1410"/>
        <source>Hot Water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1386"/>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="1412"/>
        <source>Hot Acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="874"/>
        <source>Disinfect completed! Machine will shutdown automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="875"/>
        <source>in          minutes if no operation !</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="854"/>
        <source>     Date            Time          Program Type</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="857"/>
        <source>Remaining Time Until Filter Change</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="853"/>
        <source>Last Programs</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/scene_disinfect.cpp" line="847"/>
        <source>Stop</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneHistory</name>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="230"/>
        <source>Introduce:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="670"/>
        <source>Alarm record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="671"/>
        <source>history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="672"/>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="673"/>
        <source>first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="674"/>
        <source>up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="675"/>
        <source>down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="676"/>
        <source>last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <source>dispose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="678"/>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="679"/>
        <source>info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="722"/>
        <source>selfcheck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_history.cpp" line="726"/>
        <source>current</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneKTV</name>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="373"/>
        <source>Pre-dislysis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="374"/>
        <source>Post-dislysis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="375"/>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="377"/>
        <source>Age:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="378"/>
        <source>Gender:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="379"/>
        <source>  Calibration should be done when Kt/V tests inaccurately.In calibration,machine should be in prime status.Precondition on successful calibration: Pre-dialysis conductivity and post-dialysis conductivity should be in the range of 13.0-15.0 mS/cm,the error between them should be less than 1.0 mS/cm.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="385"/>
        <source>Male</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="386"/>
        <source>Female</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="387"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="388"/>
        <source>Ban</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="390"/>
        <source>Kt/V function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="391"/>
        <source>  Dialysis urea reduction rate just reflects reduction percentage of soluteinstead of actual solute-removing index. &gt;70% indicates dialysis adequacy.Only for reference! Please refer to actual clinical for analysis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="394"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="403"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="434"/>
        <source>First pre-dialysis BUN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="395"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="404"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="419"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="435"/>
        <source>First post-dialysis BUN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="396"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="397"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="407"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="408"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="424"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="425"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="426"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="440"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="441"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="442"/>
        <source>mmol/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="398"/>
        <source>Dialysis urea reduction rate(URR):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="399"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="410"/>
        <source>0 %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="400"/>
        <source>  Pool II solute clearance index, a parameter calculated by urea kinetic model, indicates solute removing index in dialysis. SRI&gt;70% indicates dialysis adequacy. Only for reference! Please refer to actual clinical for analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="406"/>
        <source>Pool II solute clearance index(SRI2pool):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="409"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="422"/>
        <source>ml</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="411"/>
        <source>  Normal protein catabolism rate.The protein intakes for dialysis patients should be more than 1.1(g/kg.d),then nPCR will be more than 1.1(g/kg.d) too.When nPCR is less than 0.8(g/kg.d),it means malnutrition and inadequate dialysisrate will be high. Only for reference! Please refer to actual clinical for analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="416"/>
        <source>Urine volume in dialysis interphase:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="417"/>
        <source>Interval time of dialysis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="418"/>
        <source>Urine BUN in dialysis interphase:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="420"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="436"/>
        <source>Second pre-dialysis BUN:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="421"/>
        <source>Normal protein catabolism rate(nPCR):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="423"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="443"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="444"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="427"/>
        <source>1000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="428"/>
        <source>g/kg.d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="429"/>
        <source>  Time Average Concentrations of Urea reflects synthesis situation of       dialysis urea remov index and patient&apos;s protein metabolism.TACurea&gt;50(mg/dl)       means reference index for dialysis adequacy.It indicates cardiovascular,      nervous system of alimentary canal and other long-term complications increase.      Only for reference! Please refer to actual clinical for analysis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="447"/>
        <source>  If the result after dialysis is &gt;1.2,it measn dialysis adequacy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="437"/>
        <source>Dialysis time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="376"/>
        <source>Dry weight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="405"/>
        <source>Acc UF Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="438"/>
        <source>Dialysis interval time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="439"/>
        <source>Time Average Concentrations of Urea(TACurea):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="445"/>
        <source>mg/dl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv.cpp" line="446"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneKTV2</name>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="197"/>
        <source>PerInfo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="291"/>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="292"/>
        <source>Dry Weight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="293"/>
        <source>Age:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="294"/>
        <source>Gender:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="296"/>
        <source>Male</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="297"/>
        <source>Female</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="298"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="301"/>
        <source>Dialyzer Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="303"/>
        <source>Blood Flow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="299"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="304"/>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="311"/>
        <source>[ml/min]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="305"/>
        <source>Patient Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="306"/>
        <source>Treatment Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="307"/>
        <source>[h:min]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="308"/>
        <source>UF Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="309"/>
        <source>[ml]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="310"/>
        <source>Dialysate Flowrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="312"/>
        <source>Kt/V Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="313"/>
        <source>Kt/V Upto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="314"/>
        <source>Kt/V Actual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="316"/>
        <source>  If the result after dialysis is &gt;1.2,it measn dialysis adequacy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/scene_ktv2.cpp" line="317"/>
        <source>P.t Info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneLogEmr</name>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_emr.cpp" line="29"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_emr.cpp" line="30"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneLogRun</name>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="87"/>
        <source>Next Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="88"/>
        <source>Pre Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>workstatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_run.cpp" line="89"/>
        <source>note</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneLogTreatment</name>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="12"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="10"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="44"/>
        <source>  conductivity   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="45"/>
        <source>   temperature  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="46"/>
        <source>  DialysisFlux </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="47"/>
        <source>   UFR         </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="48"/>
        <source>   HeparinFlux  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="49"/>
        <source>ArterialPressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="50"/>
        <source> VenousPressure </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="51"/>
        <source> Transmembrane  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="52"/>
        <source> blood pressure </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="53"/>
        <source>      ktv       </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_treatment.cpp" line="54"/>
        <source>    alerting    </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneLogWarn</name>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_log_warn.cpp" line="70"/>
        <source>dispose</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneMaintain</name>
    <message>
        <location filename="../../src/maintain/scene_maintain.cpp" line="195"/>
        <source>Project Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>参数设置</source>
        <translation type="obsolete">Params set</translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain.cpp" line="196"/>
        <source>Config Language</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain.cpp" line="197"/>
        <source>Return</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneMaintainConfigLanguage</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="19"/>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="39"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="22"/>
        <location filename="../../src/maintain/scene_maintain_config_language.cpp" line="40"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneProjectModeEeprom</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="54"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="95"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="57"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="96"/>
        <source>Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="87"/>
        <source>0000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="88"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="89"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="92"/>
        <location filename="../../src/maintain/scene_maintain_project_eeprom.cpp" line="93"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneProjectModeFormulaSet</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="41"/>
        <source>mmol/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="42"/>
        <source>g/l</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="462"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="538"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="624"/>
        <source>/Config/Formula/Default%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="472"/>
        <source>One</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="473"/>
        <source>Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="474"/>
        <source>Three</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="475"/>
        <source>Four</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="228"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="477"/>
        <source>NaAc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="226"/>
        <source>B scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="227"/>
        <source>Water scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="229"/>
        <source>Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="230"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="232"/>
        <source>HCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="234"/>
        <source>Acetate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="235"/>
        <source>Ca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="237"/>
        <source>Default Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="478"/>
        <source>Na+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="479"/>
        <source>Cl-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="480"/>
        <source>K+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="482"/>
        <source>Mg++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="483"/>
        <source>Acetate+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="484"/>
        <source>Ca++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="485"/>
        <source>B)NaCl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="486"/>
        <source>Default Na+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="238"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="487"/>
        <source>Default HCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="497"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="556"/>
        <source>RadioB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="498"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="557"/>
        <source>RadioWater</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="499"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="558"/>
        <source>NaAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="503"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="560"/>
        <source>CL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="231"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="504"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="561"/>
        <source>K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="233"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="508"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="563"/>
        <source>Mg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="509"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="564"/>
        <source>ACE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="510"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="565"/>
        <source>CA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="236"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="511"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="566"/>
        <source>BNaCl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="506"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="562"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="569"/>
        <source>Stand_HCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="501"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="559"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="570"/>
        <source>Stand_Na</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="476"/>
        <source>Formula  1 :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="512"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="567"/>
        <source>DNa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="513"/>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="568"/>
        <source>DHCO3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="571"/>
        <source>Stand_B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="572"/>
        <source>Stand_Water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="611"/>
        <source>/Config/Formula/Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_formulaset.cpp" line="615"/>
        <source>use</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneProjectModeParams</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="108"/>
        <source>Maintain Params</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="109"/>
        <source>Params</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="110"/>
        <source>EEprom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params.cpp" line="111"/>
        <source>Return</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneProjectModeParamsCommon</name>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>max</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1308"/>
        <source>/Config/Params_UF/UF_Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1425"/>
        <source>/Config/Params_UF/Earlier_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1627"/>
        <source>/Config/Params_Dialyser/onlineRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1888"/>
        <source>/Config/Params_BP/Rate_GetBlood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2763"/>
        <source>/Config/Params_PreFlush/BpRate_Conect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2809"/>
        <source>/Config/Params_PreFlush/BpRate_phase1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2855"/>
        <source>/Config/Params_PreFlush/BpRate_phase2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2901"/>
        <source>/Config/Params_PreFlush/BpRate_phase3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2947"/>
        <source>/Config/Params_PreFlush/TMPUp_PF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3000"/>
        <source>/Config/Params_ColdFlush/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3055"/>
        <source>/Config/Params_ColdFlush/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3150"/>
        <source>/Config/Params_HotFlush/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3414"/>
        <source>/Config/Params_Chymistry_Citric/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3453"/>
        <source>/Config/Params_Chymistry_Citric/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3590"/>
        <source>/Config/Params_Chymistry_Citric/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3644"/>
        <source>/Config/Params_Chymistry_Peracetic/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3654"/>
        <source>/Config/Params_Chymistry_Peracetic/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3703"/>
        <source>/Config/Params_Chymistry_Peracetic/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3758"/>
        <source>/Config/Params_Chymistry_Reserve3/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3768"/>
        <source>/Config/Params_Chymistry_Reserve3/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3818"/>
        <source>/Config/Params_Chymistry_Reserve3/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3874"/>
        <source>/Config/Params_Hot_Citric/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3884"/>
        <source>/Config/Params_Hot_Citric/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3934"/>
        <source>/Config/Params_Hot_Citric/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3979"/>
        <source>/Config/Params_Hot/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3989"/>
        <source>/Config/Params_Hot/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4065"/>
        <source>/Config/Params_Center_Chymistry_Input/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4075"/>
        <source>/Config/Params_Center_Chymistry_Input/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4085"/>
        <source>/Config/Params_Center_Chymistry_Input/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4139"/>
        <source>/Config/Params_Center_Chymistry_Flush/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4149"/>
        <source>/Config/Params_Center_Chymistry_Flush/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4159"/>
        <source>/Config/Params_Center_Chymistry_Flush/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4213"/>
        <source>/Config/Params_Center_Hot/Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4223"/>
        <source>/Config/Params_Center_Hot/Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4243"/>
        <source>/Config/Params_Center_Hot/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4297"/>
        <source>/Config/Params_Center_Flush_Entry/Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4346"/>
        <source>/Config/Auto_scale/AP_ReadySafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4356"/>
        <source>/Config/Auto_scale/AP_ReadySafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4366"/>
        <source>/Config/Auto_scale/AP_RunSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4376"/>
        <source>/Config/Auto_scale/AP_RunSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4406"/>
        <source>/Config/Auto_scale/AP_RunAutoScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4416"/>
        <source>/Config/Auto_scale/AP_RunAutoScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4386"/>
        <source>/Config/Auto_scale/AP_StopSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4396"/>
        <source>/Config/Auto_scale/AP_StopSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4429"/>
        <source>/Config/Auto_scale/VP_ReadySafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4439"/>
        <source>/Config/Auto_scale/VP_ReadySafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4449"/>
        <source>/Config/Auto_scale/VP_RunSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4459"/>
        <source>/Config/Auto_scale/VP_RunSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4489"/>
        <source>/Config/Auto_scale/VP_RunAutoScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4499"/>
        <source>/Config/Auto_scale/VP_RunAutoScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4469"/>
        <source>/Config/Auto_scale/VP_StopSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4479"/>
        <source>/Config/Auto_scale/VP_StopSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4513"/>
        <source>/Config/Auto_scale/TMP_ReadySafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4523"/>
        <source>/Config/Auto_scale/TMP_ReadySafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4533"/>
        <source>/Config/Auto_scale/TMP_RunSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4543"/>
        <source>/Config/Auto_scale/TMP_RunSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4573"/>
        <source>/Config/Auto_scale/TMP_RunAutoScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4583"/>
        <source>/Config/Auto_scale/TMP_RunAutoScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4553"/>
        <source>/Config/Auto_scale/TMP_StopSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4563"/>
        <source>/Config/Auto_scale/TMP_StopSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4595"/>
        <source>/Config/Auto_scale/AP_SPAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4606"/>
        <source>/Config/Auto_scale/VP_SPAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4616"/>
        <source>/Config/Auto_scale/TEMP_SPAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4626"/>
        <source>/Config/Auto_scale/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4636"/>
        <source>/Config/Auto_scale/Alarm_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4311"/>
        <source>/Config/Clean_cond/B_cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4321"/>
        <source>/Config/Clean_cond/Mix_cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4331"/>
        <source>/Config/Clean_cond/Out_cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1338"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1383"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1418"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1457"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1497"/>
        <source>UF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4314"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4324"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4334"/>
        <source>Clean_cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4314"/>
        <source>B_cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4324"/>
        <source>Mix_cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4334"/>
        <source>Out_cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4349"/>
        <source>AP_ReadySafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4359"/>
        <source>AP_ReadySafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4369"/>
        <source>AP_RunSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4379"/>
        <source>AP_RunSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4389"/>
        <source>AP_StopSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4399"/>
        <source>AP_StopSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4409"/>
        <source>AP_RunAutoScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4419"/>
        <source>AP_RunAutoScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4432"/>
        <source>VP_ReadySafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4442"/>
        <source>VP_ReadySafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4452"/>
        <source>VP_RunSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4462"/>
        <source>VP_RunSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4472"/>
        <source>VP_StopSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4482"/>
        <source>VP_StopSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4492"/>
        <source>VP_RunAutoScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4502"/>
        <source>VP_RunAutoScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4516"/>
        <source>TMP_ReadySafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4526"/>
        <source>TMP_ReadySafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4536"/>
        <source>TMP_RunSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4546"/>
        <source>TMP_RunSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4556"/>
        <source>TMP_StopSafeScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4566"/>
        <source>TMP_StopSafeScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4576"/>
        <source>TMP_RunAutoScaleUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4586"/>
        <source>TMP_RunAutoScaleLow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4666"/>
        <source>unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4699"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4700"/>
        <source>Factory Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1354"/>
        <source>/Config/Params_UF/UF_Rate</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1345"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1390"/>
        <source>/Config/Params_UF/UF_Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1510"/>
        <source>/Config/Params_Dialyser/Temp</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1542"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1581"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1620"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1659"/>
        <source>Dialyser</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1549"/>
        <source>/Config/Params_Dialyser/Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1588"/>
        <source>/Config/Params_Dialyser/Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1671"/>
        <source>/Config/Params_BP/BP_Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1702"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1764"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1803"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1842"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1881"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1920"/>
        <source>BP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1732"/>
        <source>/Config/Params_BP/Rate_CheckSelf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1771"/>
        <source>/Config/Params_BP/Rate_ThreatMent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1810"/>
        <source>/Config/Params_BP/Rate_ReturnBlood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1849"/>
        <source>/Config/Params_BP/Rate_Preflush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2044"/>
        <source>/Config/Params_Heparin/First_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2076"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2115"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2154"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2193"/>
        <source>Heparin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2083"/>
        <source>/Config/Params_Heparin/Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2122"/>
        <source>/Config/Params_Heparin/Pre_StopTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2161"/>
        <source>/Config/Params_Heparin/add_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2229"/>
        <source>/Config/Params_SubP/Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2261"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2300"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2339"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2379"/>
        <source>Sub Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2268"/>
        <source>/Config/Params_SubP/Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2307"/>
        <source>/Config/Params_SubP/Rapid_Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2391"/>
        <source>/Config/Params_TreatTime/Hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2423"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2462"/>
        <source>Threat Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2430"/>
        <source>/Config/Params_TreatTime/min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2515"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2561"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2600"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2639"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2678"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2717"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2756"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2803"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2849"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2895"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2941"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2979"/>
        <source>PreFlush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2568"/>
        <source>/Config/Params_PreFlush/Dialyser_Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2607"/>
        <source>/Config/Params_PreFlush/Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2646"/>
        <source>/Config/Params_PreFlush/PF_UF_Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2685"/>
        <source>/Config/Params_PreFlush/PF_UF_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2724"/>
        <source>/Config/Params_PreFlush/PF_Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2474"/>
        <source>/Config/Params_PreFlush/BpRate_First_FiveMin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2521"/>
        <source>/Config/Params_PreFlush/BpRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3032"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3058"/>
        <source>ColdFlush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3607"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3720"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3836"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3952"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4028"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4102"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4176"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4260"/>
        <source>PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3617"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3731"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3847"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3962"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4048"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4122"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4196"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4280"/>
        <source>Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3627"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3741"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3857"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4038"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4112"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4186"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4270"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4629"/>
        <source>Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3637"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3751"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3867"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3972"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4058"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4132"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4206"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4290"/>
        <source>BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3127"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3153"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3200"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3239"/>
        <source>HotFlush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3095"/>
        <source>/Config/Params_HotFlush/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3168"/>
        <source>/Config/Params_HotFlush/TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3667"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3781"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3897"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4003"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4236"/>
        <source>TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3207"/>
        <source>/Config/Params_HotFlush/RealTmep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3677"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3791"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3907"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4013"/>
        <source>RealTmep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3258"/>
        <source>/Config/Params_Chymistry_Citric/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3290"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3329"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3368"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3407"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3446"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3485"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3524"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3563"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3573"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3583"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3593"/>
        <source>Chymistry_Citric</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3297"/>
        <source>/Config/Params_Chymistry_Citric/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3336"/>
        <source>/Config/Params_Chymistry_Citric/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3375"/>
        <source>/Config/Params_Chymistry_Citric/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3492"/>
        <source>/Config/Params_Chymistry_Citric/TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3531"/>
        <source>/Config/Params_Chymistry_Citric/RealTmep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3570"/>
        <source>/Config/Params_Chymistry_Citric/Conduction_MAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3573"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3688"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3801"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3917"/>
        <source>Conduction_MAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3580"/>
        <source>/Config/Params_Chymistry_Citric/Conduction_MIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3583"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3696"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3811"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3927"/>
        <source>Conduction_MIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3604"/>
        <source>/Config/Params_Chymistry_Peracetic/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3607"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3617"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3627"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3637"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3647"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3657"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3667"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3677"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3688"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3696"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3706"/>
        <source>Chymistry_Peracetic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3614"/>
        <source>/Config/Params_Chymistry_Peracetic/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3624"/>
        <source>/Config/Params_Chymistry_Peracetic/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3634"/>
        <source>/Config/Params_Chymistry_Peracetic/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3664"/>
        <source>/Config/Params_Chymistry_Peracetic/TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3674"/>
        <source>/Config/Params_Chymistry_Peracetic/RealTmep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3685"/>
        <source>/Config/Params_Chymistry_Peracetic/Conduction_MAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3693"/>
        <source>/Config/Params_Chymistry_Peracetic/Conduction_MIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3717"/>
        <source>/Config/Params_Chymistry_Reserve3/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3720"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3731"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3741"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3751"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3761"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3771"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3781"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3791"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3801"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3811"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3821"/>
        <source>Chymistry_Reserve3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3728"/>
        <source>/Config/Params_Chymistry_Reserve3/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3738"/>
        <source>/Config/Params_Chymistry_Reserve3/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3748"/>
        <source>/Config/Params_Chymistry_Reserve3/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3778"/>
        <source>/Config/Params_Chymistry_Reserve3/TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3788"/>
        <source>/Config/Params_Chymistry_Reserve3/RealTmep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3798"/>
        <source>/Config/Params_Chymistry_Reserve3/Conduction_MAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3808"/>
        <source>/Config/Params_Chymistry_Reserve3/Conduction_MIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3833"/>
        <source>/Config/Params_Hot_Citric/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3058"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3153"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3647"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3761"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3877"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3982"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4068"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4142"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4216"/>
        <source>Flush_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3657"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3771"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3887"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3992"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4078"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4152"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4226"/>
        <source>Loop_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3593"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3706"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3821"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3937"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4088"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4162"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4246"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4300"/>
        <source>Suck_Flux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="1464"/>
        <source>/Config/Params_UF/AutoChange_Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="2346"/>
        <source>/Config/Params_SubP/AutoChange_Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3836"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3847"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3857"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3867"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3877"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3887"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3897"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3907"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3917"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3927"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3937"/>
        <source>Hot_Citric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3844"/>
        <source>/Config/Params_Hot_Citric/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3854"/>
        <source>/Config/Params_Hot_Citric/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3864"/>
        <source>/Config/Params_Hot_Citric/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3894"/>
        <source>/Config/Params_Hot_Citric/TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3904"/>
        <source>/Config/Params_Hot_Citric/RealTmep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3914"/>
        <source>/Config/Params_Hot_Citric/Conduction_MAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3924"/>
        <source>/Config/Params_Hot_Citric/Conduction_MIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3949"/>
        <source>/Config/Params_Hot/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3952"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3962"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3972"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3982"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3992"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4003"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4013"/>
        <source>Hot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3959"/>
        <source>/Config/Params_Hot/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="3969"/>
        <source>/Config/Params_Hot/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4000"/>
        <source>/Config/Params_Hot/TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4010"/>
        <source>/Config/Params_Hot/RealTmep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4025"/>
        <source>/Config/Params_Center_Chymistry_Input/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4028"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4038"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4048"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4058"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4078"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4088"/>
        <source>Center_Chymistry_Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4035"/>
        <source>/Config/Params_Center_Chymistry_Input/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4045"/>
        <source>/Config/Params_Center_Chymistry_Input/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4055"/>
        <source>/Config/Params_Center_Chymistry_Input/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4068"/>
        <source>Center_Chymistry_Inpult</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4099"/>
        <source>/Config/Params_Center_Chymistry_Flush/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4102"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4112"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4122"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4132"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4142"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4152"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4162"/>
        <source>Center_Chymistry_Flush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4109"/>
        <source>/Config/Params_Center_Chymistry_Flush/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4119"/>
        <source>/Config/Params_Center_Chymistry_Flush/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4129"/>
        <source>/Config/Params_Center_Chymistry_Flush/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4173"/>
        <source>/Config/Params_Center_Hot/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4176"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4186"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4196"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4206"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4216"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4226"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4236"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4246"/>
        <source>Center_Hot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4183"/>
        <source>/Config/Params_Center_Hot/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4193"/>
        <source>/Config/Params_Center_Hot/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4203"/>
        <source>/Config/Params_Center_Hot/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4233"/>
        <source>/Config/Params_Center_Hot/TargetTemp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4257"/>
        <source>/Config/Params_Center_Flush_Entry/PreFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4260"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4270"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4280"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4290"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4300"/>
        <source>Center_Flush_Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4267"/>
        <source>/Config/Params_Center_Flush_Entry/Hold_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4277"/>
        <source>/Config/Params_Center_Flush_Entry/Loop_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4287"/>
        <source>/Config/Params_Center_Flush_Entry/BackFlush_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4349"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4359"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4369"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4379"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4389"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4399"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4409"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4419"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4432"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4442"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4452"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4462"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4472"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4482"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4492"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4502"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4516"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4526"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4536"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4546"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4556"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4566"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4576"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4586"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4598"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4609"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4619"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4629"/>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4639"/>
        <source>Auto_scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4598"/>
        <source>AP_SPAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4609"/>
        <source>VP_SPAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4619"/>
        <source>TEMP_SPAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4639"/>
        <source>Alarm_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4697"/>
        <source>last</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/maintain/scene_maintain_project_params_common.cpp" line="4698"/>
        <source>next</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneRecordCurve</name>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="221"/>
        <source>Treatment start time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="223"/>
        <source>Treatment end time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="243"/>
        <source>Pre Cure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="244"/>
        <source>Nxt Cure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="245"/>
        <source>Pre Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="246"/>
        <source>Nxt Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="637"/>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="642"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="637"/>
        <source>C701</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="637"/>
        <source>C702</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="637"/>
        <source>C704</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="637"/>
        <source>C709</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="642"/>
        <source>T201</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="642"/>
        <source>T203</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="642"/>
        <source>T204</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/scene_record_curve.cpp" line="642"/>
        <source>T205</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupAdvertTimer</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="135"/>
        <source>SingleTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="136"/>
        <source>CycleTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="137"/>
        <source>RemainTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="139"/>
        <source>Stop/RUN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="140"/>
        <source>One-Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="141"/>
        <source>Cyc-Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="143"/>
        <source>Prompt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="144"/>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="145"/>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="147"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="148"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_advert_timer.cpp" line="150"/>
        <source>00:00:00</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupAutoWakeUp</name>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="320"/>
        <source>Monday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="321"/>
        <source>Tuesday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="322"/>
        <source>Wednesday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="323"/>
        <source>Thursday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="324"/>
        <source>Friday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="325"/>
        <source>Saturday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="326"/>
        <source>Sunday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="327"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="328"/>
        <source>Enable Auto-wake-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="329"/>
        <source>Power Time: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="330"/>
        <source>2000.0.0 0:0:0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="331"/>
        <source>Set Wakeup Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="332"/>
        <source>Time Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_autowakeup.cpp" line="333"/>
        <source>Time Copy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupBPM</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="118"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="504"/>
        <source>Lying</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="119"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="505"/>
        <source>Sitting</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="120"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="506"/>
        <source>Standing</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="128"/>
        <source>ADult</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="129"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="509"/>
        <source>Child</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>Time</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>Systolic 
 mmHg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>Diastolic 
 mmHg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <source>MAP 
 mmHg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="258"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="500"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="516"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="532"/>
        <source>Pulse</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="378"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="525"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="875"/>
        <source>Auto Measure 
 ON</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="370"/>
        <source>Auto Measure 
 OFF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="388"/>
        <source>Cancel Measure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="405"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="526"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="561"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="573"/>
        <source>Start Measure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="418"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="442"/>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="502"/>
        <source>SYS/DIA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="503"/>
        <source>Patient Position</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="508"/>
        <source>Adult</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="511"/>
        <source>Measure interval</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="515"/>
        <source>Lower</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="513"/>
        <source>Upper</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="524"/>
        <source>Close</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="427"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="527"/>
        <source>Table</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="507"/>
        <source>Belt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="512"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="529"/>
        <source>Systolic</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="514"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="530"/>
        <source>Diastolic</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="517"/>
        <source>Hour</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="518"/>
        <source>Min</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="523"/>
        <source>Curve/Table</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bpm.cpp" line="531"/>
        <source>MAP</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneSetupBloodTemp</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_bloodtemp.cpp" line="41"/>
        <source>Temp :</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SceneSetupCureTime</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="248"/>
        <source>Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="435"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="436"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="437"/>
        <source>Treatment time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="438"/>
        <source>Min time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="439"/>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="441"/>
        <source>/H:m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_cure_time.cpp" line="440"/>
        <source>Max time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupCurveTest</name>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="12"/>
        <source>线性曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="13"/>
        <source>抛物线曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="14"/>
        <source>三次曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="15"/>
        <source>指数曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="16"/>
        <source>阶梯曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="17"/>
        <source>方波曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="18"/>
        <source>反方波曲线</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="164"/>
        <source>超滤率曲线类型:  </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="165"/>
        <source>治疗时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="166"/>
        <source>脱水量</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="167"/>
        <source>初始化超滤值</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="168"/>
        <source>超滤最大值</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="169"/>
        <source>超滤最大值时刻</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../src/setup/setup_advanced/scene_setup_curve_test.cpp" line="177"/>
        <source>修改</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupDialysate</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="218"/>
        <source>Na+:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="219"/>
        <source>HCO3-:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="222"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="224"/>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="221"/>
        <source>Dialysate Temp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="220"/>
        <source>Dialysate Flow:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_dialysate.cpp" line="223"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupEC</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="19"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="43"/>
        <source>Na+:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="26"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_EC.cpp" line="42"/>
        <source>Cond:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupHemopump</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="371"/>
        <source>Supply Flux:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="372"/>
        <source>Blood Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="374"/>
        <source>yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="375"/>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="377"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="230"/>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="378"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="183"/>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="370"/>
        <source>Blood Flow:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="232"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="373"/>
        <source>Regard spare pump as blood pump:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_hemopump.cpp" line="376"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupHeparin</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="646"/>
        <source>Syringe Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="255"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="651"/>
        <source>BOLUS:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="652"/>
        <source>Heparin Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="654"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="376"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="655"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="197"/>
        <source>/Config/Engineer_Factoryset/HeparinMode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="229"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="648"/>
        <source>Initial Dose:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="235"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="649"/>
        <source>Dose rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="241"/>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="650"/>
        <source>Stop time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="368"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="647"/>
        <source>Acc heparin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_heparin.cpp" line="653"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupIsoUF</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="89"/>
        <source>ISO UF Hour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="94"/>
        <source>ISO UF Min:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="99"/>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="375"/>
        <source>ISO UF Goal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="373"/>
        <source>ISO UF Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="376"/>
        <source>ISO UF Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="377"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_isouf.cpp" line="378"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupLang</name>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_lang.cpp" line="219"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_lang.cpp" line="220"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupNaUF</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_nauf.cpp" line="427"/>
        <source>Na+ Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_nauf.cpp" line="428"/>
        <source>UF Profile</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupNetwork</name>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="269"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="271"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="273"/>
        <source>Ip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="274"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="282"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="286"/>
        <source>192</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="275"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="283"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="287"/>
        <source>168</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="276"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="284"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="289"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="277"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="278"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="279"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="280"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="285"/>
        <source>255</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="281"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="288"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="92"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="93"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="94"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="95"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="290"/>
        <source>Mask:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="87"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="88"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="89"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="90"/>
        <source>IP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="97"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="98"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="99"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="100"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="291"/>
        <source>Gateway:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="102"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="103"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="104"/>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="105"/>
        <source>Dns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="268"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="272"/>
        <source>Parameter of Network:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="292"/>
        <source>DNS:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_network.cpp" line="295"/>
        <source>Init wlan</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupPreflush</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="358"/>
        <source>Preflush Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="364"/>
        <source>Preflush Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="352"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="354"/>
        <source>Blood Pump Flow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="356"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="360"/>
        <source>Uf Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="362"/>
        <source>Uf Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="366"/>
        <source>Acc Preflush Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="369"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="371"/>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="372"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="373"/>
        <source>Enable online lead-in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="374"/>
        <source>Disable online lead-in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="375"/>
        <source>Enable online return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="376"/>
        <source>Disable online return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="378"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="380"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="635"/>
        <source>Preflush BP Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="641"/>
        <source>Preflush Blood Pump Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="647"/>
        <source>Dialysate Flow:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="659"/>
        <source>Preflush Uf Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="665"/>
        <source>Preflush Uf Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_preflush.cpp" line="671"/>
        <source>Return Blood Volume:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupPressure</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="406"/>
        <source>A.P Alarm Range:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="407"/>
        <source>V.P Alarm Range:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="408"/>
        <source>TMP Alarm Range:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_pressure.cpp" line="409"/>
        <source>Max TMP:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupSpO2</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_oximeter.cpp" line="153"/>
        <source>SpO2 :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupSubspump</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="57"/>
        <source>80</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="58"/>
        <source>160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="59"/>
        <source>240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="60"/>
        <source>320</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="61"/>
        <source>400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="62"/>
        <source>480</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="63"/>
        <source>560</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="186"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="383"/>
        <source>Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="201"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="227"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="392"/>
        <source>Run</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="215"/>
        <source>Dilute Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="216"/>
        <source>UF/BP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="217"/>
        <source>Blood Flow:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="218"/>
        <source>Dialysate Flow:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="220"/>
        <source>Sub. Flux:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="221"/>
        <source>Sub. Goal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="222"/>
        <source>Sub. Vol:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="223"/>
        <source>Rapid Infusion Vol:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="224"/>
        <source>Rapid Infusion Rate:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="225"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="226"/>
        <source>Cancel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="264"/>
        <source>Pre Dilute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="268"/>
        <source>Post Dilute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="452"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="459"/>
        <source>SUB speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="453"/>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="465"/>
        <source>SUB total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_subspump.cpp" line="471"/>
        <source>SUB Add:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupSysinfo</name>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="89"/>
        <source>Soft Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="90"/>
        <source>Manufacture date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="91"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_sysinfo.cpp" line="92"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupSystemTime</name>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="92"/>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="93"/>
        <source>Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="40"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="95"/>
        <source>China</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="41"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="96"/>
        <source>Japan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="42"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="97"/>
        <source>India</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="43"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="98"/>
        <source>Indonesia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="44"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="99"/>
        <source>Malaysia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="45"/>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="100"/>
        <source>Vietnam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="94"/>
        <source>Time Zone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="101"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_system_time.cpp" line="102"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupUf</name>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="222"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="229"/>
        <source>UF Goal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="223"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="235"/>
        <source>UF rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="392"/>
        <source>Treatment UF Goal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="393"/>
        <source>Treatment UF Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="394"/>
        <source>Now Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="400"/>
        <source>Cure UF Goal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="401"/>
        <source>Cure UF rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="402"/>
        <source>Now rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="395"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="403"/>
        <source>Acc UF Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="396"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="404"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="398"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="406"/>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="397"/>
        <location filename="../../src/setup/setup_cure/scene_setup_ultrafiltration.cpp" line="405"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupUnit</name>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="45"/>
        <source>Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="46"/>
        <source>Pressure:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="47"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/scene_setup_unit.cpp" line="48"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupWorkmode</name>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="938"/>
        <source>HD</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="939"/>
        <source>Single Needle</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="940"/>
        <source>SNDP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="941"/>
        <source>Double Needle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="943"/>
        <source>HDF (Online)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="944"/>
        <source>HF (Online)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="949"/>
        <source>ISO UF</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="950"/>
        <source>PE/HP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="951"/>
        <source>A + B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="953"/>
        <source>Acetate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="954"/>
        <source>Central fluid supply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="955"/>
        <source>Work Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="956"/>
        <source>Treatmemt Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="957"/>
        <source>Supply Fluid Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="945"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="947"/>
        <source>Predilution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="946"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="948"/>
        <source>Postdilution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="952"/>
        <source>A + B(Dry Powder)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="958"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="959"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="960"/>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="961"/>
        <source>NaAc:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="962"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="986"/>
        <source>g/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="964"/>
        <source>Na:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="965"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="968"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="971"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="974"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="977"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="980"/>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="983"/>
        <source>mmol/l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="967"/>
        <source>Cl:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="970"/>
        <source>K:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="973"/>
        <source>HCO3:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="976"/>
        <source>Mg:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="979"/>
        <source>Acetate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="982"/>
        <source>Ca:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_workmode/scene_setup_workmode.cpp" line="985"/>
        <source>B)NaCl:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSetupXmlconfig</name>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="57"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="79"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="91"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="79"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="91"/>
        <source>Config Files (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="58"/>
        <source>Config files (*.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="70"/>
        <source>update ok!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="109"/>
        <source>save fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="123"/>
        <source>save ok!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="129"/>
        <source>Load File :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="130"/>
        <source>Save File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="131"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="132"/>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="133"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/scene_setup_xmlconfig.cpp" line="134"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneSummary</name>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="341"/>
        <source>Summary Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="344"/>
        <source>Curve Type :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="345"/>
        <source>Dilution Type :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="346"/>
        <source>Remaining Time :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="347"/>
        <source>UF Rate :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="348"/>
        <source>UF Goal :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="349"/>
        <source>Acc UF Volume :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="350"/>
        <source>A.P. :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="351"/>
        <source>V.P. :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="352"/>
        <source>TMP :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="353"/>
        <source>Cond. :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="354"/>
        <source>Temp :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="355"/>
        <source>Heparin Flux:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="356"/>
        <source>Heparin Vol :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="357"/>
        <source>BP Flow :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="358"/>
        <source>Sub. Goal :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="359"/>
        <source>Sub. Vol :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="360"/>
        <source>Dialysate Flow :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="362"/>
        <source>Cond Profile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="363"/>
        <source>UF Profile:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="478"/>
        <source>Pre Dilute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="482"/>
        <source>Post Dilute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_summary/scene_summary.cpp" line="361"/>
        <source>Blood Temp :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Drain_Option</name>
    <message>
        <location filename="../../src/debug_mode/scene_drain_option/scene_drain_option.cpp" line="19"/>
        <source>Drain option</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Project_Param</name>
    <message>
        <location filename="../../src/debug_mode/scene_project_param/scene_project_param.cpp" line="18"/>
        <source>Project param</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Setup_Param</name>
    <message>
        <location filename="../../src/debug_mode/scene_setup_param/scene_setup_param.cpp" line="19"/>
        <source>Setup parm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Ts_Debug</name>
    <message>
        <location filename="../../src/debug_mode/scene_ts_debug/scene_ts_debug.cpp" line="19"/>
        <source>TS debug</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Use_Time</name>
    <message>
        <location filename="../../src/debug_mode/scene_use_time/scene_use_time.cpp" line="19"/>
        <source>Use time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_User_Param</name>
    <message>
        <location filename="../../src/debug_mode/scene_user_param/scene_user_param.cpp" line="19"/>
        <source>User param</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Scene_Water_Test</name>
    <message>
        <location filename="../../src/debug_mode/scene_water_test/scene_water_test.cpp" line="19"/>
        <source>Water test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenSnaper</name>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="110"/>
        <source>save image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="111"/>
        <source>Image(*.jpg *.png *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="122"/>
        <source>quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="127"/>
        <source>save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="178"/>
        <source>/hjx.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="180"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/common/ScreenSnaper.cpp" line="182"/>
        <source>%1 Files (*.%2);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserDataRequest</name>
    <message>
        <location filename="../../src/wlan/userdatarequest.cpp" line="86"/>
        <source>Authentication credentials required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/userdatarequest.cpp" line="89"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/userdatarequest.cpp" line="91"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetAimConfig</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="225"/>
        <source>ISO Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="387"/>
        <source>Blood Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="388"/>
        <source>Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="389"/>
        <source>UF Goal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="392"/>
        <source>ISO time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="240"/>
        <location filename="../../src/scenes/scene_main/widget_aim_config.cpp" line="390"/>
        <source>Sub. Pump</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetCheckSelf</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_check_self.cpp" line="93"/>
        <source>Self-testing</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WidgetCrossExtern</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="95"/>
        <source>Work mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="96"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="97"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_cross_extern.cpp" line="98"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetDisinfectRadioButton</name>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="124"/>
        <source>Rinse Selected</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="129"/>
        <source>Hot Rinse Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="152"/>
        <source>Hot Disinfect Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="156"/>
        <source>Hot CitricAcid Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="162"/>
        <source>Central Hot Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="166"/>
        <source>Central Chemical Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="170"/>
        <source>Central Disinfect Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="178"/>
        <source>No Work Model Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="180"/>
        <source>Rinse</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="183"/>
        <source>Chemical Disinfect</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="185"/>
        <source>Hot Disinfect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="187"/>
        <source>Central Disinfect Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="188"/>
        <source>Hot Acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="181"/>
        <source>Hot Rinse</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="135"/>
        <source>Chymistry Peracetic Selecte</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="139"/>
        <source>Chymistry Citric Selecte</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="143"/>
        <source>Chymistry Reserve3 Selecte</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_radio_button.cpp" line="147"/>
        <source>Chymistry Disinfect Error!</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WidgetIms</name>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="12"/>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="168"/>
        <source>IMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="170"/>
        <source>Log Warn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="171"/>
        <source>Log Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ims/widget_ims.cpp" line="173"/>
        <source>Record Profile</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetNotice</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="86"/>
        <source>Ready St</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="89"/>
        <source>Treatment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="92"/>
        <source>Disconnection</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="95"/>
        <source>Cleaning</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="98"/>
        <source>Debug</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="101"/>
        <source>Drain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="105"/>
        <source>Water Stop</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="156"/>
        <source>Ready</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="159"/>
        <source>BM_test</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="162"/>
        <source>BM test OK</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="165"/>
        <source>Prime</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="168"/>
        <source>Dialyze ready</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="171"/>
        <source>HD DoubleNeedle</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="174"/>
        <source>ISO DoubleNeedle</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="177"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="667"/>
        <source>HDFonline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="180"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="670"/>
        <source>HFonline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="183"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="186"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="673"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="676"/>
        <source>PE/PH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="189"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="679"/>
        <source>HD SNSP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="192"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="682"/>
        <source>HD SNDP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="195"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="685"/>
        <source>ISO SNSP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="198"/>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="688"/>
        <source>ISO SNDP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="234"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="255"/>
        <source>ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="258"/>
        <source>run</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="658"/>
        <source>Self testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="661"/>
        <source>HD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="664"/>
        <source>ISO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="694"/>
        <source>Priming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="698"/>
        <source>   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="708"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="711"/>
        <source>Bypass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_notice.cpp" line="714"/>
        <source>  </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSetupAdvanced</name>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="341"/>
        <source>Setup NaProfile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="344"/>
        <source>Setup Sequential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="347"/>
        <source>Setup Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="350"/>
        <source>Setup XmlConfig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="356"/>
        <source>Setup Preflush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="454"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="456"/>
        <source>Na Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="457"/>
        <source>Sequential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="458"/>
        <source>Cond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_advanced/widget_setup_advanced.cpp" line="460"/>
        <source>Preflush</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSetupCure</name>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="136"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="137"/>
        <source>Treat Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="138"/>
        <source>UF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="139"/>
        <source>Blood Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="140"/>
        <source>Heparin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="141"/>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="142"/>
        <source>Dialysate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="143"/>
        <source>Substitution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="144"/>
        <source>ISO UF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="237"/>
        <source>Setup Treatment time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="240"/>
        <source>Setup UF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="243"/>
        <source>Setup Bloodpump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="246"/>
        <source>Setup Dialysate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="249"/>
        <source>Setup Subspump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="252"/>
        <source>Setup ISO UF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="255"/>
        <source>Setup Heparin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_cure/widget_setup_cure.cpp" line="258"/>
        <source>Setup Pressure</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSetupExt</name>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="242"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="243"/>
        <source>BPM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="244"/>
        <source>SpO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="245"/>
        <source>BTM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="248"/>
        <source>Kt/V2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="249"/>
        <source>BVM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="246"/>
        <source>Timer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_ext/widget_setup_ext.cpp" line="247"/>
        <source>Kt/V</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSetupOther</name>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="277"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="278"/>
        <source>System Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="279"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="280"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="281"/>
        <source>System Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="252"/>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="282"/>
        <source>Maintain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="244"/>
        <source>Setup System Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="246"/>
        <source>Setup Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="248"/>
        <source>Setup Lang</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="250"/>
        <source>Setup System Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="254"/>
        <source>Status Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="258"/>
        <source>Setup Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="260"/>
        <source>Setup Auto-wake-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="287"/>
        <source>Auto-wake-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="262"/>
        <source>Setup Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="285"/>
        <source>Engineer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="286"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/setup/setup_other/widget_setup_other.cpp" line="283"/>
        <source>Status Map</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetSwitch</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="306"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="879"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1071"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1953"/>
        <source>Auto Prime</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="308"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="881"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1078"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1955"/>
        <source>Manual Prime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="339"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="892"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1051"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1098"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1209"/>
        <source>Connect P.t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="326"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1171"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1976"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="3677"/>
        <source>Treatment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="311"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="893"/>
        <source>UF Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="513"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="2003"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="514"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="2004"/>
        <source>Drain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="894"/>
        <source>Heparin Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="895"/>
        <source>Bypass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="218"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1106"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="1984"/>
        <location filename="../../src/scenes/scene_main/widget_switch.cpp" line="2002"/>
        <source>Return Blood</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>WidgetTempo</name>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_tempo.cpp" line="125"/>
        <source>Please wait till 100%.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_disinfect/widget_tempo.cpp" line="134"/>
        <source>Rinse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetTime</name>
    <message>
        <location filename="../../src/scenes/scene_main/widget_time.cpp" line="180"/>
        <source>Remaining time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WindowBoot</name>
    <message>
        <location filename="../../src/windows/window_boot.cpp" line="320"/>
        <source>Enter Self-test menu...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/windows/window_boot.cpp" line="321"/>
        <source>Skip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/windows/window_boot.cpp" line="322"/>
        <source>Debug mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WindowStatusMap</name>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="57"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="58"/>
        <source>Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="59"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/window_status_map/window_status_map.cpp" line="60"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Window_ChangeFilter</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1325"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1326"/>
        <source>Reset Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1328"/>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1354"/>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1376"/>
        <source>Dry Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1330"/>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="1371"/>
        <source>Stop Dry</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Window_Confirm</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="626"/>
        <source>Press&apos;Yes&apos; to auto scale AP!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="633"/>
        <source>Press&apos;Yes&apos; to auto scale VP!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="640"/>
        <source>Press&apos;Yes&apos; to auto scale TMP!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="650"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="651"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Window_Message</name>
    <message>
        <source>æä½æ¹æ³:</source>
        <translation type="obsolete">Guidances</translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="297"/>
        <source>Must confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="326"/>
        <source>Operation guide:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="478"/>
        <source>close</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="479"/>
        <source>last</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="480"/>
        <source>next</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_warn/scene_message.cpp" line="481"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Window_Note</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="158"/>
        <source>Do you want to start the &quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="161"/>
        <source>HD SNSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="164"/>
        <source>HD double</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="167"/>
        <source>HD SNDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="171"/>
        <source>HDF pre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="174"/>
        <source>HDF post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="178"/>
        <source>HF pre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="181"/>
        <source>HF post</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="185"/>
        <source>ISOUF SNSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="188"/>
        <source>ISOUF DNSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="227"/>
        <source>Cure Finished ? Press&apos;No&apos; to continut ,Press&apos;Yes&apos; to return blood .</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="191"/>
        <source>ISOUF SNDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="195"/>
        <source>PE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="198"/>
        <source>HD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="201"/>
        <source>&quot; Cure Mode?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="208"/>
        <source>Return to ready status,keep or reset parameters? Yes-keep,No-reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="215"/>
        <source>Do you want to change the work mode ?</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="221"/>
        <source>Do you want to leave cure ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="236"/>
        <source>Cancel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="237"/>
        <source>No</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="238"/>
        <source>Yes</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="239"/>
        <source>Confirm</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Window_Passwd</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="794"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="795"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="796"/>
        <source>Please Input Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="846"/>
        <source>Password Error !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Window_YES</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="497"/>
        <source>Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Window_YESNO</name>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="372"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scenes/scene_note/scene_note.cpp" line="373"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>wlan</name>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="76"/>
        <source>wlan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="77"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="78"/>
        <source>Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="79"/>
        <source>Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="82"/>
        <source>flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="83"/>
        <source>signal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="84"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="85"/>
        <source>BSSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/wlan/wlan.cpp" line="86"/>
        <source>SSID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
