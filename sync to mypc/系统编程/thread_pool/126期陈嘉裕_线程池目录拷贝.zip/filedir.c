/*
*功能：目录路径链表的初始化和添加，并实现查找目录和拷贝文件
*参数：目录路径链表，主函数传参
*/


#include "myhead.h"



pfile file_init()												//初始化链表
{
	pfile files = (pfile)malloc(sizeof(file));
	files->prev = files->next = files;
		
	return files;
}



int file_add(char *area,char *name,char *tar,pfile files)
{
	char filebuf[50] = {0};
	char tarbuf[50] = {0};
	pfile new = malloc(sizeof(file));
	if(new == NULL)
	{
		perror("creat new\n");
		return -1;
	}
	
	sprintf(filebuf,"%s/%s",area,name);
	sprintf(tarbuf,"%s/%s",tar,name);
	
	strcpy(new->filename,filebuf);
	strcpy(new->tarname,tarbuf);
	
	new->prev = files->prev;
	new->next = files;
	
	files->prev = new;
	new->prev->next = new;
	
	return 0;
}


void file_show(pfile file)
{
	pfile p = file->next;
	
	while(p != file)
	{
		printf("the name of file is : %s\n",p->filename);
		printf("the name of tar is : %s\n",p->tarname);
		p = p->next;
	}
}



int insert_cp(char *old,char *news,char *arg,int flags)
{
	if(flags == 0)
	{
		printf("the aim\n");
	}
	else if(flags == 1)
	{
	if(strstr(old,arg) == NULL)
		return -1;
	}
	else if(flags == 2)
		return -1;


	struct stat stat_buf;
	int resurt;
	
	
	char buf[2048] = {0};
	FILE *oldf = NULL;
	FILE *newf = NULL;
	
	resurt = stat(old,&stat_buf);
	
	oldf = fopen(old,"r+");
	if(oldf == NULL)
	{
		perror("open oldfile failed\n");
		return -1;
	}
	
	fread(buf,stat_buf.st_size,1,oldf);
	
	newf = fopen(news,"w+");
	if(newf == NULL)
	{
		perror("open newfile failed\n");
		return -1;
	}
	fwrite(buf,stat_buf.st_size,1,newf);
	
	return 0;
}


int file_cp(pfile files,char *arg,int flag)
{
	char buf[60] = {0};
	pfile p = files->next;
	
	while(p != files)
	{
		printf("cp now %s\n",p->filename);
		// sprintf(buf,"touch %s",p->tarname);
		// system(buf);
		insert_cp(p->filename,p->tarname,arg,flag);
		
		//execl("/bin/mkdir","mkdir",buf,NULL);
		p = p->next;
	}
	
}


int satefile(char *arg,char *arg2,pfile files)					//拷贝
{
	 DIR *mydir;
	struct dirent *mydirent;
	char abuf[100] = {0};
	char bbuf[100] = {0};
	
	char hhbuf[50] = {0};
	
	mydir = opendir(arg);
	if(mydir == NULL)
	{
		perror("open dir failed!\n");
		return -1;
	}
	
	while((mydirent = readdir(mydir)) != NULL)
	{
		if(!strcmp(mydirent->d_name,".") || !strcmp(mydirent->d_name,".."))
		{
			continue;
		}
		else if(mydirent->d_type != 4)							//如果是文件
		{
			
			file_add(arg,mydirent->d_name,arg2,files);
		}
		else if(mydirent->d_type == 4)							//如果是目录
		{		
			sprintf(abuf,"%s/%s",arg,mydirent->d_name);
			sprintf(bbuf,"%s/%s",arg2,mydirent->d_name);
			//sprintf(hhbuf,"mkdir %s",bbuf);
			mkdir(bbuf, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
			//system(hhbuf);
			satefile(abuf,bbuf,files);
		}
		
	}
	return 0;
}

