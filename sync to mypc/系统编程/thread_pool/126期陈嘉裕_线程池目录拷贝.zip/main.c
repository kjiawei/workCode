/*
*功能：创建线程池，并添加任务实现目录的拷贝
*参数：源文件  目标路径  拷贝文件类型
*/


#include "myhead.h"

int main(int argc,char *argv[])
{
	char argvbuf1[50] = {0};								//主函数传参1
	char argvbuf2[50] = {0};								//主函数传参2
	int in_argv3 = 0;

	pfile file = file_init();

	
	if(argc < 2)
	{
		printf("please input the ture way\n");

		scanf("%s",argvbuf1);
		while(access(argvbuf1,F_OK))
		{
			printf("please input the ture way\n");
			memset(argvbuf1,0,sizeof(argvbuf1));
			scanf("%s",argvbuf1);
		}
	}
	else
	{
		strcpy(argvbuf1,argv[1]);
		while(access(argvbuf1,F_OK))
		{
			printf("the way unexist,please input the ture way\n");
			memset(argvbuf1,0,sizeof(argvbuf1));
			scanf("%s",argvbuf1);
		}
	}
	

	if(argc < 3)
	{	
		printf("please input the aim way\n");
		scanf("%s",argvbuf2);
	}
	else
	{
		strcpy(argvbuf2,argv[2]);
	}
	
	if(access(argvbuf2,F_OK))
	{
		if(access(argvbuf2,F_OK))
			mkdir(argvbuf2,S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	}
	

	if(argc >= 4)
	{
		if(!strcmp(argv[3],"-d"))
			in_argv3 = 2;
		else	
		in_argv3 = 1;
	}
	
	
		

	struct pool *pool;
	pool = (struct pool *)malloc(sizeof(struct pool));
	int i;

	pool_init(pool,6);	
	
	task_add(pool,task1,(void *)argvbuf1,(void *)argv[2],(void *)file);
	usleep(15000);
	task_add(pool,task2,(void *)file,(void *)argv[3],(void *)&in_argv3);
	usleep(15000);
	task_add(pool,task3,(void *)file,NULL,NULL);
	

	usleep(15000);
	
	pool_destory(pool);
	
	
	return 0;
}