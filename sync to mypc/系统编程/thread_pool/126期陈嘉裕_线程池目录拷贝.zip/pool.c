﻿/*
*功能：创建线程池，并添加任务实现目录的拷贝
*参数：源文件  目标路径  拷贝文件类型
*/



#include "myhead.h"



void *(task1)(void *arg,void *arg2,void *arg3)						//任务1
{
	satefile((char *)arg,(char *)arg2,(pfile)arg3);
	printf("我是第1个\n");
	pthread_exit(NULL);
}


void *(task2)(void *arg,void *arg2,void *arg3)						//任务2
{
	file_cp((pfile)arg,(char *)arg2,*(int *)arg3);
	printf("我是第2个\n");
	pthread_exit(NULL);
}


void *(task3)(void *arg,void *arg2,void *arg3)						//任务3
{
	file_show((pfile)arg);
	printf("我是第3个\n");
	pthread_exit(NULL);
}



void *(feels)(void *arg)										//解锁
{
	pthread_mutex_unlock((pthread_mutex_t *)arg);
}

void *handler(void *arg)									//3、线程函数初始化
{
	//printf("handler is %d\n",(int)pthread_self());
	struct pool *newpool = (struct pool *)arg;
	struct task *temp;
	while(1)
	{
		pthread_cleanup_push((void *)feels,(void *)&newpool->lock);
		pthread_mutex_lock(&newpool->lock);
		
	
	while(newpool->waitingtask == 0 && newpool->shutdown == false)
	{
		printf("pthread %d is waitting\n",(int)pthread_self());
		pthread_cond_wait(&newpool->cond,&newpool->lock);
	}
	
	if(newpool->shutdown == true)
	{
		pthread_mutex_unlock(&newpool->lock);
		printf("pthread %d will be exit\n",(int)pthread_self());
		
		pthread_exit(NULL);
	}	
	
	temp = newpool->taskhead->next;
	//temp = temp->next;
	newpool->taskhead->next = temp->next;
	
	newpool->waitingtask--;
	
	pthread_mutex_unlock(&newpool->lock);
	pthread_cleanup_pop(0);
	pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,NULL);
	(*(temp->funl))(temp->arg,temp->arg2,temp->arg3); 
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	
	free(temp);					//释放指针
	}
	pthread_exit(NULL);
}




int pool_init(struct pool *mypool,int ati_num)						//2、初始化线程池
{
	int i;
	
	mypool->id = malloc(sizeof(pthread_t) * ati_num);
	if(mypool->id == NULL)
	{
		perror("id init\n");
		return -1;
	}
	
	mypool->taskhead = malloc(sizeof(struct task));
	
	mypool->waitingtask = 0;
	
	mypool->doingtask = ati_num;
	
	mypool->shutdown = false;
	
	mypool->taskhead->next = NULL;
	
	pthread_mutex_init(&mypool->lock,NULL);
	
	pthread_cond_init(&mypool->cond,NULL);
	
	for(i=0; i<ati_num; i++)										//创建线程
	{
		pthread_create(&(mypool->id[i]),NULL,handler,(void *)mypool);
		usleep(2000);
	}	
	
	return 0;
}

int task_add(struct pool *mypool,void *(*funl)(void *arg,void *arg2,void *arg3),void *arg,void *arg2,void *arg3)		//添加任务
{	
	struct task *new = malloc(sizeof(struct task));
	
	new->funl = funl; 
	new->arg = arg;
	new->arg2 = arg2;
	new->arg3 = arg3;
	new->next = NULL;
	
	pthread_mutex_lock(&mypool->lock);
	
	if(mypool->waitingtask >= mypool->doingtask)
	{
		pthread_mutex_unlock(&mypool->lock);
		printf("too many task,sorry\n");
		free(new);
		
		return -1;
	}
	
	struct task *temp = mypool->taskhead;
	while(temp->next != NULL)
		temp = temp->next;
	
	temp->next = new;
	
	
	mypool->waitingtask++;
	
	pthread_mutex_unlock(&mypool->lock);
	pthread_cond_signal(&mypool->cond);
	
	return 0;
}


int pool_destory(struct pool *mypool)
{
	int i;
	free(mypool->id);
	
	mypool->shutdown = true;
	
	pthread_cond_broadcast (&(mypool->cond));
	
	pthread_mutex_destroy(&(mypool->lock));
	pthread_cond_destroy(&(mypool->cond));
	
	for(i=0; i<mypool->doingtask; i++)
	{
		pthread_join(mypool->id[i],NULL);
	}
	
	
}



