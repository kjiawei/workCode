#ifndef _MYHEAD_H_
#define _MYHEAD_H_

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>


typedef struct file
{
	char filename[40];
	char tarname[40];
	
	struct file *prev;
	struct file *next;
}file,*pfile;




struct task								//1、任务链表创建
{
	void *(*funl)(void *arg,void *arg2,void *arg3);
	void *arg;
	void *arg2;
	void *arg3;
	
	struct task *next;	
};

struct pool								//定义线程池结构体
{
	pthread_t *id;						//保存多个线程id
	
	pthread_mutex_t lock;
	pthread_cond_t cond;
	
	struct task *taskhead;
	
	int waitingtask;						//等待的线程
	int doingtask;							//活跃的线程数量
	
	
	
	bool shutdown;
	
};



extern pfile file_init();
extern int file_add(char *area,char *name,char *tar,pfile files);
extern void file_show(pfile file);
extern int insert_cp(char *old,char *news,char *arg,int flags);
extern int file_cp(pfile files,char *arg,int flag);
extern int satefile(char *arg,char *arg2,pfile files);
extern int satefile(char *arg,char *arg2,pfile files);
extern void *(task1)(void *arg,void *arg2,void *arg3);
extern void *(task2)(void *arg,void *arg2,void *arg3);
extern void *(task3)(void *arg,void *arg2,void *arg3);
extern void *(feels)(void *arg);
extern void *handler(void *arg);
extern int pool_init(struct pool *mypool,int ati_num);
extern int task_add(struct pool *mypool,void *(*funl)(void *arg,void *arg2,void *arg3),void *arg,void *arg2,void *arg3);
extern int pool_destory(struct pool *mypool);



#endif