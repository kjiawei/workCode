<?php
return $arr= array (
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'wx_shop',
  'DB_USER' => 'root',
  'DB_PWD' => '',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'weixin_',
);