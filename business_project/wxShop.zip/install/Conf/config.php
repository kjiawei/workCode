<?php
return array(
	'DEFAULT_MODULE' => 'index', //默认控制器
	'APP_AUTOLOAD_PATH' => '@.ORG', //自动加载项目类库
	'URL_MODEL' => '0',
	'OUTPUT_ENCODE' => false,
);